"""Summarize live content-free telemetry for each user message; no model calls."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "services/agentd-py"))
from agentd.retrieval.candidate_metrics import message_measurement  # noqa: E402


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=ROOT / ".crucible/state/performance.jsonl")
    parser.add_argument("--limit", type=int, default=20)
    parser.add_argument("--output", type=Path, help="Save full per-message JSON instead of printing a table")
    args = parser.parse_args()
    # Two passes avoid keeping every historical trace's profiling records in RAM.
    identities = {}
    with args.source.open() as stream:
        for line in stream:
            try:
                row = json.loads(line)
            except ValueError:  # A concurrent append may leave an incomplete last line.
                continue
            if row.get("layer") == "user_turn":
                identities[row["trace"]] = row
    traces = sorted(identities, key=lambda t: identities[t].get("started_unix_ms", 0))[
        -max(1, args.limit):]
    grouped = {t: [] for t in traces}
    with args.source.open() as stream:
        for line in stream:
            try:
                row = json.loads(line)
            except ValueError:
                continue
            if row.get("trace") in grouped:
                grouped[row["trace"]].append(row)
    results = [{"trace": t, **message_measurement(grouped[t])} for t in traces]
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(results, indent=2) + "\n")
        print(args.output)
        return
    print("| Message | Backend ms | Retrieval ms | Qwen ms | Requests | Current candidate tokens | Automatic candidate tokens sent | Filter before → after | Without Qwen estimate |")
    print("|---|---:|---:|---:|---:|---:|---:|---:|---:|")
    for row in results:
        spans = row["span_ms"]
        retrieval = spans.get("candidates.retrieval", {}).get("total", 0)
        qwen = spans.get("candidates.reranking", {}).get("total", 0)
        print(f"| {row['message_id']} | {row['backend_elapsed_ms']} | {retrieval} | {qwen} | "
              f"{row['physical_requests']} | {row['candidate_tokens_new_deliveries']} | "
              f"{row['candidate_tokens_all_requests']} | "
              f"{row['filter_catalog_tokens_before']} → {row['filter_catalog_tokens_after']} | "
              f"{row['delivery_comparison']['without_qwen_tokens']} |")
    if any(r["index_search_calls"] for r in results):
        print("\n| Message | Index lookups | New index result tokens |")
        print("|---|---:|---:|")
        for row in results:
            print(f"| {row['message_id']} | {row['index_search_calls']} | "
                  f"{row['index_search_result_tokens']} |")
    print("\nAutomatic candidate tokens are o200k_base envelope estimates, summed across requests "
          "including retries. Filter columns compare each computed catalog once, before visibility "
          "suppression. Without-Qwen estimates apply the same observed reads to the unfiltered "
          "catalog, not a separate agent run. Index result tokens count new tool outputs once; "
          "replayed tool history still contributes to whole input. Timing includes telemetry overhead.")


if __name__ == "__main__":
    main()
