"""Read-only live messages, content-free backend telemetry and per-message attribution."""
from __future__ import annotations

import json
import argparse
import sys
import threading
import time
import urllib.request
from pathlib import Path
from uuid import uuid4

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from _backend_auth import auth_headers  # noqa: E402 -- repository-local helper
sys.path.insert(0, str(ROOT / "services/agentd-py"))
from agentd.retrieval.candidate_metrics import message_measurement  # noqa: E402


def summarize(rows):
    return message_measurement(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--on-demand", action="store_true")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    lock = json.loads((ROOT / ".crucible/state/agentd.lock").read_text())
    base = f"http://127.0.0.1:{lock['port']}"
    output = args.output or ROOT / "docs/validation/2026-10-18-qwen-live/messages.json"
    if output.exists():
        raise RuntimeError("Preserve previous live results")
    state = ROOT / ".crucible/state"
    (state / "performance.enabled").touch()
    source = state / "performance.jsonl"

    def request(path, payload=None, timeout=300):
        return urllib.request.urlopen(urllib.request.Request(
            base + path, data=json.dumps(payload).encode() if payload is not None else None,
            headers={**auth_headers(base), "Content-Type": "application/json"}), timeout=timeout)

    def new_thread():
        with request("/v1/chat/threads", {"workspace": str(ROOT), "title": "Qwen live metrics"}) as r:
            return json.load(r)["thread_id"]

    thread = new_thread()
    cases = [
        (thread, "code", "Read services/agentd-py/agentd/retrieval/candidate_delivery.py and explain "
         "when its catalog is recomputed rather than reused. Read-only; do not edit files. "
         "Keep the answer to three sentences."),
        (thread, "acknowledgement", "Thanks, that answers it."),
        (thread, "multiple_files", "Now explain how candidate relevance filtering, local-model "
         "opt-out and hybrid retrieval connect. Inspect the needed files; read-only, no edits. "
         "Give a concise answer."),
        (new_thread(), "greeting", "hello"),
    ]
    if args.on_demand:
        cases[0] = (thread, "unknown_location", "Where is the logic that decides whether local "
                    "code-retrieval models are enabled, and what happens when they are disabled? "
                    "Locate and read the relevant implementation. Read-only; do not edit files. "
                    "Answer in three sentences.")
        cases[2] = (thread, "multiple_files", "How are code candidate catalogs refreshed after "
                    "edits and suppressed when their source is already visible? Trace the "
                    "relevant components. Read-only; do not edit files. Answer concisely.")
    results = []
    for tid, label, message in cases:
        offset = source.stat().st_size if source.exists() else 0
        mid = str(uuid4())
        started = time.perf_counter()
        done = threading.Event()

        def watchdog():
            if not done.wait(240):
                with request(f"/v1/chat/threads/{tid}/stop", {}, timeout=20) as r:
                    r.read()

        threading.Thread(target=watchdog, daemon=True).start()
        row = {"label": label, "thread_id": tid, "message_id": mid, "message": message,
               "events": [], "completed": False}
        try:
            with request(f"/v1/chat/threads/{tid}/message", {
                "content": message, "message_id": mid, "plan_mode": False,
                "step_review": False}) as response:
                row["http_headers_ms"] = round((time.perf_counter() - started) * 1000, 2)
                for line in response:
                    if not line.startswith(b"data: "):
                        continue
                    event = json.loads(line[6:])
                    kind = event.get("type")
                    row["events"].append(kind)
                    if kind == "chat_response" and "first_response_ms" not in row:
                        row["first_response_ms"] = round((time.perf_counter() - started) * 1000, 2)
                    if kind in {"chat_done", "done"}:
                        row["elapsed_ms"] = round((time.perf_counter() - started) * 1000, 2)
                        row["completed"] = True
                        break
        finally:
            done.set()
            if not row["completed"]:
                with request(f"/v1/chat/threads/{tid}/stop", {}, timeout=20) as r:
                    r.read()
            records = []
            for _ in range(40):
                if source.exists():
                    with source.open() as stream:
                        stream.seek(offset)
                        records = [json.loads(line) for line in stream if line.strip()]
                traces = {r["trace"] for r in records if r.get("layer") == "user_turn"
                          and r.get("message_id") == mid}
                selected = [r for r in records if r.get("trace") in traces]
                if any(r.get("name") == "controller.backend_turn" and r.get("kind") == "span"
                       for r in selected):
                    break
                time.sleep(.1)
            assert traces, "Missing message-to-trace attribution"
            row["trace_ids"] = sorted(traces)
            row["metrics"] = summarize(selected)
            tools = sorted([r for r in selected if r.get("kind") == "span"
                            and str(r.get("name", "")).startswith("tool.")],
                           key=lambda r: r["start_ns"])
            discovery = {"search_index", "search_code", "search_semantic", "query_graph",
                         "read_file", "list_directory"}
            row["first_executed_tool"] = tools[0]["name"][5:] if tools else None
            row["first_discovery_tool"] = next((r["name"][5:] for r in tools
                                                 if r["name"][5:] in discovery), None)
            row["index_searches"] = [r for r in selected if r.get("layer") == "index_search"]
            row["candidate_path_verified"] = bool(row["metrics"]["filter_computations"])
            row["records"] = selected
            results.append(row)
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_text(json.dumps(results, indent=2) + "\n")
            print(label, "completed", row["completed"], "elapsed_ms", row.get("elapsed_ms"),
                  "physical_requests", row["metrics"]["physical_requests"],
                  "candidate_tokens", row["metrics"]["candidate_tokens_all_requests"], flush=True)


if __name__ == "__main__":
    main()
