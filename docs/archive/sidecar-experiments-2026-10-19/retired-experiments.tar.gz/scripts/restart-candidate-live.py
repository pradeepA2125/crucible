"""Restart this workspace's idle backend with selected discovery, preserving provider env."""
from __future__ import annotations

import concurrent.futures
import argparse
import ctypes
import json
import os
import signal
import struct
import subprocess
import sys
import time
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from _backend_auth import BackendAuthError, auth_headers  # noqa: E402 -- repository-local helper


def process_launch(pid):
    libc = ctypes.CDLL(None, use_errno=True)
    mib = (ctypes.c_int * 3)(1, 49, pid)
    size = ctypes.c_size_t()
    if libc.sysctl(mib, 3, None, ctypes.byref(size), None, 0):
        raise OSError(ctypes.get_errno())
    buf = ctypes.create_string_buffer(size.value)
    if libc.sysctl(mib, 3, buf, ctypes.byref(size), None, 0):
        raise OSError(ctypes.get_errno())
    raw = buf.raw[:size.value]
    argc = struct.unpack_from("i", raw)[0]
    cursor = raw.index(b"\0", 4) + 1
    while raw[cursor:cursor + 1] == b"\0":
        cursor += 1
    argv = []
    for _ in range(argc):
        end = raw.index(b"\0", cursor)
        argv.append(raw[cursor:end].decode())
        cursor = end + 1
    env = {}
    for item in raw[cursor:].split(b"\0"):
        if b"=" in item:
            k, v = item.split(b"=", 1)
            env[k.decode()] = v.decode()
    return argv, env


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate-delivery", choices=["automatic", "on_demand"], default="on_demand")
    parser.add_argument("--receipt", type=Path)
    args = parser.parse_args()
    lock = json.loads((ROOT / ".crucible/state/agentd.lock").read_text())
    pid, port = lock["pid"], lock["port"]
    argv, env = process_launch(pid)
    assert argv[1:3] == ["-m", "agentd.serve"]
    assert argv[-2:] == ["--workspace-lock", str(ROOT)]
    assert env["CRUCIBLE_WORKSPACE_PATH"] == str(ROOT)
    assert env.get("CRUCIBLE_LOCAL_MODELS", "1").lower() in {"1", "true", "yes", "on"}
    base = f"http://127.0.0.1:{port}"

    def get(path):
        req = urllib.request.Request(base + path, headers=auth_headers(base))
        with urllib.request.urlopen(req, timeout=15) as response:
            return json.load(response)

    threads = get("/v1/chat/threads?" + urllib.parse.urlencode({"workspace": str(ROOT)}))["threads"]
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        states = list(pool.map(lambda t: get(f"/v1/chat/threads/{t['thread_id']}/live"), threads))
    assert not any(s.get("turn_active") or s.get("agents_running") for s in states), (
        "Live turns are active; restart deferred")
    before = get("/v1/config")
    env.update(CRUCIBLE_CODE_CANDIDATE_TRIAL="1", CRUCIBLE_CODE_CANDIDATE_SCORER="qwen",
               CRUCIBLE_CODE_CANDIDATE_DELIVERY=args.candidate_delivery,
               CRUCIBLE_CODE_QWEN_MODEL_PATH=str(ROOT / ".crucible/models/qwen3-reranker-0.6b"))
    os.kill(pid, signal.SIGTERM)
    for _ in range(100):
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            break
        time.sleep(.1)
    else:
        raise RuntimeError("Previous backend did not exit cleanly")
    with (ROOT / ".crucible/state/qwen-live-backend.log").open("ab", buffering=0) as log:
        backend = subprocess.Popen(argv, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                   stdout=log, stderr=log, start_new_session=True)
    result = {"port": port, "pid": backend.pid, "ready": False}
    for _ in range(120):
        if backend.poll() is not None:
            raise RuntimeError("Updated backend exited; inspect qwen-live-backend.log")
        try:
            config = get("/v1/config")
            scorer_ready = config.get("candidate_scorer", {}).get("state") == "ready"
            demand_ready = (args.candidate_delivery == "on_demand"
                            and config.get("candidate_delivery") == "on_demand"
                            and config.get("local_models", {}).get("embedder", {}).get("state")
                            == "ready")
            if scorer_ready or demand_ready:
                result.update(ready=True, candidate_scorer=config["candidate_scorer"],
                              candidate_delivery=config.get("candidate_delivery", "automatic"),
                              provider_unchanged=before["provider"] == config["provider"],
                              local_models=config["local_models"])
                break
            if config.get("candidate_scorer", {}).get("state") == "unavailable":
                raise RuntimeError("Qwen warmup failed")
        except (OSError, ValueError, BackendAuthError):
            pass
        time.sleep(.5)
    else:
        raise RuntimeError("Qwen readiness deadline exceeded")
    target = args.receipt or ROOT / "docs/validation/2026-10-18-qwen-live/restart.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
