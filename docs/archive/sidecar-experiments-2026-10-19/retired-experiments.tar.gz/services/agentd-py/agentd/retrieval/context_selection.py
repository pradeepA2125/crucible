"""Cached semantic context selection for the opt-in candidate trial."""
from __future__ import annotations

import math
import threading
from collections import OrderedDict
from collections.abc import Mapping

from agentd.local_models import LocalModels
from agentd.memory.embedder import Embedder


def trial_enabled(env: Mapping[str, str]) -> bool:
    return env.get("CRUCIBLE_CODE_CANDIDATE_TRIAL", "").lower() in {"1", "true", "yes", "on"}


def on_demand_enabled(env: Mapping[str, str]) -> bool:
    # Automatic delivery is an explicit opt-in; unset/invalid settings use on-demand.
    return env.get("CRUCIBLE_CODE_CANDIDATE_DELIVERY", "on_demand").strip().lower() != "automatic"


def threshold(env: Mapping[str, str], key: str, default: float) -> float:
    try:
        value = float(env.get(key, str(default)))
        return value if math.isfinite(value) and 0 < value <= 1 else default
    except ValueError:
        return default


class SemanticContextSelector:
    """One encode batch for query + uncached segments, then cosine comparisons.

    Cache is process-local, bounded, and owned by one model instance. No LLM
    classification, keyword bypass or per-segment reranker passes.
    """

    def __init__(self, embedder: Embedder, capability: LocalModels, *, cutoff: float = .55
                 ) -> None:
        self.embedder = embedder
        self.capability = capability
        self.cutoff = cutoff
        self._cache: OrderedDict[str, list[float]] = OrderedDict()
        self._lock = threading.Lock()

    @classmethod
    def from_env(cls, env: Mapping[str, str], capability: LocalModels | None
                 ) -> SemanticContextSelector | None:
        if on_demand_enabled(env) or env.get(
            "CRUCIBLE_CODE_CANDIDATE_SCORER", "bge"
        ).strip().lower() in {"qwen", "none"}:
            return None
        if not trial_enabled(env) or capability is None or not capability.enabled:
            return None
        return cls(Embedder(env.get("CRUCIBLE_EMBEDDING_MODEL", "BAAI/bge-small-en-v1.5"),
                            local_models=capability), capability,
                   cutoff=threshold(env, "CRUCIBLE_CODE_CONTEXT_MIN_SIMILARITY", .55))

    def select(self, query: str, **signals: str) -> dict[str, str]:
        limits = {"recap": 400, "summary": 600, "closing": 400}
        bounded = {k: v[:limits[k]] for k, v in signals.items() if k in limits and v.strip()}
        if not bounded or not self.capability.ready("embedder"):
            return bounded
        with self._lock:
            missing = list(dict.fromkeys(v for v in bounded.values() if v not in self._cache))
            vectors = self.embedder.embed([query[:1600], *missing])
            if len(vectors) != 1 + len(missing):
                return bounded  # unavailable/failed inference preserves normal retrieval
            if (not vectors[0] or not all(math.isfinite(x) for v in vectors for x in v)
                    or any(sum(x * x for x in v) == 0 for v in vectors)
                    or any(len(v) != len(vectors[0]) for v in vectors)):
                return bounded
            for text, vector in zip(missing, vectors[1:], strict=True):
                self._cache[text] = vector
            selected = {}
            for name, text in bounded.items():
                vector = self._cache[text]
                self._cache.move_to_end(text)
                similarity = sum(a * b for a, b in zip(vectors[0], vector, strict=True))
                if similarity >= self.cutoff:
                    selected[name] = text
            while len(self._cache) > 96:
                self._cache.popitem(last=False)
            return selected
