"""Experimental local relevance gate; unavailable inference always passes through."""
from __future__ import annotations

import logging
import math
from collections.abc import Mapping
from typing import Any

from agentd.local_models import LocalModels
from agentd.memory.reranker import Reranker
from agentd.retrieval.context_selection import on_demand_enabled, trial_enabled

logger = logging.getLogger(__name__)


def candidate_document(candidate: Mapping[str, Any]) -> str:
    """The metadata-only representation evaluated in the calibration experiment."""
    return f"File: {candidate['path']}\nSymbols: " + ", ".join(
        f"{symbol.get('name')} ({symbol.get('kind')})"
        for symbol in candidate.get("symbols", [])
    )


class CandidateRelevanceGate:
    """Single-batch relevance filtering, gated by existing local-model readiness.

    The opt-in trial accepts false negatives and filters individual rows at .10.
    The earlier explicit-cutoff experiment retains its catalog-gate behavior.
    Neither mode verifies source or perfectly classifies conversational intent.
    """

    def __init__(self, ranker: Reranker, local_models: LocalModels, *, cutoff: float,
                 per_candidate: bool = False) -> None:
        if not math.isfinite(cutoff) or not 0 < cutoff <= 1:
            raise ValueError("Candidate gate cutoff must be finite and in (0, 1]")
        self.ranker = ranker
        self.local_models = local_models
        self.cutoff = cutoff
        self.per_candidate = per_candidate

    @classmethod
    def from_env(
        cls, env: Mapping[str, str], local_models: LocalModels | None,
    ) -> CandidateRelevanceGate | None:
        if on_demand_enabled(env) or env.get(
            "CRUCIBLE_CODE_CANDIDATE_SCORER", "bge"
        ).strip().lower() == "none":
            return None
        trial = trial_enabled(env)
        from agentd.retrieval.qwen_gate import configured_gate, qwen_enabled
        if trial and qwen_enabled(env):
            return configured_gate(env, local_models)  # type: ignore[return-value]
        value = env.get("CRUCIBLE_CODE_CANDIDATE_MIN_SCORE", "0.1" if trial else "").strip()
        if not value or local_models is None or not local_models.enabled:
            return None
        try:
            cutoff = float(value)
            if not math.isfinite(cutoff) or not 0 < cutoff <= 1:
                raise ValueError("outside (0, 1]")
        except ValueError:
            logger.warning("[retrieval] invalid candidate cutoff; using direct delivery")
            return None
        ranker = Reranker(
            env.get("CRUCIBLE_MEMORY_RERANKER_MODEL", "BAAI/bge-reranker-base"),
            local_models=local_models, bounded=True,
        )
        return cls(ranker, local_models, cutoff=cutoff, per_candidate=trial)

    def filter(self, query: str, candidates: list[dict[str, Any]], **signals: str
               ) -> list[dict[str, Any]]:
        if (not candidates or not self.local_models.ready("reranker")
                or not self.ranker.available):
            return candidates
        try:
            context = {"Q": query}
            if self.per_candidate:
                context["R"] = "\n".join(signals.get(k, "") for k in ("recap", "summary"))
                context["C"] = signals.get("closing", "")
            result = self.ranker.score_context(
                context, [candidate_document(candidate) for candidate in candidates],
            )
            if (len(result.scores) != len(candidates)
                    or not all(math.isfinite(s) and 0 <= s <= 1 for s in result.scores)):
                raise ValueError("Invalid candidate relevance scores")
            accepted = max(result.scores) >= self.cutoff
            logger.debug("[retrieval] candidate gate accepted=%s max_score=%.6f cutoff=%.6f",
                         accepted, max(result.scores), self.cutoff)
            if self.per_candidate:
                return [c for c, s in zip(candidates, result.scores, strict=True)
                        if s >= self.cutoff]
            return candidates if accepted else []
        except Exception:
            logger.debug("[retrieval] candidate gate failed; using direct delivery", exc_info=True)
            return candidates
