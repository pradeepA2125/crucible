"""Content-free candidate payload attribution using a named proxy tokenizer."""
from __future__ import annotations

import json
from functools import lru_cache
from typing import Any


@lru_cache(maxsize=1)
def _encoding() -> Any:
    try:
        import tiktoken
        return tiktoken.get_encoding("o200k_base")
    except Exception:
        return None


def payload_measurement(text: str) -> dict[str, Any]:
    if not text:
        return {"tokens": 0, "chars": 0, "method": "empty"}
    # Same escaped string field used by the logical request; exact standalone
    # envelope tokenization, not a claim about a provider's full request boundary.
    field = json.dumps({"code_candidates": text}, ensure_ascii=False, separators=(",", ":"))
    encoding = _encoding()
    return {"tokens": len(encoding.encode(field, disallowed_special=())) if encoding else
            (len(field) + 3) // 4, "chars": len(field),
            "method": "o200k_base_field_envelope" if encoding else "chars_div_4_estimate"}


def text_measurement(text: str) -> dict[str, Any]:
    encoding = _encoding()
    return {"tokens": len(encoding.encode(text, disallowed_special=())) if encoding else
            (len(text) + 3) // 4, "chars": len(text),
            "method": "o200k_base_text" if encoding else "chars_div_4_estimate"}


def message_measurement(rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Aggregate one user turn, retaining retries and separating filter from delivery.

    The before/after comparison runs once per catalog computation. It is not a
    no-filter replay of the model calls, which could follow a different path.
    """
    physical = [r for r in rows if r.get("layer") == "physical"]
    filters = [r for r in rows if r.get("layer") == "candidate_filter"]
    deliveries = [r for r in rows if r.get("layer") == "candidate_delivery"]
    index_searches = [r for r in rows if r.get("layer") == "index_search"]
    compared = [r for r in deliveries if "without_qwen" in r]
    without_qwen = sum(r["without_qwen"]["tokens"] for r in compared)
    with_qwen = sum(r["delivered"]["tokens"] for r in compared)
    spans: dict[str, list[float]] = {}
    for row in rows:
        if row.get("kind") == "span":
            spans.setdefault(row["name"], []).append((row["end_ns"] - row["start_ns"]) / 1e6)
    identity = next((r for r in rows if r.get("layer") == "user_turn"), {})
    before = sum(r["before"]["tokens"] for r in filters)
    after = sum(r["after"]["tokens"] for r in filters)
    request_tokens = [r.get("candidate_payload_tokens", 0) for r in physical]
    root = spans.get("controller.backend_turn", [])
    return {
        "message_id": identity.get("message_id"), "thread_id": identity.get("thread_id"),
        "started_unix_ms": identity.get("started_unix_ms"),
        "completed": bool(root), "backend_elapsed_ms": round(sum(root), 2) if root else None,
        "physical_requests": len(physical),
        "index_search_calls": len(index_searches),
        "index_search_result_tokens": sum(r.get("result", {}).get("tokens", 0)
                                           for r in index_searches),
        "index_searches": index_searches,
        "candidate_tokens_all_requests": sum(request_tokens),
        "candidate_tokens_per_request": request_tokens,
        "candidate_tokens_new_deliveries": sum(r["delivered"]["tokens"] for r in deliveries),
        "delivery_comparison": {
            "method": "same_retrieved_catalog_and_observed_reads",
            "deliveries_compared": len(compared), "without_qwen_tokens": without_qwen,
            "with_qwen_tokens": with_qwen, "tokens_removed": without_qwen - with_qwen,
        },
        "candidate_tokens_logical_calls": sum(r.get("candidate_payload", {}).get("tokens", 0)
                                               for r in rows if r.get("layer") == "logical"),
        "candidate_token_methods": sorted({m["method"] for r in physical
                                            for m in r.get("candidate_payloads", [])}),
        "provider_input_reports": [r["input_tokens"] for r in rows if r.get("layer") == "reported"],
        "filter_catalog_tokens_before": before, "filter_catalog_tokens_after": after,
        "filter_catalog_tokens_removed": before - after,
        "filter_catalog_reduction_pct": (round(100 * (before - after) / before, 2)
                                         if before else None),
        "filter_computations": filters, "deliveries": deliveries,
        "candidate_errors": [r for r in rows if r.get("layer") == "candidate_error"],
        "span_ms": {k: {"calls": len(v), "total": round(sum(v), 2)} for k, v in spans.items()},
        "note": "Candidate tokens use o200k_base field envelopes, a provider-attribution proxy. "
                "Filter computations compare bounded catalogs before/after relevance only. "
                "Not a counterfactual estimate of entire-agent token or billing savings.",
    }
