"""Request-local candidate delivery; visible current reads are the only coverage proof."""
from __future__ import annotations

import hashlib
import json
from collections.abc import Callable
from pathlib import Path
from typing import Any

from agentd.retrieval.candidates import render_candidates
from agentd.subagents.write_log import canonical_path


def file_version(path: Path) -> tuple[int, ...] | None:
    try:
        stat = path.stat()
        return stat.st_mtime_ns, stat.st_ctime_ns, stat.st_size, stat.st_ino
    except OSError:
        return None


class CandidateDelivery:
    """One catalog cache per user turn; no artificial history or permanent 'seen' ledger.

    Recompute after steering, explicit refresh, edits/index changes or compaction.
    Recheck actual outgoing read content on every call, including after restart.
    """

    def __init__(self, workspace: Path, query: str, compute: Callable[[str], str],
                 snapshot_version: Callable[[], object], *,
                 unfiltered_catalog: Callable[[], str | None] | None = None,
                 catalog_only: bool = False) -> None:
        self.workspace = workspace.resolve()
        self.query = query
        self.compute = compute
        self.snapshot_version = snapshot_version
        self.unfiltered_catalog = unfiltered_catalog
        self.catalog_only = catalog_only
        self.catalog: dict[str, Any] | None = None
        self._version: object = None
        self._reads: dict[tuple[str, tuple[int, ...]], tuple[str, list[str]]] = {}
        self._failed_results: set[str] = set()

    def _paths(self) -> list[str]:
        return [row[0] for row in (self.catalog or {}).get("candidates", [])]

    def _state(self) -> object:
        return self.snapshot_version(), [
            (path, file_version(self.workspace / path)) for path in self._paths()
        ]

    def _new_failure(self, history: list[dict[str, Any]]) -> bool:
        refresh = False
        for entry in history:
            content = str(entry.get("content", ""))
            failed = entry.get("is_error") or (
                entry.get("tool") in {"search_code", "search_semantic"}
                and content.startswith(("No matches found", "No semantically similar code found"))
            )
            if (entry.get("role") != "tool_result" or not failed
                    or entry.get("tool") not in {"read_file", "search_code", "search_semantic",
                                                 "query_graph"}):
                continue
            key = str(entry.get("call_id") or (entry.get("tool"), entry.get("content")))
            if key not in self._failed_results:
                self._failed_results.add(key)
                refresh = True
        return refresh

    def _visible(self, history: list[dict[str, Any]], paths: list[str] | None = None,
                 ) -> dict[str, tuple[int, list[tuple[int, int]]]]:
        eligible = set(self._paths() if paths is None else paths)
        covered: dict[str, tuple[int, list[tuple[int, int]]]] = {}
        for entry in history:
            metadata = entry.get("delivered_read")
            content = entry.get("content")
            if (entry.get("role") != "tool_result" or entry.get("tool") != "read_file"
                    or entry.get("is_error") or not isinstance(metadata, dict)
                    or not isinstance(content, str)):
                continue
            root = metadata.get("root")
            if not isinstance(root, str) or not root or Path(root).resolve() != self.workspace:
                continue
            path = canonical_path(self.workspace, str(metadata.get("path", "")))
            if path is None or path not in eligible:
                continue
            start, end = metadata.get("delivered_start"), metadata.get("delivered_end")
            if type(start) is not int or type(end) is not int or not 0 < start <= end:
                continue
            absolute = self.workspace / path
            version = file_version(absolute)
            if version is None or version[2] > 2_000_000:
                continue
            key = (path, version)
            if key not in self._reads:
                try:
                    with absolute.open("rb") as handle:
                        raw = handle.read(2_000_001)
                except OSError:
                    continue
                if len(raw) > 2_000_000 or version != file_version(absolute):
                    continue
                self._reads[key] = (hashlib.sha256(raw).hexdigest(),
                                    raw.decode("utf-8", errors="replace").splitlines())
            digest, lines = self._reads[key]
            if metadata.get("revision") != digest or end > len(lines):
                continue
            # Metadata alone can survive compaction/truncation; require the actual
            # complete numbered output still be present, not an old hash or summary.
            expected = "\n".join(f"{i + 1:4d}: {lines[i]}" for i in range(start - 1, end))
            if not expected or not content.startswith(expected):
                continue
            covered.setdefault(path, (len(lines), []))[1].append((start, end))
        return covered

    @staticmethod
    def _covered(row: list[Any], visible: tuple[int, list[tuple[int, int]]]) -> bool:
        total, spans = visible
        merged: list[list[int]] = []
        for start, end in sorted(spans):
            if merged and start <= merged[-1][1] + 1:
                merged[-1][1] = max(merged[-1][1], end)
            else:
                merged.append([start, end])

        def includes(start: int, end: int) -> bool:
            return any(a <= start <= end <= b for a, b in merged)

        if includes(1, total):
            return True
        ranges, symbols = row[2], row[1]
        # Without reliable range hints, a definition line alone isn't the body.
        return bool(ranges) and all(includes(a, b) for a, b in ranges) and all(
            type(s[2]) is int and includes(s[2], s[2]) for s in symbols
        )

    def deliver(self, history: list[dict[str, Any]], query: str | None = None,
                refresh: bool = False) -> str:
        if query is not None and query != self.query:
            self.query = query
            refresh = True
        refresh = self._new_failure(history) or refresh
        recomputed = self.catalog is None or refresh or self._version != self._state()
        if recomputed:
            text = self.compute(self.query)
            self.catalog = json.loads(text) if text else {"candidates": []}
            self._version = self._state()
            self._reads.clear()
        visible = self._visible(history)
        assert self.catalog is not None
        text, remaining_count = self._render(self.catalog, visible)
        from agentd.performance import capturing, context_measurement
        if capturing():
            from agentd.retrieval.candidate_metrics import payload_measurement
            measurement: dict[str, Any] = {"layer": "candidate_delivery", "recomputed": recomputed,
                           "rows_before_visibility": len(self.catalog.get("candidates", [])),
                           "rows_after_visibility": remaining_count,
                           "delivered": payload_measurement(text)}
            baseline = self.unfiltered_catalog() if self.unfiltered_catalog else None
            if baseline is not None:
                catalog = json.loads(baseline) if baseline else {"candidates": []}
                baseline_visible = self._visible(history, [r[0] for r in catalog["candidates"]])
                baseline_text, _ = self._render(catalog, baseline_visible)
                measurement["without_qwen"] = payload_measurement(baseline_text)
                measurement["comparison"] = "same_retrieved_catalog_and_observed_reads"
            context_measurement(measurement)
        return text

    def _render(self, catalog: dict[str, Any],
                visible: dict[str, tuple[int, list[tuple[int, int]]]]) -> tuple[str, int]:
        rows = catalog.get("candidates", [])
        remaining = [r for r in rows if r[0] not in visible
                     or not self._covered(r, visible[r[0]])]
        relationships = [
            {"from": rows[a][0], "to": rows[b][0], "kind": kind}
            for a, b, kind in catalog.get("relations", [])
            if type(a) is int and type(b) is int and 0 <= a < len(rows) and 0 <= b < len(rows)
        ]
        # No refills: explicit paths or removed graph neighbours must not be
        # silently reintroduced after relevance/visibility rejection.
        text = render_candidates([
            {"path": r[0], "symbols": [dict(zip(("name", "kind", "line"), s, strict=True))
                                       for s in r[1]], "ranges": r[2]}
            for r in remaining
        ], relationships, query=self.query, include_explicit=False)
        if self.catalog_only:
            from agentd.retrieval.candidates import format_catalog
            text = format_catalog(text)
        return text, len(remaining)
