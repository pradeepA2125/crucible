"""Opt-in plain-context Qwen scorer; memory keeps its independent BGE reranker."""
from __future__ import annotations

import json
import math
from collections.abc import Mapping
from typing import Any

from agentd.local_models import LocalModels
from agentd.model_loading import MODEL_LOCK
from agentd.retrieval.candidate_gate import candidate_document

_SHARED: dict[str, QwenCandidateGate] = {}
_PREFIX = ('<|im_start|>system\nJudge whether the Document meets the requirements based on the '
           'Query and the Instruct provided. Note that the answer can only be "yes" or "no".'
           '<|im_end|>\n<|im_start|>user\n')
_SUFFIX = '<|im_end|>\n<|im_start|>assistant\n<think>\n\n</think>\n\n'
_RULE = "Judge whether this candidate file is relevant to the supplied conversation and request."


def qwen_enabled(env: Mapping[str, str]) -> bool:
    return env.get("CRUCIBLE_CODE_CANDIDATE_SCORER", "bge").lower() == "qwen"


def configured_gate(env: Mapping[str, str], models: LocalModels | None
                    ) -> QwenCandidateGate | None:
    from agentd.retrieval.context_selection import on_demand_enabled
    if on_demand_enabled(env) or not qwen_enabled(env) or models is None or not models.enabled:
        return None
    path = env.get("CRUCIBLE_CODE_QWEN_MODEL_PATH", "Qwen/Qwen3-Reranker-0.6B")
    # One scorer per configured path/capability, shared by startup and the controller.
    with MODEL_LOCK:
        gate = _SHARED.get(path)
        if gate is None or gate.local_models is not models:
            gate = QwenCandidateGate(path, models)
            _SHARED[path] = gate
        return gate


class QwenCandidateGate:
    per_candidate = True
    cutoff = .5
    name = "qwen_plain"

    def __init__(self, path: str, local_models: LocalModels) -> None:
        self.path = path
        self.local_models = local_models
        self._state = "loading"
        self._model: Any = None
        self._tokenizer: Any = None
        self.last_status = "loading"

    def status(self) -> dict[str, str]:
        return {"scorer": self.name, "state": self._state}

    def warmup(self) -> None:
        if not self.local_models.enabled or self._state != "loading":
            return
        try:
            with MODEL_LOCK:
                if self._state != "loading":
                    return
                import torch
                from transformers import AutoModelForCausalLM, AutoTokenizer

                device = "mps" if torch.backends.mps.is_available() else (
                    "cuda" if torch.cuda.is_available() else "cpu")
                dtype = torch.bfloat16 if device != "cpu" else torch.float32
                self._tokenizer = AutoTokenizer.from_pretrained(
                    self.path, padding_side="left", local_files_only=True, trust_remote_code=False)
                self._model = AutoModelForCausalLM.from_pretrained(
                    self.path, local_files_only=True, trust_remote_code=False,
                    dtype=dtype, attn_implementation="sdpa").eval().to(device)
                scores = self._score("Which planet is red?", ["Mars is the red planet."])
                if len(scores) != 1:
                    raise ValueError("Qwen warmup returned no score")
                self._state = "ready"
        except Exception:
            self._state = "unavailable"
            self._model, self._tokenizer = None, None

    def _score(self, query: str, documents: list[str]) -> list[float]:
        import torch

        with MODEL_LOCK, torch.inference_mode():
            tokenizer, model = self._tokenizer, self._model
            texts = [_PREFIX + f"<Instruct>: {_RULE}\n<Query>: {query}\n<Document>: {doc}" +
                     _SUFFIX for doc in documents]
            encoded = tokenizer(texts, add_special_tokens=False, padding=True,
                                truncation=False, return_tensors="pt")
            if encoded["input_ids"].shape[1] > 8192:
                raise ValueError("Qwen candidate pair exceeds input budget")
            output = model(**{k: v.to(model.device) for k, v in encoded.items()},
                           logits_to_keep=1, use_cache=False).logits[:, -1, :]
            no, yes = [tokenizer.convert_tokens_to_ids(t) for t in ("no", "yes")]
            scores = torch.softmax(torch.stack([output[:, no], output[:, yes]], 1).float(),
                                   dim=1)[:, 1].cpu().tolist()
            if len(scores) != len(documents) or not all(
                    math.isfinite(s) and 0 <= s <= 1 for s in scores):
                raise ValueError("Invalid Qwen candidate scores")
            return scores

    def filter(self, query: str, candidates: list[dict[str, Any]], **signals: str
               ) -> list[dict[str, Any]]:
        if not candidates:
            self.last_status = "empty"
            return []
        if not self.local_models.enabled or self._state != "ready":
            self.last_status = "bypassed_" + self._state
            return candidates
        try:
            state = {"current_request": query[:1600], "recap": signals.get("recap", "")[:400],
                     "summary": signals.get("summary", "")[:600],
                     "previous_answer": signals.get("closing", "")[:400]}
            scores = self._score(json.dumps(state, ensure_ascii=False),
                                 [candidate_document(c) for c in candidates])
            self.last_status = "filtered"
            return [c for c, s in zip(candidates, scores, strict=True) if s > self.cutoff]
        except Exception:
            self._state = "unavailable"
            self.last_status = "bypassed_failure"
            return candidates
