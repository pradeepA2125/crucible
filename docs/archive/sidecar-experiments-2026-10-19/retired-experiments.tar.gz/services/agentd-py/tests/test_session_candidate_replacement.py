"""Exercise candidate replacement at the actual native request-history boundary."""
import copy
import json

import pytest

from agentd.context_metrics import physical_context
from agentd.providers.openai_native import CURRENT_STEP, SessionInputs, _labelled


def tail(candidates="old", *, parts=False):
    payload = {"goal": "task", "instruction": "keep this"}
    if candidates:
        payload["code_candidates"] = candidates
    content = json.dumps(payload)
    if parts:
        content = [{"type": "input_text", "text": content},
                   {"type": "input_image", "image_url": "https://example.test/image"}]
    return {"role": "user", "content": content}


@pytest.mark.parametrize("parts", [False, True])
def test_catalog_is_replaced_then_removed_without_losing_tools_or_images(parts):
    cache = SessionInputs()
    head = {"role": "user", "content": '{"workspace_path":"/ws"}'}
    quoted = {"role": "user", "content": 'Explain the literal "code_candidates"'}
    first = [head, quoted, tail(parts=parts)]
    sent = cache.build("chat", first)
    original = copy.deepcopy(sent)
    cache.commit("chat", first, sent)
    assert sent == original  # Never mutate a request retained by transport/telemetry.
    call = {"type": "function_call", "name": "read_file", "call_id": "c", "arguments": "{}"}
    result = {"type": "function_call_output", "call_id": "c", "output": "current source"}
    second = [head, quoted, call, result, tail("new", parts=parts)]
    sent2 = cache.build("chat", second)
    assert sent2 == cache.build("chat", second)  # An uncommitted retry is identical.
    assert quoted in sent2 and call in sent2 and result in sent2
    measured = physical_context({"input": sent2})
    assert len(measured["candidate_payloads"]) == 1
    old_content = sent2[2]["content"]
    if parts:
        assert old_content[2] == first[-1]["content"][1]
        old_payload = json.loads(old_content[1]["text"])
    else:
        old_payload = json.loads(old_content.removeprefix(CURRENT_STEP))
    assert old_payload == {"goal": "task", "instruction": "keep this"}
    cache.commit("chat", second, sent2)
    third = [*second[:-1], {"role": "user", "content": "Thanks"}, tail("")]
    sent3 = cache.build("chat", third)
    assert physical_context({"input": sent3})["candidate_payload_tokens"] == 0
    assert result in sent3


def test_no_candidate_stream_retains_append_only_behavior_and_compaction_resets():
    cache = SessionInputs()
    body = [{"role": "user", "content": "hello"}]
    first = [*body, tail("")]
    sent = cache.build("a", first)
    cache.commit("a", first, sent)
    second = [*body, {"role": "user", "content": "next"}, tail("")]
    sent2 = cache.build("a", second)
    assert sent2[:len(sent)] == sent
    compacted = [{"role": "user", "content": "summary"}, tail("fresh")]
    assert cache.build("a", compacted) == [compacted[0], _labelled(compacted[1])]
    assert cache.build("other-thread", second) == [*second[:-1], _labelled(second[-1])]
