"""Exercise the trial through the real controller and projected request boundary."""
from __future__ import annotations

import json
import threading
from unittest.mock import Mock

import pytest
from candidate_context_helpers import _RecordingEngine, _workspace

from agentd.chat.controller import ChatController
from agentd.chat.storage import ChatThreadStore
from agentd.local_models import LocalModels
from agentd.memory.embedder import Embedder
from agentd.memory.harness import MemoryHarness
from agentd.memory.models import TurnPreparation
from agentd.memory.reranker import Reranker
from agentd.orchestrator.broadcaster import EventBroadcaster
from agentd.retrieval.artifact_client import RetrievalArtifactClient
from agentd.retrieval.candidate_gate import CandidateRelevanceGate
from agentd.retrieval.context_selection import SemanticContextSelector
from agentd.subagents.inbox import InboxItem


def ctrl(root, store, engine, **kwargs):
    return ChatController(workspace_path=str(root), reasoning_engine=engine,
                          thread_store=store, orchestrator=None,
                          broadcaster=EventBroadcaster(),
                          retrieval_client=kwargs.pop("retrieval", RetrievalArtifactClient()),
                          **kwargs)


@pytest.fixture(autouse=True)
def trial(monkeypatch):
    monkeypatch.setenv("CRUCIBLE_CODE_CANDIDATE_TRIAL", "1")
    monkeypatch.setenv("CRUCIBLE_CODE_CANDIDATE_DELIVERY", "automatic")


def responses():
    return [
        {"type": "tool_calls", "thought": "Read auth", "calls": [
            {"id": "r", "tool": "read_file", "args": {"path": "auth.py"}}]},
        {"type": "answer", "thought": "Done", "answer": "ok"},
    ]


@pytest.mark.asyncio
async def test_summary_is_read_on_owning_thread_before_off_loop_retrieval(tmp_path):
    owner = threading.get_ident()

    class Harness(MemoryHarness):
        def anchor_markdown(self, run_id):
            assert threading.get_ident() == owner
            return "auth context"

    _workspace(tmp_path)
    store = ChatThreadStore(tmp_path / "chat.sqlite3")
    tid = store.create_thread(str(tmp_path), title="Thread affinity").thread_id
    engine = _RecordingEngine()
    harness = Harness(enabled=False, compactor=None)
    controller = ctrl(tmp_path, store, engine, memory_harness=harness)
    original = controller._compute_code_candidates
    seen = []

    def compute(query, **signals):
        assert threading.get_ident() != owner
        seen.append(signals)
        return original(query, **signals)

    controller._compute_code_candidates = compute
    await controller.handle_message(tid, "auth", channel_id="c")
    assert seen and seen[0]["summary"] == "auth context"
    assert "code_candidates" in engine.payloads[0]


@pytest.mark.asyncio
async def test_trial_suppresses_visible_reads_and_recovers_them_after_restart(tmp_path):
    _workspace(tmp_path)
    store = ChatThreadStore(tmp_path / "chat.sqlite3")
    tid = store.create_thread(str(tmp_path), title="Trial").thread_id
    engine = _RecordingEngine()
    engine._controller_step_responses = responses()
    await ctrl(tmp_path, store, engine).handle_message(tid, "auth", channel_id="c")
    assert "code_candidates" in engine.payloads[0]
    assert "code_candidates" not in engine.payloads[1]
    assert "auth original" in json.dumps(engine.payloads[1])
    restarted = _RecordingEngine()
    await ctrl(tmp_path, store, restarted).handle_message(tid, "auth", channel_id="c")
    assert "code_candidates" not in restarted.payloads[0]


@pytest.mark.asyncio
async def test_trial_compaction_restores_discovery_without_automatic_source(tmp_path):
    class Compact(MemoryHarness):
        def __init__(self):
            super().__init__(enabled=False, compactor=None)
            self.calls = 0

        async def prepare_turn(self, history, run_id, **kwargs):
            self.calls += 1
            if self.calls == 2:
                return TurnPreparation(history=[{"role": "user", "content": "Compacted auth"}],
                                       compacted=True, evicted_count=2, anchor_version=1)
            return TurnPreparation(history=history)

    _workspace(tmp_path)
    store = ChatThreadStore(tmp_path / "chat.sqlite3")
    tid = store.create_thread(str(tmp_path), title="Compaction").thread_id
    engine = _RecordingEngine()
    engine._controller_step_responses = responses()
    await ctrl(tmp_path, store, engine, memory_harness=Compact()).handle_message(
        tid, "auth", channel_id="c")
    assert "code_candidates" in engine.payloads[1]
    assert "auth original" not in json.dumps(engine.payloads[1])


@pytest.mark.asyncio
async def test_context_selection_happens_before_retrieval_and_only_one_reranker_batch(tmp_path):
    _workspace(tmp_path)
    capability = LocalModels(True)
    capability.mark_ready("reranker")
    capability.mark_ready("embedder")
    embed_calls = []

    def encode(texts):
        embed_calls.append(texts)
        return [[1., 0.] if "auth" in t else [0., 1.] for t in texts]

    select = SemanticContextSelector(Embedder(encoder=encode, local_models=capability), capability)
    scorer = Mock(side_effect=lambda pairs: [.9] * len(pairs))
    gate = CandidateRelevanceGate(Reranker(scorer=scorer, local_models=capability, bounded=True),
                                  capability, cutoff=.1, per_candidate=True)
    client = RetrievalArtifactClient()
    original = client.load_context
    calls = []

    def load(workspace, query, **kwargs):
        calls.append((query, threading.current_thread()))
        return original(workspace, query, **kwargs)

    client.load_context = load
    store = ChatThreadStore(tmp_path / "chat.sqlite3")
    tid = store.create_thread(str(tmp_path), title="Selection").thread_id
    store.set_recap(tid, "auth investigation")
    memory = MemoryHarness(enabled=False, compactor=None)
    memory.anchor_markdown = lambda run_id: "Unrelated invoice discussion"
    engine = _RecordingEngine()
    engine._controller_step_responses = responses()
    await ctrl(tmp_path, store, engine, retrieval=client, candidate_gate=gate,
               context_selector=select, memory_harness=memory).handle_message(
        tid, "auth", channel_id="c")
    assert len(calls) == 1 and calls[0][1] is not threading.main_thread()
    assert "auth investigation" in calls[0][0] and "invoice" not in calls[0][0]
    assert len(embed_calls) == scorer.call_count == 1
    assert "code_candidates" not in engine.payloads[1]


@pytest.mark.asyncio
async def test_rejection_sends_no_catalog_and_does_not_reinsert_explicit_paths(tmp_path):
    _workspace(tmp_path)
    models = LocalModels(True)
    models.mark_ready("reranker")
    scorer = Mock(side_effect=lambda pairs: [0.] * len(pairs))
    gate = CandidateRelevanceGate(Reranker(scorer=scorer, local_models=models, bounded=True),
                                  models, cutoff=.1, per_candidate=True)
    store = ChatThreadStore(tmp_path / "chat.sqlite3")
    tid = store.create_thread(str(tmp_path), title="Reject").thread_id
    engine = _RecordingEngine()
    await ctrl(tmp_path, store, engine, candidate_gate=gate).handle_message(
        tid, "Discuss src/new.py", channel_id="c")
    assert "code_candidates" not in engine.payloads[0] and scorer.call_count == 1


@pytest.mark.asyncio
async def test_mid_turn_user_steering_refreshes_for_new_query(tmp_path, monkeypatch):
    _workspace(tmp_path)
    store = ChatThreadStore(tmp_path / "chat.sqlite3")
    tid = store.create_thread(str(tmp_path), title="Steer").thread_id
    engine = _RecordingEngine()
    engine._controller_step_responses = [
        {"type": "progress", "note": "Investigating auth"},
        {"type": "answer", "thought": "Now invoices", "answer": "ok"}]
    controller = ctrl(tmp_path, store, engine)
    drains = iter([[], [InboxItem(kind="user", text="invoice", wakes=True)], []])
    monkeypatch.setattr(controller, "_drain_main", lambda *args: next(drains, []))
    await controller.handle_message(tid, "auth", channel_id="c")
    assert json.loads(engine.payloads[0]["code_candidates"])["candidates"][0][0] == "auth.py"
    assert json.loads(engine.payloads[1]["code_candidates"])["candidates"][0][0] == "invoice.py"


def test_trial_factory_defaults_to_strict_row_filter_and_respects_local_opt_out():
    env = {"CRUCIBLE_CODE_CANDIDATE_TRIAL": "1", "CRUCIBLE_CODE_CANDIDATE_DELIVERY": "automatic"}
    assert CandidateRelevanceGate.from_env(env, LocalModels(False)) is None
    gate = CandidateRelevanceGate.from_env(env, LocalModels(True))
    assert gate is not None and gate.cutoff == .1 and gate.per_candidate
    gate.local_models.mark_ready("reranker")
    gate.ranker = Reranker(scorer=lambda pairs: [.9, .01], bounded=True)
    rows = [{"path": "a.py"}, {"path": "b.py"}]
    assert gate.filter("code", rows) == [rows[0]]


@pytest.mark.asyncio
async def test_a_change_after_a_read_restores_candidates_in_next_request(tmp_path, monkeypatch):
    from agentd.tools.sources import BuiltinToolSource

    _workspace(tmp_path)
    original = BuiltinToolSource.execute

    async def execute(self, tool, args):
        result = await original(self, tool, args)
        if tool == "read_file" and args.get("path") == "auth.py":
            (tmp_path / "auth.py").write_text("def auth():\n    return 'changed outside'\n")
        return result

    monkeypatch.setattr(BuiltinToolSource, "execute", execute)
    store = ChatThreadStore(tmp_path / "chat.sqlite3")
    tid = store.create_thread(str(tmp_path), title="Changed").thread_id
    engine = _RecordingEngine()
    engine._controller_step_responses = responses()
    await ctrl(tmp_path, store, engine).handle_message(tid, "auth", channel_id="c")
    assert "code_candidates" in engine.payloads[1]
    assert "auth original" in json.dumps(engine.payloads[1])


@pytest.mark.asyncio
async def test_model_readiness_change_replaces_initial_direct_fallback(tmp_path):
    _workspace(tmp_path)
    models = LocalModels(True)
    scorer = Mock(side_effect=lambda pairs: [0.] * len(pairs))
    gate = CandidateRelevanceGate(Reranker(scorer=scorer, local_models=models, bounded=True),
                                  models, cutoff=.1, per_candidate=True)

    class WarmingEngine(_RecordingEngine):
        async def create_controller_step(self, *args, **kwargs):
            result = await super().create_controller_step(*args, **kwargs)
            models.mark_ready("reranker")
            return result

    engine = WarmingEngine()
    engine._controller_step_responses = [
        {"type": "progress", "note": "Investigating"},
        {"type": "answer", "thought": "Done", "answer": "ok"}]
    store = ChatThreadStore(tmp_path / "chat.sqlite3")
    tid = store.create_thread(str(tmp_path), title="Ready").thread_id
    await ctrl(tmp_path, store, engine, candidate_gate=gate).handle_message(
        tid, "auth", channel_id="c")
    assert "code_candidates" in engine.payloads[0]
    assert "code_candidates" not in engine.payloads[1]
    assert scorer.call_count == 1
