from unittest.mock import Mock

import pytest

from agentd.local_models import LocalModels
from agentd.memory.embedder import Embedder
from agentd.retrieval.context_selection import SemanticContextSelector


def selector(encoder, *, ready=True):
    capability = LocalModels(True)
    if ready:
        capability.mark_ready("embedder")
    return SemanticContextSelector(Embedder(encoder=encoder, local_models=capability), capability)


def test_independent_segment_selection_and_cache_only_encodes_changed_context():
    vectors = {"query": [1., 0.], "recap": [1., 0.], "summary": [0., 1.],
               "second query": [0., 1.], "new summary": [0., 1.]}
    encoder = Mock(side_effect=lambda texts: [vectors[text] for text in texts])
    selected = selector(encoder)
    assert selected.select("query", recap="recap", summary="summary") == {"recap": "recap"}
    assert encoder.call_args.args[0] == ["query", "recap", "summary"]
    assert selected.select("second query", recap="recap", summary="summary") == {
        "summary": "summary"}
    assert encoder.call_args.args[0] == ["second query"]
    selected.select("query", recap="recap", summary="new summary")
    assert encoder.call_args.args[0] == ["query", "new summary"]


def test_unavailable_capability_preserves_context_without_model_calls():
    encoder = Mock(side_effect=AssertionError("must not load"))
    selected = selector(encoder, ready=False)
    assert selected.select("query", recap="recap") == {"recap": "recap"}
    encoder.assert_not_called()


def test_failed_embedding_preserves_context_and_stops_retrying():
    encoder = Mock(side_effect=RuntimeError("model failed"))
    selected = selector(encoder)
    assert selected.select("query", recap="recap") == {"recap": "recap"}
    assert selected.select("query", recap="recap") == {"recap": "recap"}
    assert encoder.call_count == 1


def test_trial_and_user_local_model_gates_are_both_required():
    assert SemanticContextSelector.from_env({}, LocalModels(True)) is None
    assert SemanticContextSelector.from_env({"CRUCIBLE_CODE_CANDIDATE_TRIAL": "1"},
                                            LocalModels(False)) is None
    selected = SemanticContextSelector.from_env({"CRUCIBLE_CODE_CANDIDATE_TRIAL": "1",
                                                "CRUCIBLE_CODE_CANDIDATE_DELIVERY": "automatic"},
                                                LocalModels(True))
    assert selected is not None and selected.cutoff == .55


def test_context_is_bounded_and_cache_does_not_grow_without_limit():
    encoder = Mock(side_effect=lambda texts: [[1., 0.] for _ in texts])
    selected = selector(encoder)
    out = selected.select("q" * 5000, recap="r" * 5000, summary="s" * 5000, closing="c" * 5000)
    assert len(out["recap"]) == 400 and len(out["summary"]) == 600
    assert len(encoder.call_args.args[0][0]) == 1600
    for i in range(100):
        selected.select("query", recap=f"recap {i}")
    assert len(selected._cache) == 96


@pytest.mark.parametrize("scores", [[[], []], [[1., 0.]], [[float("nan")], [1.]],
                                   [[0., 0.], [0., 0.]]])
def test_invalid_vectors_do_not_drop_context(scores):
    selected = selector(lambda texts: scores)
    assert selected.select("query", recap="recap") == {"recap": "recap"}
