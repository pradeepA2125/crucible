"""Optional relevance rejection must never turn model unavailability into no results."""
from __future__ import annotations

import json
from unittest.mock import Mock

import pytest
from candidate_context_helpers import _RecordingEngine, _workspace

from agentd.chat.controller import ChatController
from agentd.chat.controller_factory import select_chat_handler
from agentd.chat.storage import ChatThreadStore
from agentd.local_models import LocalModels
from agentd.memory.reranker import Reranker
from agentd.orchestrator.broadcaster import EventBroadcaster
from agentd.retrieval.artifact_client import RetrievalArtifactClient
from agentd.retrieval.candidate_gate import CandidateRelevanceGate

CANDIDATES = [{"path": "src/auth.py", "symbols": [
    {"name": "login", "kind": "Function", "line": 12}], "ranges": [[12, 40]]},
    {"path": "src/cache.py", "symbols": []}]


@pytest.fixture(autouse=True)
def automatic_delivery(monkeypatch):
    monkeypatch.setenv("CRUCIBLE_CODE_CANDIDATE_DELIVERY", "automatic")


def gate(scorer, *, state="ready", cutoff=.1):
    models = LocalModels(state != "disabled")
    if state == "ready":
        models.mark_ready("reranker")
    if state == "unavailable":
        models.fail("reranker", "warmup failed")
    ranker = Reranker(scorer=scorer, local_models=models, bounded=True)
    return CandidateRelevanceGate(ranker, models, cutoff=cutoff)


@pytest.mark.parametrize("state", ["disabled", "loading", "unavailable"])
def test_not_ready_preserves_candidates_and_never_calls_model(state):
    scorer = Mock(side_effect=AssertionError("must not load/run model"))
    assert gate(scorer, state=state).filter("auth", CANDIDATES) is CANDIDATES
    scorer.assert_not_called()


@pytest.mark.parametrize("value", ["", "0", "-1", "1.1", "nan", "inf", "bad"])
def test_default_or_invalid_cutoff_keeps_experiment_off(value):
    assert CandidateRelevanceGate.from_env(
        {"CRUCIBLE_CODE_CANDIDATE_MIN_SCORE": value,
         "CRUCIBLE_CODE_CANDIDATE_DELIVERY": "automatic"}, LocalModels(True)) is None


def test_capability_required_and_shared_user_opt_out_wins():
    env = {"CRUCIBLE_CODE_CANDIDATE_MIN_SCORE": ".0013",
           "CRUCIBLE_CODE_CANDIDATE_DELIVERY": "automatic"}
    assert CandidateRelevanceGate.from_env(env, None) is None
    assert CandidateRelevanceGate.from_env(env, LocalModels(False)) is None
    models = LocalModels(True)
    configured = CandidateRelevanceGate.from_env(env, models)
    assert configured is not None and configured.local_models is models
    assert configured.cutoff == .0013 and not configured.ranker.available


@pytest.mark.parametrize("enabled", [False, True])
def test_factory_wires_experimental_gate_without_loading_a_model(
    tmp_path, monkeypatch, enabled,
):
    monkeypatch.setenv("CRUCIBLE_CHAT_CONTROLLER", "1")
    monkeypatch.setenv("CRUCIBLE_MEMORY_ENABLED", "0")
    monkeypatch.setenv("CRUCIBLE_CODE_CANDIDATE_MIN_SCORE", ".0013")
    models = LocalModels(enabled)
    handler = select_chat_handler(
        workspace_path=str(tmp_path), transport=object(), model="test",
        thread_store=ChatThreadStore(tmp_path / "factory.sqlite3"), orchestrator=None,
        broadcaster=EventBroadcaster(), local_models=models,
    )
    assert (handler._candidate_gate is not None) == enabled
    if enabled:
        assert handler._candidate_gate.local_models is models
        assert handler._candidate_gate.ranker._model is None


def test_threshold_applies_to_catalog_without_pruning_its_graph_neighbors():
    scorer = Mock(return_value=[.1, .00001])
    relevance = gate(scorer)
    assert relevance.filter("find auth", CANDIDATES) is CANDIDATES
    pairs = scorer.call_args.args[0]
    assert all(query == "Current request:\nfind auth" for query, _ in pairs)
    assert "login (Function)" in pairs[0][1]
    assert "12" not in pairs[0][1] and "ranges" not in pairs[0][1]
    scorer.return_value = [.099, .01]
    assert relevance.filter("hello", CANDIDATES) == []


@pytest.mark.parametrize("failure", [RuntimeError("failed"), [float("nan"), .2], [.1]])
def test_failed_or_invalid_inference_passes_through_and_disables_failed_ranker(failure):
    scorer = Mock()
    if isinstance(failure, Exception):
        scorer.side_effect = failure
    else:
        scorer.return_value = failure
    relevance = gate(scorer)
    assert relevance.filter("auth", CANDIDATES) is CANDIDATES
    assert relevance.local_models.state("reranker").state == "unavailable"
    assert relevance.filter("auth", CANDIDATES) is CANDIDATES
    assert scorer.call_count == 1


@pytest.mark.asyncio
@pytest.mark.parametrize("score,delivered", [(0.0, False), (.9, True)])
async def test_controller_uses_gate_without_adding_scores_or_source_to_payload(
    tmp_path, score, delivered,
):
    _workspace(tmp_path)
    store = ChatThreadStore(tmp_path / "chat.sqlite3")
    tid = store.create_thread(str(tmp_path), title="Gate").thread_id
    engine = _RecordingEngine()
    relevance = gate(lambda pairs: [score] * len(pairs))
    controller = ChatController(
        workspace_path=str(tmp_path), reasoning_engine=engine, thread_store=store,
        orchestrator=None, broadcaster=EventBroadcaster(),
        retrieval_client=RetrievalArtifactClient(), candidate_gate=relevance,
    )
    await controller.handle_message(tid, "auth", channel_id="c")
    payload = engine.payloads[-1]
    assert ("code_candidates" in payload) == delivered
    if delivered:
        catalog = json.loads(payload["code_candidates"])
        assert catalog["candidates"][0][0] == "auth.py"
        assert "score" not in payload["code_candidates"]
    assert "auth original" not in json.dumps(payload)


def test_explicit_user_paths_remain_locators_even_when_gate_rejects(tmp_path):
    _workspace(tmp_path)
    controller = ChatController(
        workspace_path=str(tmp_path), reasoning_engine=_RecordingEngine(),
        thread_store=ChatThreadStore(tmp_path / "chat.sqlite3"),
        orchestrator=None, broadcaster=EventBroadcaster(),
        retrieval_client=RetrievalArtifactClient(),
        candidate_gate=gate(lambda pairs: [0.0] * len(pairs)),
    )
    text = controller._compute_code_candidates("Inspect src/new.py")
    assert json.loads(text)["candidates"] == [["src/new.py", [], []]]
