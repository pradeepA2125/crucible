import json

from agentd.context_metrics import physical_context
from agentd.retrieval import candidate_metrics


def test_empty_candidates_have_no_added_payload():
    assert candidate_metrics.payload_measurement("")["tokens"] == 0


def test_named_tokenizer_and_no_character_heuristic_when_available(monkeypatch):
    class Encoder:
        def encode(self, text, **kwargs):
            assert json.loads(text) == {"code_candidates": "candidate text"}
            return [1, 2, 3]
    monkeypatch.setattr(candidate_metrics, "_encoding", lambda: Encoder())
    m = candidate_metrics.payload_measurement("candidate text")
    assert m["tokens"] == 3 and m["method"] == "o200k_base_field_envelope"


def test_failed_optional_tokenizer_is_labeled_heuristic(monkeypatch):
    monkeypatch.setattr(candidate_metrics, "_encoding", lambda: None)
    assert candidate_metrics.payload_measurement("x")["method"] == "chars_div_4_estimate"


def test_physical_retries_each_count_the_actual_candidate_envelope(monkeypatch):
    class Encoder:
        def encode(self, *args, **kwargs):
            return [1, 2, 3]
    monkeypatch.setattr(candidate_metrics, "_encoding", lambda: Encoder())
    body = {"input": [{"role": "user", "content": json.dumps({
        "goal": "task", "code_candidates": "catalog"})}]}
    first, retry = physical_context(body), physical_context(body)
    assert first["candidate_payload_tokens"] == retry["candidate_payload_tokens"] == 3
    assert first["candidate_payloads"][0]["method"] == "o200k_base_field_envelope"
    assert physical_context({"input": [{"content": "no candidates"}]})[
        "candidate_payload_tokens"] == 0


def test_native_labelled_step_counts_string_and_content_parts(monkeypatch):
    from agentd.providers.openai_native import CURRENT_STEP, _labelled

    class Encoder:
        def encode(self, *args, **kwargs):
            return [1, 2, 3]
    monkeypatch.setattr(candidate_metrics, "_encoding", lambda: Encoder())
    payload = json.dumps({"goal": "task", "code_candidates": "catalog"})
    for content in (payload, [{"type": "input_text", "text": payload}]):
        assert physical_context({"input": [_labelled({"role": "user", "content": content})]})[
            "candidate_payload_tokens"] == 3
    # A JSON fragment embedded in ordinary prose is not a controller payload.
    assert physical_context({"input": [{"content": "quote: " + payload}]})[
        "candidate_payload_tokens"] == 0
    assert CURRENT_STEP


def test_message_totals_count_retries_without_calling_filter_savings_task_savings():
    rows = [
        {"layer": "user_turn", "message_id": "m", "thread_id": "t"},
        {"layer": "candidate_filter", "before": {"tokens": 100}, "after": {"tokens": 40}},
        {"layer": "candidate_delivery", "delivered": {"tokens": 20},
         "without_qwen": {"tokens": 70}},
        {"layer": "physical", "candidate_payload_tokens": 20},
        {"layer": "physical", "candidate_payload_tokens": 20},
        {"layer": "reported", "input_tokens": 9000},
        {"kind": "span", "name": "controller.backend_turn", "start_ns": 0, "end_ns": 12000000},
    ]
    result = candidate_metrics.message_measurement(rows)
    assert result["candidate_tokens_all_requests"] == 40
    assert result["candidate_tokens_new_deliveries"] == 20
    assert result["delivery_comparison"]["without_qwen_tokens"] == 70
    assert result["delivery_comparison"]["with_qwen_tokens"] == 20
    assert result["delivery_comparison"]["tokens_removed"] == 50
    assert result["candidate_tokens_per_request"] == [20, 20]
    assert result["filter_catalog_tokens_removed"] == 60
    assert result["filter_catalog_reduction_pct"] == 60
    assert result["provider_input_reports"] == [9000]
    assert result["backend_elapsed_ms"] == 12 and result["completed"]
    assert not candidate_metrics.message_measurement(rows[:-1])["completed"]


def test_index_results_are_distinguished_from_automatic_candidate_fields():
    summary = candidate_metrics.message_measurement([
        {"layer": "index_search", "status": "ok", "result": {"tokens": 200}},
        {"layer": "physical", "candidate_payload_tokens": 0},
        {"layer": "reported", "input_tokens": 25000},
    ])
    assert summary["candidate_tokens_all_requests"] == 0
    assert summary["index_search_calls"] == 1 and summary["index_search_result_tokens"] == 200
    assert summary["provider_input_reports"] == [25000]
