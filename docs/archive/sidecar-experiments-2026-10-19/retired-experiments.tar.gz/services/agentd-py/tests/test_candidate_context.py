"""Per-turn discovery is bounded, source-free and never substitutes for a read."""

from __future__ import annotations

import json
import threading
import time
from types import SimpleNamespace
from unittest.mock import Mock

import pytest
from candidate_context_helpers import _RecordingEngine, _workspace

from agentd.chat.controller import ChatController
from agentd.chat.controller_prompts import build_controller_step_payload
from agentd.chat.storage import ChatThreadStore
from agentd.memory.harness import MemoryHarness
from agentd.orchestrator.broadcaster import EventBroadcaster
from agentd.providers.openai_native import native_actions, to_native_input
from agentd.retrieval import artifact_client
from agentd.retrieval.artifact_client import RetrievalArtifactClient
from agentd.retrieval.candidates import MAX_CHARS, render_candidates, retrieval_query


@pytest.fixture(autouse=True)
def automatic_delivery(monkeypatch):
    """These tests exercise the explicitly enabled automatic discovery path."""
    monkeypatch.setenv("CRUCIBLE_CODE_CANDIDATE_DELIVERY", "automatic")


def controller(tmp_path, store, engine, retrieval, **kwargs):
    return ChatController(workspace_path=str(tmp_path), reasoning_engine=engine,
                          thread_store=store, orchestrator=None,
                          broadcaster=EventBroadcaster(), retrieval_client=retrieval, **kwargs)


def test_candidate_encoding_has_fixed_headers_and_only_links_between_delivered_rows():
    items = [{"path": f"src/file{i}.py",
              "symbols": [{"name": "run", "kind": "Function", "line": 12}],
              "ranges": [[12, 40]], "excerpt": "never send this source"}
             for i in range(20)]
    relationships = [{"from": "src/file0.py", "to": f"src/file{i}.py", "kind": "imports"}
                     for i in range(1, 20)]
    text = render_candidates(items, relationships, query="Trace the flow")
    data = json.loads(text)
    assert data["symbol_columns"] == ["name", "kind", "line"]
    assert len(data["candidates"]) == 8 and len(data["relations"]) == 6
    assert all(0 <= endpoint < 8 for link in data["relations"] for endpoint in link[:2])
    assert len(text) <= MAX_CHARS
    assert "never send this source" not in text and '"name"' in text
    assert text.count('"name"') == 1


def test_candidate_character_budget_never_slices_a_row_or_breaks_references():
    items = [{"path": f"src/file{i}.py", "symbols": [
        {"name": "large" * 300, "kind": "Function", "line": 12}]} for i in range(8)]
    text = render_candidates(items, [], query="Trace")
    data = json.loads(text)
    assert 0 < len(data["candidates"]) < 8 and len(text) <= MAX_CHARS
    assert all(len(row[1][0][0]) == 1500 for row in data["candidates"])


def test_explicit_relative_paths_survive_index_misses_without_reading_or_inventing_locations():
    text = render_candidates([], [], query="Compare src/new.py and ui/view.ts")
    assert json.loads(text)["candidates"] == [["src/new.py", [], []], ["ui/view.ts", [], []]]
    assert render_candidates([], [], query="Visit https://host/src/new.py and ../src/new.py") == ""


def test_recall_query_is_bounded_and_preserves_the_current_request_first():
    text = retrieval_query("Investigate invoices", recap="R" * 5000,
                           summary="S" * 5000, closing="C" * 5000)
    assert text.startswith("Investigate invoices")
    assert text.count("R") == 400 and text.count("S") == 600
    assert len(text) < 3100


def test_candidate_tail_preserves_cache_prefix_and_ignores_retired_context_fields():
    history = [{"role": "user", "content": "Earlier source request"}]
    ctx = {"workspace_path": "/workspace", "retrieval_seed": {"legacy": "huge seed"},
           "source_evidence": {"legacy": "huge manifest"}}
    a = build_controller_step_payload(
        {**ctx, "code_candidates": "first"}, history, [], phase="ACTIVE")
    b = build_controller_step_payload(
        {**ctx, "code_candidates": "second"}, history, [], phase="ACTIVE")
    keys = list(a)
    assert keys.index("code_candidates") > keys.index("conversation_history")
    assert "retrieval_seed" not in a and "source_evidence" not in a
    assert (json.dumps(a).split('"code_candidates"')[0]
            == json.dumps(b).split('"code_candidates"')[0])
    from agentd.chat.controller_prompts import controller_response_schema

    actions = native_actions(controller_response_schema(phase="ACTIVE", anyof=True), "step")
    assert to_native_input(a, actions)[0] == to_native_input(b, actions)[0]


def test_discovery_skips_source_extraction_and_repository_tree(tmp_path, monkeypatch):
    _workspace(tmp_path)
    client = RetrievalArtifactClient()
    monkeypatch.setattr(
        client, "_build_planner_evidence", Mock(side_effect=AssertionError("source")))
    monkeypatch.setattr(artifact_client.os, "walk", Mock(side_effect=AssertionError("tree")))
    context, _ = client.load_context(str(tmp_path), "auth invoice", discovery_only=True)
    assert {row["path"] for row in context.discovery_candidates} == {"auth.py", "invoice.py"}
    assert context.repository_structure == [] and context.file_outlines == {}
    assert not context.planner_evidence.evidence_files and context.file_contents == {}
    empty, _ = client.load_context(str(tmp_path), "nonexistentword", discovery_only=True)
    assert not empty.discovery_candidates and not empty.related_files


class RecordingRetrieval(RetrievalArtifactClient):
    def __init__(self):
        super().__init__()
        self.calls = []

    def load_context(self, workspace_path, goal, **kwargs):
        self.calls.append((goal, kwargs, threading.current_thread()))
        return super().load_context(workspace_path, goal, **kwargs)


@pytest.mark.asyncio
async def test_new_and_existing_chats_use_fresh_per_turn_candidates_without_source(
    tmp_path, monkeypatch,
):
    # The retired opt-in must not reactivate automatic source delivery.
    monkeypatch.setenv("CRUCIBLE_VERIFIED_SOURCE_REUSE_ENABLED", "1")
    _workspace(tmp_path)
    store = ChatThreadStore(tmp_path / "chat.sqlite3")
    tid = store.create_thread(str(tmp_path), title="Discovery").thread_id
    store.set_controller_seed(tid, {"legacy": "pinned source we must not send"})
    engine, retrieval = _RecordingEngine(), RecordingRetrieval()
    for query, expected in (("auth", "auth.py"), ("invoice", "invoice.py")):
        await controller(tmp_path, store, engine, retrieval).handle_message(
            tid, query, channel_id=f"chat:{tid}")
        payload = engine.payloads[-1]
        rows = json.loads(payload["code_candidates"])["candidates"]
        assert rows[0][0] == expected
        assert "original" not in json.dumps(payload)
        assert "retrieval_seed" not in payload and "source_evidence" not in payload
        assert not any(entry.get("origin") == "automatic_source"
                       for entry in payload.get("conversation_history", []))
    assert len(retrieval.calls) == 2
    assert all(call[2] is not threading.main_thread() for call in retrieval.calls)
    assert all(call[1]["discovery_only"] for call in retrieval.calls)
    # Old storage is preserved for non-destructive compatibility; never replayed.
    assert store.get_thread(tid).controller_retrieval_seed == {
        "legacy": "pinned source we must not send",
    }


@pytest.mark.asyncio
async def test_retrieval_uses_recap_summary_and_substantive_answer(tmp_path):
    _workspace(tmp_path)
    store = ChatThreadStore(tmp_path / "chat.sqlite3")
    tid = store.create_thread(str(tmp_path), title="Discovery").thread_id
    store.set_recap(tid, "Investigating auth behavior")
    memory = MemoryHarness(enabled=False, compactor=None)
    memory.anchor_markdown = lambda run_id: (
        "Compacted auth investigation" if run_id == tid else None)
    retrieval, engine = RecordingRetrieval(), _RecordingEngine()
    ctrl = controller(tmp_path, store, engine, retrieval, memory_harness=memory)
    await ctrl.handle_message(tid, "auth", channel_id=f"chat:{tid}")
    await ctrl.handle_message(tid, "continue", channel_id=f"chat:{tid}")
    query, kwargs, _ = retrieval.calls[-1]
    assert query.startswith("continue") and kwargs["current_query"] == "continue"
    assert "Investigating auth behavior" in query and "Compacted auth investigation" in query
    assert "Previous substantive answer: ok" in query
    assert len(json.loads(engine.payloads[-1]["code_candidates"])["candidates"]) <= 8


@pytest.mark.asyncio
async def test_multiple_model_steps_reuse_one_discovery_and_normal_reads_still_deliver_source(
    tmp_path,
):
    _workspace(tmp_path)
    store = ChatThreadStore(tmp_path / "chat.sqlite3")
    tid = store.create_thread(str(tmp_path), title="Read").thread_id
    engine, retrieval = _RecordingEngine(), RecordingRetrieval()
    engine._controller_step_responses = [
        {"type": "tool_calls", "thought": "Read code", "calls": [
            {"id": "read", "tool": "read_file", "args": {"path": "auth.py"}}]},
        {"type": "answer", "thought": "Read", "answer": "ok"},
    ]
    await controller(tmp_path, store, engine, retrieval).handle_message(tid, "auth", channel_id="c")
    assert len(retrieval.calls) == 1 and len(engine.payloads) == 2
    assert engine.payloads[0]["code_candidates"] == engine.payloads[1]["code_candidates"]
    assert "auth original" not in json.dumps(engine.payloads[0])
    assert "auth original" in json.dumps(engine.payloads[1])
    assert not any(entry.get("origin") == "automatic_source"
                   for entry in engine.payloads[1]["conversation_history"])


@pytest.mark.asyncio
async def test_retrieval_failure_preserves_chat_without_stale_candidates(tmp_path):
    store = ChatThreadStore(tmp_path / "chat.sqlite3")
    tid = store.create_thread(str(tmp_path), title="Failure").thread_id
    retrieval, engine = RecordingRetrieval(), _RecordingEngine()
    retrieval.load_context = Mock(side_effect=OSError("index unavailable"))
    await controller(tmp_path, store, engine, retrieval).handle_message(
        tid, "hello", channel_id="c")
    assert "code_candidates" not in engine.payloads[-1]
    assert "source_evidence" not in engine.payloads[-1]


def test_discovery_preserves_real_direction_and_filters_relation_endpoints(tmp_path):
    snapshot = tmp_path / ".crucible/index-snapshot.json"
    snapshot.parent.mkdir()
    snapshot.write_text(json.dumps({
        "workspace_root": str(tmp_path), "generated_at_ms": int(time.time() * 1000),
        "graph": {"nodes": [
            {"id": "auth", "path": "auth.py", "name": "auth.py", "kind": "File"},
            {"id": "cache", "path": "cache.py", "name": "cache.py", "kind": "File"},
        ], "edges": [{"from": "auth", "to": "cache", "kind": "Imports"}]},
    }))
    context, _ = RetrievalArtifactClient().load_context(str(tmp_path), "auth", discovery_only=True)
    text = render_candidates(
        context.discovery_candidates, context.graph_relationships, query="auth")
    data = json.loads(text)
    source, target, kind = data["relations"][0]
    assert data["candidates"][source][0] == "auth.py"
    assert data["candidates"][target][0] == "cache.py" and kind == "imports"


def test_current_request_outranks_old_recap_but_followups_can_use_it(tmp_path):
    _workspace(tmp_path)
    client = RetrievalArtifactClient()
    context, _ = client.load_context(
        str(tmp_path), retrieval_query("invoice", recap="auth " * 80),
        discovery_only=True, current_query="invoice")
    assert context.discovery_candidates[0]["path"] == "invoice.py"
    followup, _ = client.load_context(
        str(tmp_path), retrieval_query("continue", recap="Investigating auth"),
        discovery_only=True, current_query="continue")
    assert followup.discovery_candidates[0]["path"] == "auth.py"


def test_tests_do_not_take_discovery_slots_unless_requested(tmp_path):
    _workspace(tmp_path)
    path = tmp_path / ".crucible/index-snapshot.json"
    snapshot = json.loads(path.read_text())
    snapshot["graph"]["nodes"].insert(0, {
        "id": "test", "path": "tests/test_auth.py", "name": "auth", "kind": "Function",
    })
    client = RetrievalArtifactClient()
    context = client._build_context(snapshot, "auth", 0, str(tmp_path), discovery_only=True)
    assert "tests/test_auth.py" not in context.related_files
    context = client._build_context(snapshot, "test auth", 0, str(tmp_path), discovery_only=True)
    assert "tests/test_auth.py" in context.related_files


def test_semantic_discovery_uses_recall_signals_without_sending_chunk_text(tmp_path):
    _workspace(tmp_path)
    snapshot = json.loads((tmp_path / ".crucible/index-snapshot.json").read_text())

    class Semantic:
        def is_ready(self):
            return True

        def query(self, goal, **kwargs):
            assert "continue" in goal and "Investigating invoices" in goal
            return [SimpleNamespace(score=0.9, chunk=SimpleNamespace(
                path="invoice.py", name="deep_semantic_match", kind="Function",
                line_start=300, line_end=320, text="never emit chunk source"))]

    client = RetrievalArtifactClient(semantic_index=Semantic())
    query = retrieval_query("continue", recap="Investigating invoices")
    context = client._build_context(
        snapshot, query, 0, str(tmp_path), discovery_only=True, current_query="continue")
    text = render_candidates(context.discovery_candidates, context.graph_relationships,
                             query="continue")
    assert json.loads(text)["candidates"][0][0] == "invoice.py"
    assert json.loads(text)["candidates"][0][1][0] == ["deep_semantic_match", "Function", 300]
    assert "never emit chunk source" not in text


@pytest.mark.asyncio
async def test_compaction_does_not_drop_current_candidates_or_trigger_source_delivery(tmp_path):
    from agentd.memory.models import TurnPreparation

    class CompactingMemory(MemoryHarness):
        def __init__(self):
            super().__init__(enabled=False, compactor=None)

        def anchor_markdown(self, run_id):
            return "Investigating auth"

        async def prepare_turn(self, history, run_id, **kwargs):
            return TurnPreparation(history=[{"role": "user", "content": "Compacted history"}],
                                   compacted=True, evicted_count=2, anchor_version=1)

    _workspace(tmp_path)
    store = ChatThreadStore(tmp_path / "chat.sqlite3")
    tid = store.create_thread(str(tmp_path), title="Compaction").thread_id
    engine, retrieval = _RecordingEngine(), RecordingRetrieval()
    await controller(tmp_path, store, engine, retrieval,
                     memory_harness=CompactingMemory()).handle_message(tid, "auth", channel_id="c")
    payload = engine.payloads[-1]
    assert json.loads(payload["code_candidates"])["candidates"][0][0] == "auth.py"
    assert "original" not in json.dumps(payload)
    assert "source_evidence" not in payload
