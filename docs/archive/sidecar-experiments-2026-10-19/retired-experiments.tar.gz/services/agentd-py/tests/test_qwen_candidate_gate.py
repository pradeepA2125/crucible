from __future__ import annotations

import json
from unittest.mock import Mock

import pytest

from agentd.local_models import LocalModels
from agentd.retrieval.candidate_gate import CandidateRelevanceGate
from agentd.retrieval.context_selection import SemanticContextSelector
from agentd.retrieval.qwen_gate import QwenCandidateGate, configured_gate


def test_qwen_factory_is_opt_in_and_respects_user_opt_out():
    env = {"CRUCIBLE_CODE_CANDIDATE_TRIAL": "1", "CRUCIBLE_CODE_CANDIDATE_SCORER": "qwen",
           "CRUCIBLE_CODE_CANDIDATE_DELIVERY": "automatic"}
    models = LocalModels(True)
    gate = CandidateRelevanceGate.from_env(env, models)
    assert isinstance(gate, QwenCandidateGate) and gate._state == "loading"
    assert configured_gate(env, models) is gate
    assert SemanticContextSelector.from_env(env, models) is None
    assert CandidateRelevanceGate.from_env(env, LocalModels(False)) is None
    assert configured_gate({}, models) is None


def test_plain_context_uses_one_batch_and_strict_threshold_without_selector():
    gate = QwenCandidateGate("not-loaded", LocalModels(True))
    gate._state = "ready"
    gate._score = Mock(return_value=[.5, .51, .1])
    rows = [{"path": p} for p in ["one.py", "two.py", "three.py"]]
    assert gate.filter("new topic", rows, recap="old", summary="summary", closing="answer") == [
        rows[1]]
    query, documents = gate._score.call_args.args
    assert json.loads(query) == {"current_request": "new topic", "recap": "old",
                                "summary": "summary", "previous_answer": "answer"}
    assert len(documents) == 3 and gate._score.call_count == 1


@pytest.mark.parametrize("state", ["loading", "unavailable"])
def test_not_ready_preserves_rows_without_loading(state):
    gate = QwenCandidateGate("unused", LocalModels(True))
    gate._state = state
    gate._score = Mock(side_effect=AssertionError("should not run"))
    rows = [{"path": "one.py"}]
    assert gate.filter("query", rows) is rows
    gate._score.assert_not_called()


def test_failed_scoring_preserves_rows_and_stops_retrying():
    gate = QwenCandidateGate("unused", LocalModels(True))
    gate._state = "ready"
    gate._score = Mock(side_effect=RuntimeError("no backend"))
    rows = [{"path": "one.py"}]
    assert gate.filter("query", rows) is rows
    assert gate.status()["state"] == "unavailable"
    assert gate.filter("query", rows) is rows
    assert gate._score.call_count == 1


def test_qwen_background_is_bounded_and_does_not_change_other_model_readiness():
    models = LocalModels(True)
    gate = QwenCandidateGate("unused", models)
    gate._state = "ready"
    gate._score = Mock(return_value=[.9])
    gate.filter("q" * 4000, [{"path": "one.py"}], recap="r" * 4000,
                summary="s" * 4000, closing="c" * 4000)
    q = json.loads(gate._score.call_args.args[0])
    assert [len(q[k]) for k in ["current_request", "recap", "summary", "previous_answer"]] == [
        1600, 400, 600, 400]
    assert models.state("reranker").state == "loading"


def test_disabling_local_models_always_wins_even_after_warmup():
    models = LocalModels(False)
    gate = QwenCandidateGate("unused", models)
    gate._state = "ready"
    gate._score = Mock(side_effect=AssertionError("should not run"))
    rows = [{"path": "one.py"}]
    assert gate.filter("query", rows) is rows
    gate._score.assert_not_called()
