"""No-reranker catalogs preserve discovery metadata and the actual request boundary."""
from __future__ import annotations

import json
from types import SimpleNamespace
from unittest.mock import Mock

import pytest
from candidate_context_helpers import _RecordingEngine

from agentd.chat.controller import ChatController
from agentd.chat.storage import ChatThreadStore
from agentd.local_models import LocalModels
from agentd.orchestrator.broadcaster import EventBroadcaster
from agentd.retrieval.candidate_gate import CandidateRelevanceGate
from agentd.retrieval.candidates import format_catalog, render_candidates
from agentd.retrieval.context_selection import SemanticContextSelector
from agentd.retrieval.qwen_gate import configured_gate


@pytest.fixture(autouse=True)
def automatic_delivery(monkeypatch):
    monkeypatch.setenv("CRUCIBLE_CODE_CANDIDATE_DELIVERY", "automatic")


def decode_rows(text):
    rows = []
    for line in text.splitlines():
        parts = line.split("|", 3)
        if len(parts) == 4 and parts[0].isdigit():
            rows.append([json.loads(cell) for cell in parts[1:]])
    return rows


def test_text_catalog_preserves_all_symbol_range_and_relationship_metadata():
    candidates = [
        {"path": "src/a|b\n.py", "symbols": [
            {"name": "run", "kind": "Function", "line": 10},
            {"name": "Worker", "kind": "Class", "line": 40}],
         "ranges": [[10, 30], [40, 60]], "excerpt": "DO NOT SEND SOURCE"},
        {"path": "src/other.py", "symbols": [], "ranges": []},
    ]
    internal = render_candidates(candidates, [
        {"from": candidates[0]["path"], "to": candidates[1]["path"], "kind": "Calls"}
    ], query="work")
    catalog = format_catalog(internal)
    assert decode_rows(catalog) == json.loads(internal)["candidates"]
    assert '[0,1,"Calls"]' in catalog
    assert "read_file" in catalog and "query_graph" in catalog and "search_semantic" in catalog
    assert "DO NOT SEND SOURCE" not in catalog
    assert format_catalog("") == format_catalog('{"candidates":[]}') == ""


def test_catalog_budget_keeps_complete_rows_and_no_dangling_relationships():
    data = render_candidates([
        {"path": "a.py", "symbols": [], "ranges": []},
        {"path": "b" * 600 + ".py", "symbols": [], "ranges": []},
    ], [{"from": "a.py", "to": "b" * 600 + ".py", "kind": "Imports"}], query="work")
    text = format_catalog(data, max_chars=300)
    assert len(text) <= 300 and decode_rows(text) == [["a.py", [], []]]
    assert "relations[" not in text
    assert format_catalog(data, max_chars=10) == ""


def test_none_explicitly_bypasses_both_local_candidate_models():
    env = {"CRUCIBLE_CODE_CANDIDATE_TRIAL": "1", "CRUCIBLE_CODE_CANDIDATE_SCORER": "none",
           "CRUCIBLE_CODE_CANDIDATE_MIN_SCORE": "0.9",
           "CRUCIBLE_CODE_CANDIDATE_DELIVERY": "automatic"}
    models = LocalModels(True)
    assert CandidateRelevanceGate.from_env(env, models) is None
    assert SemanticContextSelector.from_env(env, models) is None
    assert configured_gate(env, models) is None


@pytest.mark.asyncio
@pytest.mark.parametrize("trial", ["0", "1"])
@pytest.mark.parametrize("mode", ["none", "local_opt_out"])
async def test_disabled_qwen_delivers_top_four_metadata_catalog_and_replaces_each_turn(
    tmp_path, monkeypatch, trial, mode,
):
    monkeypatch.setenv("CRUCIBLE_CODE_CANDIDATE_TRIAL", trial)
    monkeypatch.setenv("CRUCIBLE_CODE_CANDIDATE_SCORER", "none" if mode == "none" else "qwen")
    monkeypatch.setenv("CRUCIBLE_LOCAL_MODELS", "1" if mode == "none" else "0")
    items = [{"path": f"src/module{i}.py", "symbols": [
        {"name": f"entry{i}", "kind": "Function", "line": 1},
        {"name": f"Worker{i}", "kind": "Class", "line": 3}],
        "ranges": [[1, 2], [3, 4]], "excerpt": "DO NOT SEND SOURCE"} for i in range(8)]
    for i in range(8):
        path = tmp_path / items[i]["path"]
        path.parent.mkdir(exist_ok=True)
        path.write_text(f"def entry{i}():\n    pass\nclass Worker{i}:\n    pass\n")
    retrieval = SimpleNamespace(load_context=Mock(return_value=(SimpleNamespace(
        discovery_candidates=items, graph_relationships=[
            {"from": items[0]["path"], "to": items[1]["path"], "kind": "Calls"},
            {"from": items[0]["path"], "to": items[7]["path"], "kind": "Imports"},
        ]), [])))
    gate = SimpleNamespace(filter=Mock(side_effect=AssertionError("must not score")))
    selector = SimpleNamespace(select=Mock(side_effect=AssertionError("must not embed context")))
    store = ChatThreadStore(tmp_path / "chat.sqlite3")
    tid = store.create_thread(str(tmp_path), title="Catalog").thread_id
    engine = _RecordingEngine()
    ctrl = ChatController(
        workspace_path=str(tmp_path), reasoning_engine=engine, thread_store=store,
        orchestrator=None, broadcaster=EventBroadcaster(), retrieval_client=retrieval,
        candidate_gate=gate, context_selector=selector,
    )
    await ctrl.handle_message(tid, "Find entry points", channel_id="c")
    text = engine.payloads[0]["code_candidates"]
    rows = decode_rows(text)
    assert len(rows) == 4
    assert rows[0] == [items[0]["path"], [["entry0", "Function", 1], ["Worker0", "Class", 3]],
                       [[1, 2], [3, 4]]]
    assert '[0,1,"Calls"]' in text and "Imports" not in text
    assert "DO NOT SEND SOURCE" not in text
    await ctrl.handle_message(tid, "Inspect src/module7.py", channel_id="c")
    assert decode_rows(engine.payloads[-1]["code_candidates"])[0][0] == "src/module7.py"
    gate.filter.assert_not_called()
    selector.select.assert_not_called()


@pytest.mark.asyncio
async def test_catalog_still_disappears_after_source_is_visible(tmp_path, monkeypatch):
    from candidate_context_helpers import _workspace

    from agentd.retrieval.artifact_client import RetrievalArtifactClient

    monkeypatch.setenv("CRUCIBLE_CODE_CANDIDATE_TRIAL", "1")
    monkeypatch.setenv("CRUCIBLE_CODE_CANDIDATE_SCORER", "none")
    _workspace(tmp_path)
    store = ChatThreadStore(tmp_path / "chat.sqlite3")
    tid = store.create_thread(str(tmp_path), title="Visible catalog").thread_id
    engine = _RecordingEngine()
    engine._controller_step_responses = [
        {"type": "tool_calls", "thought": "read", "calls": [
            {"id": "r", "tool": "read_file", "args": {"path": "auth.py"}}]},
        {"type": "answer", "thought": "done", "answer": "ok"},
    ]
    ctrl = ChatController(
        workspace_path=str(tmp_path), reasoning_engine=engine, thread_store=store,
        orchestrator=None, broadcaster=EventBroadcaster(),
        retrieval_client=RetrievalArtifactClient(),
    )
    await ctrl.handle_message(tid, "auth", channel_id="c")
    assert decode_rows(engine.payloads[0]["code_candidates"])[0][0] == "auth.py"
    assert "code_candidates" not in engine.payloads[1]
