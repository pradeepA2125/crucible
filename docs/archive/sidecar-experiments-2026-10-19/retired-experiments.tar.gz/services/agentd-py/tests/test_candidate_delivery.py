"""Visibility means current source bytes actually present in the outgoing request."""
from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path
from unittest.mock import Mock

import pytest

from agentd.retrieval.candidate_delivery import CandidateDelivery
from agentd.retrieval.candidates import render_candidates
from agentd.tools.files import _read_file_sync


def catalog(path="code.py", ranges=None, line=12):
    return render_candidates([{"path": path, "symbols": [
        {"name": "work", "kind": "Function", "line": line}],
        "ranges": [[10, 20]] if ranges is None else ranges}], [], query="work")


def read(root: Path, start=1, end=None, *, max_lines=2000):
    output = _read_file_sync(path="code.py", start_line=start, end_line=end,
                             shadow_root=root, max_lines=max_lines, max_chars=100000)
    return {"role": "tool_result", "tool": "read_file", "is_error": output.is_error,
            "content": output.output, "delivered_read": asdict(output.delivered_read)}


@pytest.fixture
def setup(tmp_path):
    (tmp_path / "code.py").write_text("\n".join(f"value{i} = {i}" for i in range(1, 51)))
    compute = Mock(return_value=catalog())
    return CandidateDelivery(tmp_path, "work", compute, lambda: 1), compute, tmp_path


def test_reuse_catalog_but_drop_after_current_visible_read_and_restore_after_eviction(setup):
    delivery, compute, root = setup
    assert delivery.deliver([])
    history = [read(root, 10, 20)]
    assert delivery.deliver(history) == ""
    assert delivery.deliver(history) == ""
    assert delivery.deliver([])
    assert compute.call_count == 1


def test_shadow_no_filter_comparison_uses_the_same_visibility_without_changing_delivery(
    setup, monkeypatch,
):
    from agentd import performance
    from agentd.retrieval.candidate_metrics import payload_measurement
    delivery, compute, root = setup
    records = []
    monkeypatch.setattr(performance, "capturing", lambda: True)
    monkeypatch.setattr(performance, "context_measurement", records.append)
    baseline = render_candidates([
        {"path": "code.py", "symbols": [], "ranges": [[10, 20]]},
        {"path": "other.py", "symbols": [], "ranges": []},
    ], [], query="work")
    delivery.unfiltered_catalog = lambda: baseline
    assert delivery.deliver([read(root)]) == ""
    assert records[-1]["delivered"]["tokens"] == 0
    expected = render_candidates([{"path": "other.py", "symbols": [], "ranges": []}], [],
                                 query="work")
    assert records[-1]["without_qwen"] == payload_measurement(expected)
    assert compute.call_count == 1


def test_partial_and_disjoint_reads_do_not_imply_full_coverage(setup):
    delivery, _, root = setup
    assert delivery.deliver([read(root, 1, 12)])
    assert delivery.deliver([read(root, 10, 15), read(root, 17, 20)])
    assert delivery.deliver([read(root, 10, 15), read(root, 16, 20)]) == ""


def test_graph_only_definition_line_requires_full_file_coverage(setup):
    delivery, compute, root = setup
    compute.return_value = catalog(ranges=[])
    assert delivery.deliver([read(root, 12, 12)])
    assert delivery.deliver([read(root)]) == ""


@pytest.mark.parametrize("case", ["metadata_only", "truncated_content", "summary", "error",
                                  "wrong_revision", "wrong_root", "missing_root"])
def test_incomplete_or_wrong_evidence_never_suppresses_candidates(setup, case):
    delivery, _, root = setup
    entry = read(root)
    if case == "metadata_only":
        entry["content"] = "Previously read code.py"
    elif case == "truncated_content":
        entry["content"] = entry["content"][:100] + "..."
    elif case == "summary":
        entry["role"] = "user"
    elif case == "error":
        entry["is_error"] = True
    elif case == "wrong_revision":
        entry["delivered_read"]["revision"] = "wrong"
    elif case == "wrong_root":
        entry["delivered_read"]["root"] = str(root / "shadow")
    else:
        entry["delivered_read"].pop("root")
    assert delivery.deliver([entry])


def test_read_truncation_uses_delivered_range_not_requested_range(setup):
    delivery, _, root = setup
    assert delivery.deliver([read(root, max_lines=5)])
    assert delivery.deliver([read(root, 10, 50, max_lines=11)]) == ""


def test_current_file_edits_invalidate_coverage_and_refresh_candidates(setup):
    delivery, compute, root = setup
    history = [read(root)]
    assert delivery.deliver(history) == ""
    (root / "code.py").write_text("changed\n" * 50)
    assert delivery.deliver(history)
    assert compute.call_count == 2
    assert delivery.deliver([read(root)]) == ""


def test_restart_reconstructs_coverage_from_history_without_seen_ledger(setup):
    _, _, root = setup
    restarted = CandidateDelivery(root, "work", lambda query: catalog(), lambda: 1)
    assert restarted.deliver([read(root)]) == ""


def test_other_symbol_outside_visible_hint_still_needs_discovery(setup):
    delivery, compute, root = setup
    compute.return_value = catalog(line=30)
    assert delivery.deliver([read(root, 10, 20)])


def test_new_scope_index_and_force_refresh_recompute_once(setup):
    delivery, compute, _ = setup
    revision = [1]
    delivery.snapshot_version = lambda: revision[0]
    delivery.deliver([])
    delivery.deliver([], query="new scope")
    assert compute.call_args.args == ("new scope",)
    revision[0] = 2
    delivery.deliver([])
    delivery.deliver([], refresh=True)
    delivery.deliver([])
    assert compute.call_count == 4


@pytest.mark.parametrize("tool,error,content", [
    ("read_file", True, "File unavailable"),
    ("search_code", False, "No matches found."),
    ("search_semantic", False, "No semantically similar code found."),
])
def test_new_failed_discovery_refreshes_once_not_on_every_step(setup, tool, error, content):
    delivery, compute, _ = setup
    delivery.deliver([])
    result = {"role": "tool_result", "tool": tool, "call_id": "r1",
              "is_error": error, "content": content}
    delivery.deliver([result])
    delivery.deliver([result])
    assert compute.call_count == 2


def test_filtered_relationships_remap_indices_and_do_not_resurrect_explicit_paths(setup):
    delivery, compute, root = setup
    compute.return_value = render_candidates([
        {"path": "code.py", "symbols": [], "ranges": [[10, 20]]},
        {"path": "other.py", "symbols": [], "ranges": []},
    ], [{"from": "code.py", "to": "other.py", "kind": "imports"}], query="work")
    delivery.query = "Read src/code.py"
    data = json.loads(delivery.deliver([read(root)]))
    assert data["candidates"] == [["other.py", [], []]]
    assert "relations" not in data
