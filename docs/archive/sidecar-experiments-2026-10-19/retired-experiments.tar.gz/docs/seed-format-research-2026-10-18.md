# Seed representation formats: research and local comparison

> Superseded for the chat path by [candidate-only per-turn retrieval](candidate-only-retrieval-2026-10-18.md). This document preserves the earlier implementation and measurements.

18 October 2026. Research only: no application code, live backend configuration or
provider requests changed. Public reference codecs were installed under `/tmp`
with lifecycle scripts disabled. Workspace content was not sent to their projects
or any online format playground.

## Finding

The new seed removes duplicated *content*, but its object-per-symbol JSON still
repeats field names. Lossless schema-once encoding is a useful next experiment.
On the measured seeds, ordinary minified JSON is competitive with TOON, while
schema-once JSON and TRON save more. Fewer characters alone do not establish fewer
tokens, and exact codec round trips do not establish model comprehension.

## Primary-source research

- [TOON specification and reference implementation](https://github.com/toon-format/toon):
  lossless JSON-data serialization, using indentation and column headers for
  uniform records. It can compact symbol tables without dropping fields.
- [TOON's own benchmarks](https://toonformat.dev/guide/benchmarks): its prominent
  savings figures primarily compare against formatted JSON. Its mixed-structure
  token suite includes cases where minified JSON is smaller. These are project
  benchmarks, not results for our harness or configured model.
- [TRON reference implementation](https://github.com/tron-format/tron-javascript):
  factors repeated object structures into reusable class declarations and value
  instances. This applies naturally to repeated symbol records.
- [Notation Matters, June 2026 revision](https://arxiv.org/html/2605.29676v2): tests
  input and output substitution separately across four agentic benchmarks and
  five open-weight model configurations. Results show model/workload-dependent
  token and accuracy tradeoffs; unfamiliar generated tool-call formats can cause
  parsing failures. This supports evaluating input representation independently
  while retaining existing JSON/native action outputs. It does not establish an
  accuracy change for Crucible's current provider.
- [TOON vs JSON generation study](https://arxiv.org/abs/2603.03306): distinguishes
  generation from comprehension and identifies the overhead of teaching a format
  as a cost that can erase small-payload savings.
- [Microsoft LLMLingua](https://github.com/microsoft/LLMLingua): removes selected
  prompt tokens using a smaller model. This is lossy compression, unlike a
  reversible serialization. It is not the proposed treatment for code bytes,
  locations, freshness metadata or behavioral requirements.

CSV/TSV tables can remove repeated keys for flat rows, but our complete seed also
has nested ranges, optional fields and multiline source hints. A collection of
tables plus a manifest is possible; a single naive CSV conversion would change
the data model. YAML's readability does not imply token savings. These are
engineering fit assessments rather than a claim of universal model preference.

## Same-data local measurements

Input: the eight existing seed variants from the seed-restructure comparison:
four contexts, each with verified delivery enabled and disabled. All fields and
values, including usage/freshness guidance, ranges, diagnostics and omission
counts, are retained. The three broad contexts were captured from one local
snapshot using graph-only retrieval; the recorded context used original hybrid
evidence. Formatting does not improve the relevance or truth of those inputs.

Tokenizer: local `o200k_base`, not verified as the provider's authoritative
tokenizer. Baseline: actual ordinary `json.dumps(seed)` style used by the current
native seed serialization, **not pretty-printed JSON**. Alternative formats include
a brief reading legend; schema-once formats also include their column definitions.
No LLM comprehension, task-success or whole-task usage evaluations were run.

Codecs: official `@toon-format/toon` **4.4.0**, official `@tron-format/tron`
**0.1.3**, PyYAML **6.0.3**, and local reversible schema-once transformations.

Estimated tokens with verified delivery enabled:

| Representation | Recorded request | Controller/provider/edit | Index/retrieval/freshness | Team coordination |
|---|---:|---:|---:|---:|
| Current seed JSON | 3,030 | 4,496 | 4,434 | 3,838 |
| Minified JSON | 2,538 | 3,757 | 3,688 | 3,195 |
| YAML | 3,147 | 4,528 | 4,488 | 3,854 |
| TOON, comma-separated | 2,544 | 3,699 | 3,609 | 3,141 |
| TOON, tab-separated | 2,613 | 3,792 | 3,685 | 3,227 |
| TRON | 2,221 | 3,253 | 3,164 | 2,823 |
| Schema-once minified JSON | 2,230 | 3,264 | 3,184 | 2,809 |
| Schema-once JSON plus relationship file IDs | 2,371 | 3,106 | 2,993 | 2,745 |

Compared with current seed JSON, schema-once JSON saves **26.4–28.2%**, TOON
**16.0–18.6%**, and TRON **26.4–28.6%** on these four cases. File IDs improve the
relationship-heavy broad samples, but make the recorded case larger than the
same schema-once format without IDs. That recorded seed has no relationship
table to amortize ID definitions. Tab delimiters did not help this tokenizer/data.

Across all eight cases, including source-hint compatibility mode, savings are
smaller. Per-case results, legends, embedding overhead and codec versions are in
[measurements.json](validation/2026-10-18-seed-format-research/measurements.json).
Raw seeds and rendered examples remain in ignored local scratch files.

## Representation sketch

Instead of repeating `name`, `kind` and `line` for every symbol, declare them once:

```json
{
  "symbol_columns": ["name", "kind", "line"],
  "candidates": [
    {
      "path": "services/agentd-py/agentd/chat/controller.py",
      "symbols": [["handle_message", "Method", 770]],
      "ranges": [[768, 773]]
    }
  ]
}
```

This is a format sketch, not an enabled seed version. Full transformations retain
the other seed fields. The experiment preserves nonuniform symbol records as
objects instead of guessing missing columns; uniform records become rows.
Relationships similarly use one column declaration. The ID variant adds IDs to
candidates while retaining full candidate paths, then uses IDs only in relationship
rows. It does not change the `read_file` argument contract.

## Integration implications

1. Keep canonical seed objects and source-validation metadata internally. Render
   a versioned model-facing representation when constructing the request.
2. Measure the final transport. The native route currently JSON-serializes the
   workspace/seed head. Simply replacing the seed object with a TOON/TRON string
   causes another layer of newline/quote escaping. For the recorded example,
   TOON's seed-head cost including its legend is 2,638 estimated tokens with naive
   embedding, compared with 2,544 standalone. TRON similarly rises to 2,332.
   The outer HTTP JSON envelope is a different layer and is not model text.
3. A structured schema-once JSON representation avoids introducing another
   non-JSON codec. Minification still needs an actual serializer change: making
   a minified string and then JSON-encoding it again is not equivalent.
4. Preserve reading legends, column headers, optional-value distinctions, exact
   source text, omission counts and schema versions. Keep verified source bodies
   and tool-call outputs in their existing representation during the first test.
5. Pin representation selection per new chat. Do not re-encode an existing pinned
   prefix on every turn. Any file IDs must remain stable, and the model must map
   them back to full paths for existing tools; ID confusion is an evaluation risk.

## Validation and recommendation

All eight seeds round-trip exactly through each of six alternative codec settings:
YAML, TOON comma/tab, TRON, schema-once JSON and schema-once JSON with IDs. Nine
additional TOON/TRON round trips cover delimiters, escaping, multiline strings,
Unicode and JSON scalar types. That verifies data preservation by the codecs,
not the model's ability to use the representation accurately.

Recommended next experiment: **minified JSON versus schema-once minified JSON**,
with the current representation as control. Add TRON as a reference challenger;
make file IDs a separate arm rather than a blanket default. Test narrow lookups,
vague multi-file tracing, exact tool-path selection, graph direction, omitted
content, freshness/fallback reads and accepted multi-file edits. Keep model/effort
and cache conditions fixed and count complete-task usage and failures.

For the recorded seed, schema-once JSON saves another roughly **800 tokens** beyond
the newly restructured seed. Against that request's approximately 24k reconstructed
input, that is about **3.3% additional initial-input savings**, not 26% of the whole
request or session. Nothing here fixes questionable graph edges; graph correctness
is a separate issue from how compactly those edges are represented.

## Follow-up: tool catalog plus seed

The complete 57-tool prompt catalog was also encoded using both reference codecs.
Both decode back to the original definitions exactly, including argument schemas.
A 31-token explanation explicitly retains the existing JSON/native action output
contract. Native controller action schemas are not converted.

| Component | Current | TOON | TRON |
|---|---:|---:|---:|
| Prompt tool catalog, including format explanation | 7,972 | 8,700 | 7,216 |
| Recorded new seed, including format explanation | 3,030 | 2,544 | 2,221 |
| Combined | 11,002 | 11,244 | 9,437 |

TRON on both saves **1,565 estimated tokens (14.2% of those two components)**.
Holding other request content fixed, the approximately 24,239-token reconstructed
first request would become **22,674 (6.5% smaller)**. Using TRON for the catalog
and schema-once JSON for the seed gives nearly the same result: 1,556 tokens saved.
TOON on both increases the combined payload by 242 tokens. The catalog is already
compact JSON, and its heterogeneous nested schemas do not benefit like uniform
symbol records do. No model tool-call correctness test or new provider measurement
has been run. Source/tool-result metadata is unchanged by these projections.

Counts and conditions are in
[catalog-measurements.json](validation/2026-10-18-seed-format-research/catalog-measurements.json).

## Follow-up: seed plus actual source preparation

To distinguish seed size from the full code-context contribution, current source
was prepared locally for the three captured broad cases using the real reader,
source selector and native history conversion. Source history started empty and
the automatic source-entry budget was 16,000 serialized characters. No LLM was
called and no live backend was restarted. Seed sizes below use the proposed
schema-once/minified representation; source messages and their manifest retain
the current delivery representation, including hashes and wrappers.

| Case | Complete compact seed | Source manifest | Delivered source + read wrappers | Combined estimate |
|---|---:|---:|---:|---:|
| Recorded tiny-function request | 2,230 | 325 | 166 | 2,721 |
| Broad controller/provider/edit tracing | 3,264 | 2,687 | 3,244 | 9,195 |
| Broad indexing/retrieval/freshness | 3,184 | 2,279 | 3,509 | 8,972 |
| Broad team coordination | 2,809 | 1,812 | 3,443 | 8,064 |

The first row reuses the captured request's original source delivery. The other
rows read current working files against the captured discovery hints. Candidates,
relationships and repository orientation are already included in the seed column;
they must not be added again. Manifest and source-entry wrapper metadata are
different contributions and are counted once each. These independent token sums
are approximate because framing/boundaries can alter final tokenization.

Broad cases omitted some ranges at the source-entry budget, so the totals do not
establish that sufficient evidence was delivered to finish those tasks. More tool
reads can add context later. The manifest alone costs 1.8–2.7k estimated tokens
here; the source-body budget does not cap this metadata. Further metadata encoding
has not been applied or evaluated. Other instructions, tool catalogs and native
schemas are outside this table. Counts are in
[source-delivery-totals.json](validation/2026-10-18-seed-format-research/source-delivery-totals.json).
