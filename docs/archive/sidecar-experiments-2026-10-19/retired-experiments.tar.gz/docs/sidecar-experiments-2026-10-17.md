# Sidecar experiments and implementation decisions

Date: 2026-10-17. Baseline: `986cdbd5430faf60f3cb065dc24fb378c1b5db54`.
This follows the [team architecture review](superpowers/specs/2026-10-17-reliable-code-intelligence-sidecar-review.md), with executable counterexamples and a paired model trial.

Follow-up: [verified source reuse experiments](sidecar-source-reuse-experiments-2026-10-17.md) test the next proposal below, with provider-reported usage and edit/compaction counterexamples.

**Decision:** keep the targeted index lifecycle fixes. Keep automatic per-request evidence delivery experimental and **off by default**: it delivered the right context, but did not reduce exploration in the small live trial. No indexer replacement or general backend abstraction was introduced. The running extension/backend was not restarted or upgraded.

## Reproductions and fixes

| Case | Observed before | Changed behavior and validation |
|---|---|---|
| Failed TypeScript reparse | Partial new symbols/calls entered the existing graph despite a parse error | Parse into a separate per-file graph; commit only on success. Compare nodes, edges and pending-call count with the last good graph. |
| Successful reparse after deleting a function/import/call | Removed symbols and old relationships remained | Replace file-owned content rather than continually upserting. Preserve incoming relationships to surviving IDs; remove incident edges to deleted IDs. |
| File deletion immediately after a recent watcher event | Debounce suppressed cleanup; published graph retained deleted source | Process removal before debounce; remove file-owned nodes, incident edges and pending calls. Assert the published snapshot is empty in the single-file fixture. |
| Directory deletion | Extension filtering skipped the directory event and retained descendant source | Remove known graph/tracked paths under the deleted directory. |
| Rename | Old path remained alongside the new path | Reconcile the missing old path, then index the existing new path. |
| Canonical watcher path versus configured workspace alias | An event under the physical path could create a second graph entry and leave the original indexed path stale | Map watcher paths into the bootstrap workspace namespace, including deleted paths. A symlink-based regression failed before this additional fix and passes afterward. |
| Failed watcher parse | Existing graph was changed and a failure warning was not published promptly | Preserve last-good file data, publish a warning, and clear it after a successful repair. A new snapshot timestamp alone still does not certify every file is current. |
| Deleting the last semantic source file | Early return reported zero chunks while old chunks remained stored | Run removal reconciliation even when the current source set is empty. |
| Embedding failure during an update | Old chunks were deleted before the embedder failed | Prepare all embeddings and validate vector count before destructive storage calls. |
| Semantic storage deletion failure | Error was logged and the build could still report success | Propagate the failure so callers do not acknowledge a successful generation update. |

The first four service lifecycle fixtures were also run against an isolated copy of the original Rust source, with no product changes to that baseline: **0/4 passed**. The changed implementation passes all four. The parser and semantic failures above were observed as failing new regression tests before their corresponding fixes.

Additional protection checks cover incoming edges to unchanged IDs, shared external targets, endpoint closure after deletion, and removal of an imported file stub whose target never parsed successfully. The semantic fault tests use an in-memory storage double and injected embedding failures; they do not establish LanceDB transaction guarantees.

Raw Rust baseline output: [rust-baseline.txt](experiments/2026-10-17-sidecar/rust-baseline.txt).

The native macOS watcher was also exercised with the built binary and temporary source files: bootstrap, successful reparse, failed-parse preservation, repair, rename and directory removal all passed. This ran outside the restricted sandbox, which did not deliver source-change notifications in the initial probe. [Native results](experiments/2026-10-17-sidecar/native-watch.json) and [reproducible runner](../services/agentd-py/experiments/sidecar_watch_smoke.py). Updates are spaced in this smoke test; it does not validate rapid-modify coalescing.

## Request delivery experiment

The optional path reuses the existing retriever. After the first seed, each user request selects evidence on a worker thread and appends it to conversation history as `retrieval_refresh`. It does not rewrite the pinned seed or repeat the repository tree. It includes the query, snapshot timestamp/age, selected files/symbols, existing excerpts/outlines, warnings, and explicit unverified source/semantic alignment.

Accepted edits now append a structured invalidation naming touched paths. It accurately says graph results can lag indexing; the previous note called graph tools always current.

Six chat delivery checks pass:

- Related and different follow-up requests, each with and without a controller restart: current selected excerpts reach the controller payload, while the stored seed remains unchanged.
- Default-off behavior preserves the existing path.
- A failed opt-in retrieval produces an unavailable result and leaves the chat operational.

No graph tool calls are needed for these delivery checks. These are integration checks of delivery, not proof a model will use the evidence.

Opt in locally with `CRUCIBLE_REQUEST_RETRIEVAL_ENABLED=1`; unset it or set `0` to retain the default. The first request continues using its initial seed; notice-only turns do not trigger a new request bundle. Historical seed and appended evidence remain subject to existing compaction behavior.

## Live model trial

Used `gpt-6.1-sol` with Crucible's selected ChatGPT registration, without printing/copying credentials into results. Each arm used an isolated temporary two-file repository and chat. Only `read_file`, `search_code`, and `list_directory` were available; no graph tool, shell command, network tool, delegation, or source editing was offered to the model.

Each chat asked three questions with exact fixture answers:

1. Initial request: `login_timeout()` returns **17** in `auth.py:2`.
2. Different request: `invoice_retry_limit()` returns **73** in `billing.py:2`.
3. External edit, with the graph intentionally unchanged: the function now returns **91** in `billing.py:2`.

Ran baseline → request evidence at low effort, reversed the order at low effort, and ran another pair at high effort. This produced **18 completed question turns**, nine per arm.

| Aggregate across the three paired runs | Baseline | Request evidence |
|---|---:|---:|
| Expected integer returned | 9/9 | 9/9 |
| Model calls | 18 | 18 |
| Model-requested `read_file` calls | 9 | 9 |
| Sum of serialized logical user-payload characters across calls | 75,195 | 102,489 |

All answers also named the correct source file/line. In every case the model requested a file read before answering, including when a retrieval excerpt already contained the answer. The extra-bundle arm sent **36.3% more logical payload characters**, with no observed reduction in model calls or file reads. This held in both effort settings and both low-effort run orders.

**These are not billed token counts.** Logical character sums exclude system/schema input and do not account for provider serialization, prefix caching, native session reuse or reasoning tokens. Recorded timings are descriptive, not a latency benchmark.

The repositories were deliberately tiny; the questions were read-only, not implementation or impact-analysis tasks. No memory compaction, child-agent reuse, real LSP, or embedding model ran in these trials. Retrieval used the graph/keyword fallback. Existing hybrid-retrieval tests still pass, but this experiment does not benchmark embedding quality or the full production harness.

Raw results, model/effort settings and source hashes: [agent-trials.json](experiments/2026-10-17-sidecar/agent-trials.json).
Reproducible runner: [sidecar_request_evidence.py](../services/agentd-py/experiments/sidecar_request_evidence.py). It requires explicit `--live`, a model and output path; multiple signed-in registrations require explicit account selection.

## Validation

- Full Rust suite: **56 passed**, including existing parser, resolver, CLI, ignore, snapshot, LSP and backend authentication tests. Local mock-server tests needed loopback socket access outside the restricted sandbox.
- Focused Python retrieval/controller/history/native-provider suite: **68 passed**; eight workspace-specific reachability cases skipped because their fixture snapshot is absent, plus the semantic integration module skipped because LanceDB is not installed.
- New semantic lifecycle tests run without optional ML dependencies or model downloads.
- Ruff passes on changed controller/lifecycle code, new tests and the experiment runner. `artifact_client.py` retains the same 17 pre-existing lint findings, with no new findings.
- `git diff --check` passes. Existing unrelated user changes were left in place.

## What to do next

1. **Test source reuse through the existing read observer.** Deliver exact ranges with the current file hash and workspace identity, distinguish actual source bodies from outlines, and reuse them only while those bytes remain visible to the provider. Invalidate after edits and after compaction removes the source. The model's repeated reads are observed; missing trust/provenance as their cause is a hypothesis requiring an ablation.
2. **Deliver a delta when evidence changes or expands.** Preserve the stable seed, but avoid adding the same full bundle on every turn. Do not suppress a needed read using a persisted summary or an old evidence ID. Compare a small verified-source bundle against both the baseline and this unverified-bundle prototype.
3. **Use larger implementation and dependency fixtures.** Include a relevant file absent from keyword top results, ambiguous symbols, incoming dependents, topic switches, external edits, compaction and an agent that never calls `query_graph`. Score correct edits and missed dependencies before interpreting call counts as savings.
4. **Finish lifecycle guarantees before making stronger freshness claims.** Semantic delete/add remains non-transactional: an insertion failure or concurrent query can still see incomplete storage. Rapid modify events still use a dropping debounce; durable/coalesced pending work is not implemented. Changed symbol IDs still need affected-caller resolution. Shadow deletion tombstones, all-language ownership, index/source hashes, explicit generation states and graph path/truncation delivery remain outstanding.

This iteration demonstrates improvement on the reproduced lifecycle failures. It does **not** demonstrate reduced agent token spend or general task-quality improvement from automatic retrieval. That is why the lifecycle fixes are retained and the delivery prototype is disabled by default.
