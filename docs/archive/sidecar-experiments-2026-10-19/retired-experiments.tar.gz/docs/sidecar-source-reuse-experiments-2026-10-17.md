# Verified source reuse: implementation and experiments

Date: 2026-10-17. Branch: `codex/sidecar-reliability-experiments`.
Completed follow-up: [combined experiment-set findings](sidecar-experiment-set-results-2026-10-17.md), including complete-function selection, shared budget, moved source and test-scored implementation trials.
Follows [the first experiment](sidecar-experiments-2026-10-17.md), which found that appending unverified retrieval bundles did not reduce model-requested reads.

**Result:** verified source delivery reduced model round trips when the selected ranges contained the answer. It retained correct behavior after external edits and compaction. When ranges omitted the answer, the model correctly requested additional source; that case consumed more input and saved no calls. Both delivery experiments remain **off by default**. The running extension/backend was not upgraded, restarted or reconfigured.

## What changed

- `CRUCIBLE_VERIFIED_SOURCE_REUSE_ENABLED=1` opts the chat controller into the experiment. It takes precedence over the previous `CRUCIBLE_REQUEST_RETRIEVAL_ENABLED` prototype.
- The existing hybrid retriever selects bounded file excerpts and symbol snippets. Their ranges are discovery hints, not a claim the indexed source is current. Overlapping/adjacent ranges are merged by file.
- Immediately before a model request, **after memory compaction**, the harness executes the existing `read_file` through the tool registry. This preserves its path checks, workspace leases, bounded reads, file hashes and existing read observer. A new parallel read-proof system was not introduced.
- The outgoing history receives a source body with the existing `DeliveredRead` metadata: canonical workspace root/path, SHA256 of the complete file, exact delivered range, total lines and truncation reason. A tail manifest tells the model these are actual source reads it can use for grounding.
- Unchanged source is reused only if the outgoing history still contains every needed numbered line, with matching bytes, root, revision and coverage. A saved marker, a summary, or a previously stored raw segment cannot satisfy reuse. The body is delivered again after compaction removes it.
- An external write changes the hash even if the file size and mtime are unchanged. Changed source gets a new body and hash. Unknown hashes, outside-root symlinks, failed reads and unavailable paths do not get validated entries. The manifest explicitly invalidates earlier source for unavailable selected paths.
- The frozen initial seed is preserved. A different request gets new candidate selection; notice-only turns do not automatically read source. Existing model tools remain available for missing ranges and other evidence.

This moves selected source reads from a model-requested round trip into the harness. It **does not eliminate filesystem reads**: revalidation performs real bounded reads before each model request, including reuse. Retrieval itself can also read source while selecting evidence; that I/O is additional to the manifest's backend-read count.

The new helper is [source_reuse.py](../services/agentd-py/agentd/retrieval/source_reuse.py). Integration lives in the existing controller, loop and prompt payload builder. The [runner](../services/agentd-py/experiments/sidecar_request_evidence.py) now records provider usage, supports the third arm, real compaction, longer files and functions whose return falls outside the automatic range.

## Experiment design

Used `gpt-6.1-sol`, through Crucible's selected ChatGPT registration, with explicit low/high reasoning effort. Each arm used a separate temporary synthetic workspace and chat. Only read/search/list tools were available. No shell, graph tools, delegation, web tools or source edits were offered to the model. Source was changed externally by the fixture.

The compared arms were the existing baseline, the previous unverified request bundle, and verified source delivery. Scoring checks the exact expected integer and source location. All **45 completed question turns** returned both correctly.

| Run | Effort and order | Questions per arm |
|---|---|---:|
| Smoke | Low; baseline → request bundle → verified source | 3: initial, different request, external edit |
| Extended | High; verified source → request bundle → baseline | 5: initial, different request, unchanged follow-up, external edit, compaction |
| Longer file | High; baseline → verified source → request bundle | Same 5; function starts after 300 comment lines |
| Missing range | High; verified source → baseline | 3; function has 40 `pass` lines before its return, beyond the automatic excerpt |

Compaction uses the real `Compactor` to evict the source bodies, with a deterministic summary containing an obsolete invoice value of 73. The current source returns 91. A separate controller integration test also exercises injection after the controller's own memory harness compacts. These do not benchmark model-generated summaries or the full production memory configuration.

## Measured results

Model-requested reads exclude automatic harness reads. Input tokens below are the provider's reported input across completed calls, including cached input. Uncached input is reported input minus the provider's reported cached tokens.

| Run / arm | Correct | Model calls | Model-requested reads | Input tokens | Cached input | Uncached input |
|---|---:|---:|---:|---:|---:|---:|
| Smoke / baseline | 3/3 | 6 | 3 | 47,831 | 37,120 | 10,711 |
| Smoke / request bundle | 3/3 | 6 | 3 | 49,923 | 35,328 | 14,595 |
| Smoke / verified source | 3/3 | 3 | 0 | 22,290 | 13,696 | 8,594 |
| Extended / baseline | 5/5 | 9 | 4 | 70,935 | 49,536 | 21,399 |
| Extended / request bundle | 5/5 | 9 | 4 | 75,196 | 55,168 | 20,028 |
| Extended / verified source | 5/5 | 5 | 0 | 37,706 | 19,712 | 17,994 |
| Longer file / baseline | 5/5 | 9 | 4 | 71,525 | 51,968 | 19,557 |
| Longer file / request bundle | 5/5 | 9 | 4 | 75,872 | 61,184 | 14,688 |
| Longer file / verified source | 5/5 | 5 | 0 | 38,468 | 19,968 | 18,500 |
| Missing range / baseline | 3/3 | 6 | 3 | 50,170 | 38,784 | 11,386 |
| Missing range / verified source | 3/3 | 6 | 3 | 58,231 | 44,288 | 13,943 |

In the longer-file run, verified source reduced model calls from **9 to 5** and total reported input by **46.2%** relative to baseline. Uncached input fell only **5.4%**. The request-bundle arm had fewer uncached tokens than verified source in that run despite needing more model calls. Cache variability therefore materially affects any cost conclusion. These figures establish neither billing savings nor a general percentage token reduction.

Across the first three runs, verified source answered directly in **13/13 turns**, with 13 model calls versus baseline's 24. It performed 14 automatic validation reads across those turns; one request selected two disjoint ranges. The unchanged follow-up reused source without appending its body again. After an external edit, it appended current source. After compaction, it restored the missing body rather than trusting the old summary.

The missing-range run is a useful counterexample: verified source still needed a model-requested read in **3/3 turns**, used six model calls like baseline, and increased total reported input by **16.1%**. Automatic validation also continued on the second model request. We should improve source selection before general rollout; reading irrelevant or insufficient ranges is overhead.

No prompt or guard forces the model to avoid reads. No read requests were intercepted or replaced with a refusal. Direct answering was the model's behavior after receiving actual source and explicit validation metadata. Conversely, the missing-range result shows it still obtained additional source when necessary.

## Selection defect found along the way

An executable longer-file check initially failed: a file-name match anchored its file excerpt at line 1, hiding a relevant function at line 201. The existing payload also contained a bounded symbol snippet, but the first prototype ignored that selection signal. The new candidate builder includes those existing symbol-snippet ranges and merges overlaps. The check now passes. This fixes selection within the experimental delivery path; it does not change the baseline retriever's scoring or claim complete function extraction.

## Validation and limits

- **17 new source-reuse tests pass**, including matching body bytes/ranges, native provider serialization, metadata-only remnants, incomplete bodies, unknown hashes, wrong roots, same-mtime writes, deletion, read permissions, outside-root symlinks, read-observer stale-edit checks, restart, deeper matched symbols, real compaction and the controller's integrated compaction path.
- The focused Python suite passes **145 tests** across retrieval, source reads, write tracking, stale-edit guards, memory compaction, controller history/payloads, native serialization and prompt goldens.
- Ruff passes on all code introduced/changed in this iteration. `git diff --check` passes. No additional Rust changes were made in this iteration.
- The low-effort smoke and first extended run preceded the symbol-range selection improvement; their two-line files made the selection difference immaterial. The longer-file and missing-range runs used the improved candidate builder.

This remains a prototype. Important limits:

1. **Selection quality:** indexed symbol positions may be stale; a freshly hashed excerpt certifies its bytes, not that the hinted range still contains the intended function. There is no current-syntax re-resolution or complete-function guarantee.
2. **Context headroom:** automatic bodies are appended after compaction and are individually bounded by existing reads, but no new aggregate provider-aware admission budget was added. Many selected ranges could add substantial input.
3. **Freshness races:** hashes describe the bytes read before a request. The filesystem is not locked for the duration of model inference. Existing stale-edit checks remain necessary; repository-wide coherent source/index generations are not implemented.
4. **Scope:** tests cover direct read-only questions, not complex edits, impact completeness, code review, shadow overlays, child-agent source inheritance or production memory-v2 behavior. These live trials used graph/keyword fallback, without an embedding model.
5. **Provider visibility:** reuse checks the post-compaction outgoing history, and a native serialization test verifies that bodies/hashes survive conversion. Future provider-specific truncation after that boundary must invalidate reuse; this is not a generic final-wire visibility manifest for every provider.
6. **Partial deltas:** unchanged covered ranges are not repeated. If only part of a requested range is already visible, the prototype conservatively appends the requested range again; it does not yet subtract overlapping lines into minimal deltas.

## Decision and next step

Keep `CRUCIBLE_VERIFIED_SOURCE_REUSE_ENABLED` unset by default. The result supports continuing this design, not deploying it globally yet. The previous request-bundle prototype also remains off.

The next meaningful experiment is current-syntax selection of complete relevant function bodies, with an aggregate source budget and explicit omissions, followed by implementation tasks where tests can score correct edits. Compare that against this prototype and baseline, including functions moved after edits and a branch where the answer is outside the budget. Preserve the successful properties: exact source provenance, reuse only of visible bodies, revalidation after edits, and restoration after compaction.

Raw results: [smoke](experiments/2026-10-17-source-reuse/smoke.json), [extended high](experiments/2026-10-17-source-reuse/extended-high.json), [longer file high](experiments/2026-10-17-source-reuse/padded-high.json), [missing range high](experiments/2026-10-17-source-reuse/missing-range-high.json). [Source provenance](experiments/2026-10-17-source-reuse/provenance.json) records final hashes and the baseline commit. All work remains uncommitted on the experiment branch.
