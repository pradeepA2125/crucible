# Agent-directed code discovery: search_index

**Live activation — 2026-10-19:** At the user's request, the workspace now selects `candidateDelivery: "on_demand"`. The backend was restarted with automatic code-candidate delivery, candidate reranking and recap/summary context selection disabled. `search_index` supplies discovery metadata when the agent requests it. The earlier automatic modes remain implemented for rollback. Activation evidence is in `docs/validation/on-demand-index/activated-live-2026-10-19.json`; the results below describe the preceding trial.

**Default — 2026-10-19:** On-demand discovery is now the default in both the backend and the extension settings. An absent or invalid backend delivery setting does not enable automatic discovery. Existing explicit `automatic` choices remain opt-ins. This removes automatic code retrieval, candidate processing and Qwen from the pre-model path; calls to `search_index` still incur retrieval/processing latency and a model round trip. Independent memory retrieval is unaffected.

Default-change validation: 139 focused backend tests and 35 extension setting tests passed. New coverage checks unset/invalid settings, no automatic lookup with either trial setting, skipped candidate models despite a configured Qwen scorer, and the explicit automatic opt-in. TypeScript, extension build, Ruff and `git diff --check` passed. The installed extension settings schema now advertises `on_demand` as its default; the live workspace already selects that mode explicitly.

The existing prompt already defines `code_candidates` as discovery hints, with paths, symbols, read ranges and relationships. It says that hints can be incomplete or stale and that the agent must read current source before relying on or editing code (`chat/controller_prompts.py`, HOW A TURN WORKS and GROUND CLAIMS IN CODE YOU HAVE READ).

The new `search_index` tool lets the model request that metadata itself:

```json
{"query":"where local code-retrieval models are enabled and disabled","limit":4}
```

The tool is bound to the current workspace, already identified by the request's `workspace_path`; the model does not need to infer or provide a repository name. It uses the same hybrid retrieval client and parsed graph cache, includes semantic retrieval when available, and returns the compact metadata-only catalog. It preserves selected symbol names/kinds/lines, available read ranges and relationships. Default limit is four files, with an explicit maximum of eight. It does not invoke Qwen, BGE candidate filtering, a recap/summary embedding selector, or a separate query-writing model.

**Query guidance — 2026-10-19:** The tool description now asks for one focused natural-language question with relevant technical keywords and known symbol/path names, and separate searches for distinct behaviors. This guides the model's query construction without changing retrieval scoring or demonstrating improved ranking. The existing search-index/controller-payload checks pass (37 tests); Ruff and whitespace checks pass.

Queries run off the event loop. The tool is read-only: `allow_build=False` prevents a missing snapshot from triggering an index-build command. Missing, invalid or stale indexes produce bounded notes and a fallback to normal search/read tools. The tool cannot select another workspace. Snapshot-version caching and workspace path filters are inherited from the existing client.

The tool is exposed through shared execution and planning registries, main chat, task execution, and child-agent tool sources where permissions allow it. The built-in read-only explore agent may use it. Existing user-defined allowlists still apply. The scheduler treats it as a read operation.

## Guidance and experimental mode

The tool description explains its purpose and limitations. When it is available, the first controller request also receives conditional guidance:

> When code is needed and its locations are unknown, prefer search_index as the first code-discovery tool, after required skill/todo setup. Treat returned locations as potentially stale hints and verify with read_file. Skip discovery for conversation, known locations, or sufficient visible source.

This is a preference, not a forced provider tool choice. It does not force a repository lookup for every message.

The new setting is:

```json
"crucible.performance.candidateDelivery": "on_demand"
```

The backend equivalent is `CRUCIBLE_CODE_CANDIDATE_DELIVERY=on_demand`. It skips both automatic candidate paths, candidate reranking and recap/summary embedding selection. The application default and this workspace's selection are both `on_demand`. Set `automatic` explicitly to restore automatic delivery, then restart the backend. An already running editor may need a reload to expose the new setting and runtime mapping.

Memory retrieval is independent and remains configured as before. Semantic code retrieval remains available when its model/index is ready.

## Live behavioral trial

Four read-only questions were sent to the configured ChatGPT provider. The prompts did not mention `search_index` or tell the model to choose it. The code questions shared a conversation; “hello” used a fresh conversation. Automatic delivery was temporarily disabled, then the previous automatic Qwen selection was restored with the provider configuration unchanged.

| Message | First executed tool | Index calls | Candidate files returned | Suggested files directly read | Model requests | Response time |
|---|---|---:|---:|---:|---:|---:|
| Locate local-model enable/disable behavior | search_index | 1 | 4 | 1 | 4 | 28.34 s |
| “Thanks” | None | 0 | 0 | 0 | 1 | 4.84 s |
| Trace catalog refresh and visible-source suppression | search_index | 1 | 4 | 0 | 5 | 35.32 s |
| Fresh “hello” | None | 0 | 0 | 0 | 1 | 6.14 s |

Both code questions selected the tool first, then used source reads and ordinary search as needed. Conversation triggered no tools. No automatic candidate lookup, catalog delivery or candidate reranking occurred in any of the four traces. Saved logical requests also contain no `code_candidates` field.

This establishes that the model can discover and use the tool under the new guidance in these examples. It does not establish reliable tool selection across models/tasks, or demonstrate that automatic discovery should be removed.

Catalog quality is still limited. The first lookup suggested `local_models.py`, `semantic_index.py`, `artifact_client.py` and the VS Code runtime mapping; the agent directly read only `local_models.py` from that list, plus `main.py`. The broader lookup returned the file-reference catalog, VS Code runtime mapping, orchestrator and patch engine; the agent instead located and read `chat/controller.py`, `chat/controller_loop.py` and `retrieval/candidate_delivery.py`. Direct-read overlap is a behavior proxy, not a relevance label, but this second result is weak evidence for relying on the catalog alone.

## Timing and token accounting

| Code lookup | Retrieval wrapper time | New tool-result tokens | Whole-input tokens reported across the message |
|---|---:|---:|---:|
| Local-model behavior | 2,281 ms | 278 | 98,715 |
| Catalog lifecycle | 241 ms | 311 | 198,078 |

The first lookup followed a backend restart and should not be treated as steady-state latency. The result token counts use `o200k_base` on the returned text, once, not on its escaped representation in every later provider request. The standalone new tool definition measured 153 proxy tokens; the conditional first-request guidance adds further prompt text.

**Zero automatic candidate tokens does not mean zero discovery-context cost.** Requested tool results remain in normal conversation history and may be replayed. The extra discovery step also requires a model round trip before the chosen source can be read. Provider-reported whole-input totals include cached input; they are not billing totals. These questions and execution paths differ from the earlier automatic trials, so their totals cannot establish a percentage saving. This experiment demonstrates tool adoption and routing, not end-to-end token reduction.

For scale, the earlier recorded old-layout seeds measured 6,343–7,158 estimated tokens (6,854 in the explicit-file example). On-demand sends zero automatic seed tokens; the two observed requested catalogs were 278 and 311 tokens. Those examples are roughly 95–96% smaller discovery metadata blocks than the old seeds, but their query/selection content differs, and this excludes the new tool definition, guidance, source reads and replay. The earlier controlled candidate-only payload reconstruction was 28,063 → 21,120 estimated first-input tokens (24.7% smaller), before the subsequent on-demand tool change. It supports an approximately one-quarter initial-payload saving in that recorded scenario, not an exact current on-demand or pre-branch whole-task saving. The current on-demand fresh code question's first provider request was 20,387 tokens and fresh greeting's 20,271; neither is a matched comparison with the original question/provider count of 27,448.

The ongoing per-message report now distinguishes automatic candidate fields from index-search calls and newly returned index-result tokens. Full provider input reports remain available in its JSON output.

## Decision and validation

The trial justified keeping the tool available, but not deleting the automatic Qwen or no-reranker implementations. The user subsequently chose on-demand delivery for the live workspace; the alternatives remain available for rollback. Next comparisons should use identical tasks and assess needed-file recall, answer correctness, tool choices, total requests, total input and end-to-end latency. Improving candidate ranking is a separate issue from whether the model chooses the discovery tool. Rust can eventually provide a faster or richer lookup underneath the same tool contract without changing the agent interface.

Twelve new search-index tests pass, covering hybrid metadata output, source omission, background-thread execution, no implicit rebuild, broken/deleted snapshots, argument bounds, model bypass, real controller search/read routing, absence of automatic delivery, and conditional guidance. Existing planning, batching, permission, prompt, graph-cache and retrieval checks passed (178 tests in the broader focused run); the subsequent task-registry integration checks passed as well. All 33 extension setting tests, TypeScript, extension build, targeted mypy, Ruff and `git diff --check` passed.

Evidence:

- `docs/validation/on-demand-index/messages.json`: live questions, measurements and trace records.
- `docs/validation/on-demand-index/behavior.json`: actual first tools, tool-written queries, candidate paths and new file reads, with source-artifact locations.
- `docs/validation/on-demand-index/per-message.json`: current summary format distinguishing automatic and requested discovery.
- `docs/validation/on-demand-index/restart-on-demand.json`: experimental mode active, candidate scorer disabled.
- `docs/validation/on-demand-index/restored-automatic.json`: automatic Qwen delivery restored and ready, provider unchanged.

Implementation remains uncommitted on `codex/sidecar-reliability-experiments`. The installed local extension has the setting and mapping; the workspace configuration now selects on-demand delivery.
