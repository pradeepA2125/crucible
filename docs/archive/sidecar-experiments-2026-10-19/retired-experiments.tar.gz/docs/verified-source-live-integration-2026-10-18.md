# Verified source delivery: local live integration

> Superseded for the chat path by [candidate-only per-turn retrieval](candidate-only-retrieval-2026-10-18.md). This document preserves the earlier implementation and measurements.

Date: 18 October 2026. Branch: `codex/sidecar-reliability-experiments`.

## Installed implementation

The live workspace backend uses the editable Python package in this checkout. Verified source delivery is enabled for this workspace, and the local extension build exposes `crucible.performance.verifiedSource` (default false). The workspace setting maps to `CRUCIBLE_VERIFIED_SOURCE_REUSE_ENABLED`. Backend capability status is visible as `verified_source_enabled` in `GET /v1/config`.

The initial seed is retained. For later user requests, retrieval selects new candidate paths/ranges. Explicit relative source paths narrow automatic delivery; a named file omitted by hybrid ranking still becomes a bounded read candidate through the normal permission-checked reader. Before each model call, after memory compaction, the harness selects current Python function bodies where possible, reads through the existing tool registry, and compares workspace root, path, full-file SHA-256 revision, range coverage and actual visible source lines. Matching visible bodies are reused; missing or changed bodies are appended within a shared budget. Unsupported languages, ambiguous symbols and incomplete syntax reads use explicitly labelled bounded ranges.

`CRUCIBLE_SOURCE_BUDGET_CHARS` defaults to 16,000 serialized source-entry characters. This limits newly appended source bodies, not the complete provider request. Full functions are not an adaptive smallest-excerpt policy. Their upfront token cost remains task dependent.

Source inspection and omitted bodies do not advance edit-read tracking. The controller commits observations only after the complete prepared result has entered outgoing history. If preparation fails, the ordinary source tools remain available and the manifest reports unavailable verification. Existing edit/hash safeguards remain in place.

The Rust parser stages per-file replacements; graph replacement/deletion removes obsolete nodes and incident edges. Watch handling covers deletions, renames and canonical workspace aliases. Failed parses preserve last-good graph data with a warning. Semantic updates remove deleted chunks, prepare embeddings before deleting old rows, and propagate deletion failures.

## Removed experiments

Removed the unverified append-every-query bundle, its feature flag and delivery branch. Removed the separate old-range-versus-syntax switch: current syntax selection and conservative range fallbacks are now part of the same implementation. Removed the three ablation runners and two experiment-only test modules from the checkout; their files were preserved under `/tmp/crucible-sidecar-retired-experiments-2026-10-18`.

Production regression tests remain, with shared controller fixtures in `tests/source_delivery_helpers.py`. Historical experiment reports and raw measurement artifacts remain as the audit trail; their feature-flag instructions describe those earlier runs, not the current integration.

## Local installation and rollback

Built and installed the local VSIX using the previously installed released runtime manifest. Installed the optimized Rust indexer atomically. The backend was restarted at the existing local address while retaining its provider, model, reasoning effort and policies. The manually launched watcher is tied to this backend’s lifetime so it exits when that backend is replaced. No remote release was published.

Extension reload through the existing window did not take effect during automation. The backend was therefore restarted directly at its existing address. The installed extension's new settings UI takes effect on the next successful window reload; the backend's verified-source capability is already enabled.

Previous extension files, indexer binary and snapshot are backed up in `/tmp/crucible-source-delivery-live-backup`. To disable source delivery, set `crucible.performance.verifiedSource` to false and run **Crucible: Restart Backend** using the updated extension. Python also supports `CRUCIBLE_VERIFIED_SOURCE_REUSE_ENABLED=0`. Disabling delivery does not revert lifecycle fixes.

## Verification and remaining boundary

The extension build, 71 extension runtime checks and all 56 Rust tests passed. All 78 focused Python source/read/history/retrieval regressions passed after the final changes, including memory-v2 sequencing/restart, partial-preparation failure and explicit-file selection. Ruff and `git diff --check` also pass.

The backend reports verified source enabled. Both local embedding and reranking workers reached ready state after the restart. The native watcher runs the optimized binary with installed language servers enabled. The final semantic index status reported enabled, not building, and exactly the same snapshot generation as the native graph; the deleted probe was absent.

The initial approval review paused model-level checks because they could send private workspace code and remembered context to the configured provider. The user explicitly approved that transmission. The authorized live checks then completed through the existing ChatGPT provider and real backend, retaining the existing model and low reasoning effort.

All seven live checks passed: initial lookup, unchanged reuse, same-size/same-mtime external edit, moved function, real controller/patch-engine edit, post-edit follow-up, and deletion. Read-only checks took one model call each; the edit took two calls (edit, submit). The updated function was independently checked through its parsed return expression. No other file changed in a hash comparison over 1,670 workspace files. The disposable probe was removed and the native graph confirmed its absence.

The first live request used **27,448 provider-reported input tokens** and **107 output tokens**, including an appended source entry of **902 serialized characters**. The unchanged follow-up appended zero source-body characters, but its total input was 29,480 tokens because history and other context still travel with each request. These are measurements of this live configuration, not a controlled comparison with the previously remembered 22k first call and not a new savings percentage.

The first diagnostic attempt answered correctly but delivered unrelated hybrid-selected evidence and needed a manual read. Its test runner also initially looked for the API role `assistant` instead of `agent`. Those issues were diagnosed separately: explicit-path selection was fixed in production code, the runner's message-role parsing was corrected, and the seven checks were rerun successfully. The diagnostic is retained rather than counted as a successful first-pass source-delivery trial.

Evidence: [live agent results](validation/2026-10-18-verified-source/live-agent.json), [local native pipeline](validation/2026-10-18-verified-source/local-pipeline.json), [initial diagnostic](validation/2026-10-18-verified-source/initial-diagnostic.json).

Freshness remains scoped to selected source bytes at read time. The pinned seed and older history may contain obsolete context; graph and vector updates are asynchronous. A current source hash does not certify graph relationships or repository-wide completeness. There is no atomic repository snapshot through model inference, and the semantic delete/insert operation is not transactional. This trial establishes neither a production savings percentage nor a no-stale-results guarantee.
