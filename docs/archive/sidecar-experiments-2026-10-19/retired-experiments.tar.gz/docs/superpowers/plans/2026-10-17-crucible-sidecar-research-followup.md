# Follow-up: complete external repository research with capable team members

Please continue the existing reliable-code-intelligence-review team. The user has explicitly requested another round with the repository researchers able to search the web and fetch repository sources. The first round was incomplete because the Graphify and code-review-graph researchers used the built-in explore role, whose effective tool set excludes web_search and web_fetch.

Use the supported native workflow, preserving the existing team/member identities and history:

1. Inspect the current completed team's run/result and request_team_member_upgrade for members graphify and review-graph. This workflow upgrades them to general-purpose, with web tools subject to normal tool availability and policy. Explain the concrete change in the confirmation card and let the user's card decision control the upgrade. Do not edit storage, agent definitions, global permissions, runtime flags, or approval settings to bypass that workflow. Do not request an upgrade for our-system; it can keep investigating local code with its current role. The architecture lead is already general-purpose.
2. Keep the team in deliberate mode. Upgrading a role does not authorize product implementation. The requested work remains research, source inspection, discussion, and updating the report.
3. After the upgrade has been approved and the effective roles are confirmed, use post_board on the same completed team to reopen it for another deliberation run. Mention @graphify @review-graph @architecture @our-system and give them this research follow-up. Do not merely resume finalization or start_team_implementation: the user wants a new discussion with peer findings and challenges.
4. Verify that both external researchers actually have web_search and web_fetch at activation. Have each attempt a public repository source fetch early. If tools are still absent or requests are gated, identify the exact effective-capability or approval issue promptly. A prose instruction to browse is not a capability grant. If same-team upgrades are unavailable, report that concrete limitation before substituting a new team.

Required external implementations:

- https://github.com/Graphify-Labs/graphify
- https://github.com/tirth8205/code-review-graph

Additional references, where useful:

- https://github.com/Aider-AI/aider
- https://github.com/oraios/serena
- https://github.com/sourcegraph/scip

Inspect actual source and tests, not just README claims. Pin the branch/commit reviewed and cite concrete files/functions. Follow source links, paginate or fetch complete relevant ranges when tool output is truncated, and label unfinished coverage honestly. Do not install or execute third-party code. Do not transmit local workspace source or private material to third-party sites; public-source web research is the authorized use of the new tools.

Read the existing report and previous team board as context:

docs/superpowers/specs/2026-10-17-reliable-code-intelligence-sidecar-review.md

Focus this run on filling the real research gaps and testing the previous recommendation against external architectures. Compare publication/update transactions; partial/failed parse behavior; deletion/rename/branch changes; graph identity and provenance; graph/semantic generation coherence; question/symbol lookup; traversal completeness and incoming/outgoing selection; explicit paths; change impact/tests; source delivery; agent integration; and failure recovery. Identify mechanisms we can adopt, their costs, where our Rust/LSP implementation is already stronger or sufficient, and where the evidence does not support a conclusion.

Reconcile findings with the local sidecar and harness rather than producing an isolated external feature list. Ask the local investigator to validate specific comparative hypotheses and identify which initial source-level concerns need runtime reproductions. Have the architecture lead revise the recommendation after peer discussion, including disagreements and changed conclusions. Existing correctness findings and the earlier report remain hypotheses to verify at the current source revision; do not automatically endorse them.

Prioritize depth, reliability, and a usable harness contract. Do not start with token-saving targets or constrain the reasoning to an arbitrary number of iterations. Respect ordinary runtime limits, and report any actual stopping condition instead of silently calling incomplete work complete. Efficiency is an outcome to evaluate after correctness and capability are established.

Update the existing report with the inspected immutable source revisions, completed comparisons, revised recommendation, concrete adoption/migration options, remaining gaps, and a reliability-first validation plan. Preserve the first round's provenance and explicitly distinguish this follow-up's new evidence. Save research documentation only; no product implementation is authorized. Deliver the revised synthesis back to the main Crucible chat.
