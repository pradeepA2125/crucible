# Crucible team brief: reliable code-intelligence sidecar

Please use Crucible's native team tools to create a team in deliberate mode and investigate how to improve our Rust indexer and its integration with the agent harness. This is an architecture research and design discussion. Produce a detailed, source-grounded assessment before implementation. Do not change product code as part of this request. Research notes and a final report are welcome.

Prioritize correctness, reliability, completeness, and architectural understanding. Do not start by optimizing token spending, limiting iteration counts, or selecting arbitrary context budgets. Take the discussion and source inspection far enough to understand the system. Efficiency should be evaluated after the correctness and harness contracts are clear; vendor savings headlines are not design requirements. Work within normal runtime permissions and limits without changing global configuration.

## Team and discussion

Use actual native team collaboration, not a solo response describing hypothetical roles. Suggested responsibilities, adapted to available team capacity:

- Our implementation: inspect the Rust indexer, LSP resolution, semantic indexing, hybrid retrieval, and the Python surfaces exposed to agents.
- Graphify: inspect the actual implementation of retrieval, graph traversal, persistence, incremental updates, integration hooks, and evidence delivery. Separate open-source capabilities from Cloud claims.
- code-review-graph: inspect actual storage, parsing/resolution, incremental changes, impact analysis, test relationships, context delivery, and partial-result semantics.
- Architecture lead/critic: synthesize and challenge the findings; inspect other relevant architectures; distinguish useful borrowings from complexity we do not need.

Have members share evidence, question assumptions, and review a concrete proposed architecture together. Include disagreements and unresolved questions, not just independent summaries. The lead should connect the sidecar's behavior to what the harness can safely rely on. Deliberation does not authorize product implementation.

## Required comparisons

Start with these two repositories:

- https://github.com/Graphify-Labs/graphify
- https://github.com/tirth8205/code-review-graph

Additional candidate references, if their implementations answer a relevant design question:

- https://github.com/Aider-AI/aider — investigate repository-map selection and how it participates in the agent workflow.
- https://github.com/oraios/serena — investigate LSP-backed symbol navigation and agent-facing code tools.
- https://github.com/sourcegraph/scip — investigate symbol identity and interoperable code-intelligence contracts. Treat it as an indexing protocol/ecosystem, not a complete agent harness.

You may add other repositories when they materially improve the comparison. Avoid superficial feature lists. Read source and tests; record the branch/commit inspected, link concrete files/functions, and label documentation claims, measured observations, and architectural inferences separately. Do not install or execute third-party code just to inspect it. Use the available web/repository-reading tools and permitted read-only source downloads as appropriate.

## Questions about our system

1. What does the Rust indexer already do well? Inspect parser fidelity, language coverage, LSP definitions/implementations, symbol and edge identity, incremental watch behavior, and persisted snapshots. Identify capabilities we should preserve.
2. What is missing or unreliable in the index itself, versus what exists but is lost or underexposed in the Python/tool integration? Verify this distinction before proposing parser/index replacement.
3. How does code context actually reach the model in chat, task planning, execution, and children? Trace initial seeds, hybrid ranking, source chunks, graph expansion, tool outputs, history persistence/compaction, and edit deltas.
4. Can the harness distinguish complete from partial, stale from current, a missing edge from a proven absence, and a source excerpt from an inferred relationship? What versioning and provenance contracts are needed?
5. What happens during edits, deletes, renames, branch switches, external changes, parse/LSP failure, a stale semantic index, restart, cancellation, concurrent requests, and shadow-workspace execution?
6. What should be guaranteed by the sidecar versus decided by the model? How should source delivery satisfy existing read/revision checks? How do we make evidence useful without relying on repeated instructions to call query_graph?
7. What architecture would make this a dependable harness subsystem with clear ownership, query semantics, update consistency, failure recovery, and observability? Compare realistic alternatives and migration costs.

## Context from the preceding discussion — verify, do not assume

The preceding analysis found that our Rust snapshot already carries Calls, Imports, References, Inherits, and Implements; Rust supports symbol-name lookup, while the Python graph tool asks for an exact file or file:Symbol. The current initial retrieval path combines symbol/path keyword scores and semantic similarity when available. The chat controller appears to pin that hybrid seed once per chat, not rerun it for every user message. Tool results append to history; the current post-edit retrieval delta appears to be only a changed-files notice. Task orchestration has separate retrieval paths. Per-query durable-memory recall is a different subsystem.

Other reported observations worth reproducing: outgoing-first truncation can hide all incoming file connections; multi-hop tool output loses intermediate edge endpoints; initial payloads expose neighboring file paths without their relationships; execution constructs a fresh graph walker per call. A saved thirty-turn convenience sample showed no explicit query_graph calls, but this is not evidence that automatic hybrid retrieval was absent, that every task needed graph traversal, or that the index delivers no benefit.

Read these previous documents only as hypotheses and proposals to critique:

- docs/graphify-rust-indexer-comparison-2026-10-17.md
- docs/superpowers/plans/2026-10-17-structured-retrieval-evidence.md

The proposed direction was to retain the index, use a small stable header, append relevant hybrid/graph/source evidence for a substantive request, reuse already-visible current source, and deliver versioned edit deltas. The user wants the team to investigate whether this is the right architecture, not merely endorse that plan. Reconsider it when source evidence suggests a better approach. Do not make token budgets or iteration targets the starting constraint.

Useful local entry points:

- services/indexer-rs/src/{parser,graph,resolver,lsp,service,config,main}.rs
- services/agentd-py/agentd/retrieval/{artifact_client,semantic_index,chunker,graph_walker}.py
- services/agentd-py/agentd/planning/{registry,agent,prompts}.py
- services/agentd-py/agentd/tools/{registry,files,read_policy}.py
- services/agentd-py/agentd/chat/{controller,controller_loop,controller_prompts}.py
- services/agentd-py/agentd/orchestrator/engine.py
- services/agentd-py/agentd/memory/{harness,compactor,evidence}.py
- Relevant tests and existing graph/context/controller design documents.

## Deliverables

Produce a detailed report and an actionable recommendation, ideally saved as docs/superpowers/specs/2026-10-17-reliable-code-intelligence-sidecar-review.md if writing a research artifact is available. Include:

1. A source-grounded current-state walkthrough and strengths to preserve.
2. A comparison matrix explaining mechanisms and tradeoffs across our system and the inspected references.
3. Verified gaps, failure scenarios, root causes, and their practical effect on the harness; separate indexing failures, retrieval failures, delivery failures, and model-use failures.
4. Proposed sidecar/harness responsibilities, data contracts, lifecycle/consistency model, and how evidence reaches the model. Explain what happens when evidence is unavailable, stale, incomplete, or ignored.
5. Alternatives, team disagreements, evidence that changed the recommendation, and remaining unknowns.
6. A staged migration and validation plan, with concrete files/modules, compatibility considerations, and tests showing reliability. Evaluate efficiency later as an outcome alongside quality, rather than choosing a savings target in advance.

Once the team has completed its review, synthesize its findings in the Crucible chat. If native teams, source access, or another required capability is unavailable, explain the precise limitation instead of claiming a team review occurred.
