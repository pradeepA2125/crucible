# Structured retrieval evidence: implementation plan

Date: 17 October 2026. Status: proposed; product changes have not been implemented.

## Outcome

Use our existing Rust graph and semantic index to supply bounded, current code evidence for a user request. Preserve useful context across follow-ups and deliver only missing or changed evidence. Reduce exploratory reads and model rounds while retaining source grounding, accepted-result quality, and provider cache behavior.

This builds on [the comparison report](../../graphify-rust-indexer-comparison-2026-10-17.md). No specific token-saving percentage is assumed.

## Existing behavior to build on

- Rust persists symbols and Calls, Imports, References, Inherits, and Implements edges. Its resolver can use LSP definitions and implementations.
- `RetrievalArtifactClient._build_context` already combines symbol/path keyword matching and optional semantic retrieval, then constructs outlines and source excerpts. Preserve the current 0.35/0.65 weights for the initial delivery experiment.
- `CodeChunk` already contains source ranges, signatures, docstrings, relationship names, and source text. Reuse these fields before expanding the Rust schema. Existing chunk boundaries are derived from snapshot symbols and capped in size; they must not be described as exact complete function bodies without verification.
- The controller computes its retrieval seed once per chat and replays it unchanged. Tool results append to history. The current edit delta is a changed-files notice.
- Read delivery metadata, revision-aware edit checks, history compaction, memory recall, and batching already exist. Extend their integration rather than introducing parallel systems.

## Target structure

```text
Workspace changes
  -> existing Rust incremental graph updates
  -> existing semantic delta indexing
  -> versioned retrieval snapshot/cache

New user request
  -> request query + bounded active-task references
  -> existing hybrid candidate ranking
  -> selected graph expansion + current source delivery
  -> remove evidence already visible at the same revision
  -> append one bounded evidence event to history
  -> existing controller loop

Accepted edit
  -> immediately invalidate affected source evidence
  -> existing index/watch updates
  -> bounded, versioned delta when relevant evidence is available
```

The first request and later requests use the same evidence contract. An initial workspace header is separate, small, and stable. An edit delta is a partial evidence event with invalidations. The graph and semantic indexes remain persistent; a user request queries them rather than rebuilding them.

## Agent uptake: make the default delivery automatic

The main optimization must not depend on the model choosing `query_graph` or `retrieve_context`. The backend runs the admitted request's retrieval, graph expansion, and source delivery before the first model call. An agent that never calls the graph tool can still receive the selected relationship paths and implementation excerpts. The tools remain available for uncovered questions. Increasing graph-tool call counts is not a success criterion.

Automatic delivery alone does not guarantee model attention or better task outcomes. We already inject initial retrieval context today. The proposed change must demonstrate that current-request selection, explicit connections, actionable source, and reuse improve behavior relative to that baseline. Keep the bundle adjacent to the current request, identify the question each result addresses, and include enough actual source for the immediate reasoning/editing step within its budget. Graph locations alone must not be mistaken for implementation evidence.

Integrate delivery with the existing source-reading/edit-evidence contract. The controller recognizes current, automatically delivered source just as it recognizes manual read results. For a repeated read whose exact source revision and requested range remain visible in the actual provider input, deliver only missing ranges or a compact reference to the surviving evidence event; do not inject the same source body again. Explicit refresh, changed files, different roots, and compaction that removes source text permit fresh delivery. A stale coverage inventory must never suppress a needed read. References are successful reuse results, not error refusals that encourage repair loops.

Source and graph completeness are different. A visible function body does not establish all callers, and a bounded graph result does not establish absence of additional callers. If an existing edit validation obligation requires caller/implementation coverage, satisfy it through current recorded evidence or a backend query for that obligation, independently of whether the model chose a graph tool. Do not introduce a universal mandatory graph call or a new gate for unrelated edits; implementation of any new blocking coverage policy requires its own correctness rationale and evaluation.

Measure redundant source bytes, repeated discovery rounds, task quality, and billed tokens. For a structural query, inspect whether the delivered bundle actually contains the required edges and whether the answer/change accounts for them. A model repeating an evidence ID is not proof that it used the evidence correctly. Include a test agent that never invokes `query_graph`: automatic structural context must still arrive. If the agent still explores as much as Current and accepted-result quality/cost do not improve, the pilot has failed its purpose even if every bundle was delivered successfully.

## Ideas to adopt from Graphify

The inspected public implementation supports scored question-to-graph retrieval, explicit edges/path queries, approximate output budgets, hub-aware traversal, and relationship provenance. Its installed instructions favor graph queries before source exploration. Sources: [query implementation](https://github.com/Graphify-Labs/graphify/blob/v8/graphify/serve.py), [assistant guidance](https://github.com/Graphify-Labs/graphify/blob/v8/graphify/always_on/agents-md.md).

| Idea | Adaptation for our implementation |
|---|---|
| Question-to-subgraph retrieval | Use our existing hybrid candidates as graph seeds; support questions and unqualified symbols in the agent-facing interface. |
| Explicit edges and paths | Return endpoint IDs and intermediate hops so the model can follow the connection without reconstructing it. |
| Scoped output budgets | Budget the complete rendered evidence, retaining endpoint closure and explicit omissions. |
| Provenance | Distinguish AST, LSP, heuristic, and unknown legacy origin where the extractor actually records it. |
| Hub suppression | Bound expansion through highly connected transit nodes while retaining directly requested symbols and reporting coverage. |
| Query-first exploration | Supply relevant graph evidence automatically for substantive code requests; encourage tools to fill specific gaps. |

Question retrieval, source delivery, and graph evidence should work together. General source inspection remains available, and behavioral claims still need current implementation evidence. Importing another indexing dependency or adopting Cloud/formal-verification features is outside this change.

## 1. Define one evidence contract

Add `agentd/retrieval/evidence_models.py` with internal typed models and a versioned serializable `EvidenceBundle`. Keep provenance, source delivery, and graph coverage distinct. The following is an illustrative contract, not current runtime output:

```json
{
  "schema_version": 1,
  "event_id": "turn-42:retrieval:0",
  "kind": "request",
  "query": {
    "original": "Who calls this?",
    "contextualized": "Callers of ChatController._compute_retrieval_seed",
    "anchors": ["services/agentd-py/agentd/chat/controller.py:_compute_retrieval_seed"]
  },
  "versions": {
    "graph": "snapshot-generation",
    "semantic": "semantic-build-generation"
  },
  "nodes": [
    {
      "id": "snapshot-scoped-symbol-id",
      "path": "services/agentd-py/agentd/chat/controller.py",
      "symbol": "ChatController._compute_retrieval_seed",
      "kind": "Method",
      "definition": {"start_line": 719, "end_line": null}
    }
  ],
  "edges": [],
  "paths": [],
  "sources": [
    {
      "evidence_id": "source-content-and-range-id",
      "path": "services/agentd-py/agentd/chat/controller.py",
      "revision": "content-hash",
      "start_line": 719,
      "end_line": 729,
      "text": "<current line-numbered source delivered to the model>",
      "delivery": "complete_range"
    }
  ],
  "invalidated": [],
  "coverage": {
    "depth": 1,
    "directions": ["in"],
    "truncated": false,
    "omissions": [],
    "freshness": "pending_verification"
  }
}
```

Each edge contains `from`, `to`, `kind`, optional `site`, and `origin`. Paths contain ordered edges; node IDs are scoped to the stated graph generation. For cross-generation rebinding, use path plus qualified name and kind, and report ambiguity instead of guessing. Older edge origins are `unknown`; an existing edge is not retroactively labelled LSP-resolved or extracted.

Store the typed bundle for observability and render compact text for the model. Do not transmit both the full JSON and its text rendering. Optional fields are omitted when unhelpful. Graph absence means “not found within this index and coverage,” not proof that a caller does not exist.

Suggested initial budgets, to tune through evaluation:

| Scope | Starting setting |
|---|---|
| Stable workspace header | At most roughly 1,000 tokens; no large task-specific excerpts |
| Request evidence | Target 3,000 tokens; maximum 6,000 plus a small fixed status allowance |
| Candidate pool | Reuse the current semantic top-40 pool and lexical candidates |
| Graph seeds | Up to four after deduplication; explicit requested anchors retained |
| Expansion | One hop by default; two for requested paths/implementation dispatch |
| Incoming/outgoing selection | Separate allocations; a requested direction may use the whole graph allocation |
| Source excerpts | Up to four initial ranges, further bounded by the aggregate budget |

Use the active tokenizer where available. Label estimates and enforce a conservative character ceiling as a fallback; never claim a character heuristic is an exact token limit. Retain every referenced edge endpoint, remove whole records/ranges at boundaries, and identify omitted directions/ranges/counts. A long seed block must not silently bypass the aggregate limit.

## 2. Improve graph querying before changing automatic retrieval

Extend `graph_walker.py` and both registries:

- Add exact unqualified symbol and node-ID lookup, retaining current file and `file:Symbol` forms. Use deterministic ambiguity output listing file-qualified candidates.
- Return explicit edges with endpoints and predecessor paths at depth two or more. Preserve multiple meaningful edge kinds between a pair of nodes.
- Add `direction`, separate incoming/outgoing quotas, and a continuation mechanism for truncated results. Fix the observed outgoing-first starvation at a shared limit.
- Reserve expansion for requested roots and relevant neighbors. Apply conservative hub limits to transit nodes and report their effect.
- Cache the parsed graph/adjacency by workspace and snapshot generation; reuse it in execution as planning already does. Bound the cache and invalidate on atomic snapshot replacement.
- Keep existing `query_graph` arguments compatible. Add question lookup through the shared retrieval service rather than implementing another independent ranking algorithm.

Keep graph-only output available: a caller asking for relationships should not automatically receive implementation text it does not need. Source excerpts are requested by the automatic evidence pipeline or its expansion tool when behavior needs inspection.

Primary files: `retrieval/graph_walker.py`, `planning/registry.py`, `tools/registry.py`; Rust `graph.rs` and `main.rs` provide an existing lookup/response reference. V1 can improve Python over the current snapshot without replacing the parser or requiring an IPC redesign.

## 3. Assemble request evidence using the existing hybrid retrieval

Add `agentd/retrieval/evidence_service.py` and `evidence_renderer.py`. Refactor candidate selection out of `artifact_client.py` so initial evidence, automatic request evidence, and on-demand expansion share one pipeline:

1. Preserve the original user request verbatim. Build a bounded contextual query from the active task/accepted recap and explicit referenced symbols. Search explicit symbol anchors directly; use the contextual query to resolve pronouns. An unrelated new request must not be overwhelmed by old task text.
2. Retrieve lexical and available semantic candidates. Maintain the current weights initially, record component scores, and deduplicate overlapping chunks and duplicate symbol candidates. Keep lexical results available when semantic retrieval is cold or fails.
3. Select a few seeds and expand graph relationships relevant to the query. Source implementation questions favor callees and local bodies; caller/blast-radius questions allocate to incoming edges; contract questions may include implementations and tests. Use explicit filters when present and a balanced default otherwise.
4. Fetch source from the current permitted workspace/root, using existing read delivery and evidence validation seams. Verify indexed chunk revisions before treating their text as current. Reuse validated `CodeChunk` ranges/signatures; leave unknown source end ranges unknown.
5. Subtract evidence already visible at the same revision. Rank remaining source and relationships under the aggregate budget and render one bundle.

Do not add a separate LLM request to classify each message as related/different. Default substantive, ambiguous code requests to retrieval. Known protocol continuations tied to an active action reuse its evidence. Greetings and explicit non-code control messages do not require code retrieval. Existing controller decisions can request expansion if the initial bundle misses the intended referent; expose the contextualized query for correction.

Avoid embedding the entire chat as a query. The bounded active-task context comes from already available state; no additional summarization model call is required. Do not silently synthesize a stale task summary as if the user supplied it.

## 4. Integrate with the controller's append-only lifecycle

Add `agentd/retrieval/evidence_session.py` to track delivery identity and request state. Integrate at `_start_user_turn`/`_run_loop` before the first provider call:

- For a new chat, pin a small workspace header under the stable prefix. Do not also inject the former large task-specific seed on that path.
- For existing chats, preserve the stored seed byte-for-byte. New evidence goes after the current user message in the history tail. Do not retroactively rewrite previous seed bytes merely to migrate the feature.
- Prepare a request bundle at most once per user-turn ID, persist it with the history event, and reuse it across model steps, backend restart, or retry. A retry may update delivery only through a new explicitly identified event.
- The same response/loop does not automatically rerun hybrid retrieval every model iteration. Additional retrieval is on-demand for a newly identified gap or actual workspace change.
- New tool-returned source and automatic evidence feed the same visibility inventory. Register only source text actually delivered after truncation; locating a file or symbol does not establish that its body was read.
- Source injection must use the same root boundaries, access checks, revision validation, and edit-evidence rules as manual reads. It must neither bypass edit guards nor force a redundant manual read solely because delivery was automatic.
- Keep per-query memory recall separate from code evidence. They share a total context budget but are not merged into an unversioned seed.

The on-demand `retrieve_context` tool should accept a question, optional file/symbol anchors, graph filters, and a bounded output budget. Keep current search/read/graph tools for precise work. Planning and execution use the same evidence service and root semantics; introduce automatic delivery in the main controller first, then reuse it in the separate task path without duplicating pre-explored evidence.

## 5. Track visibility, freshness, and edit deltas

Visibility inventory: `(workspace/root, path, content hash, delivered range, surviving history event)` for source, plus versioned node/edge identities for graph evidence. Derive it from the actual provider-visible projection after compaction, including source delivered by manual tools. A summary that says a function was read does not preserve its implementation text.

Same-revision visible overlap is removed; uncovered ranges are delivered. Invalidation occurs on edit, external file change, root change, or removal of the source event during compaction. Re-evaluate overlapping range unions instead of comparing tool arguments alone. Keep a bounded inventory and retain current duplicate-call protection.

After an accepted edit:

1. Immediately append invalidations for source ranges in touched files. Existing promotion and source revision checks stay authoritative.
2. Request/coalesce existing incremental index work. Do not synchronously rebuild the whole repository in the chat loop.
3. If a matching graph generation is available, append a bounded delta with relevant changed connections and affected callers/implementations. Compare selected neighborhoods with a baseline or retain changed-file tombstones; a new snapshot by itself cannot identify removed edges.
4. If indexing lags, append `graph_pending` with touched files. Current permitted source reads remain usable; do not present old graph relationships as fresh.
5. Before later evidence delivery, check generation/read consistency. A racing update gets one bounded retry or a clearly labelled partial source result, rather than an unbounded rebuild/wait loop.

No unsolicited delayed model turn is needed when a background build finishes. Deliver the ready delta at the next appropriate retrieval boundary. In shadow execution, real-workspace graph data must be labelled as a baseline until it is reconciled with shadow edits.

Later schema enrichment can add verified AST end ranges, call-site locations, and recorded edge origins in Rust, plus content hashes/build-generation metadata for semantic chunks. Make fields backward compatible or increment the snapshot schema with a loader migration. An mtime alone is insufficient to assert exact source equality.

## Implementation work packages

Execute sequentially; each package should be independently reviewable.

| Package | Changes | Main files | Exit criteria |
|---|---|---|---|
| A. Baseline and contract | Save matched task fixtures; add evidence models, deterministic renderer, explicit budget/coverage semantics | New `retrieval/evidence_models.py`, `evidence_renderer.py`; existing context metrics | Output bounded and deterministic; data from a historical trace is labelled as such |
| B. Graph usefulness | Symbol lookup, balanced directions, real paths, ambiguity, bounded shared cache | `graph_walker.py`, `planning/registry.py`, `tools/registry.py` | High-fan-out query returns requested incoming connections; multi-hop chain is explicit |
| C. Shared hybrid evidence | Extract candidate ranking, seed expansion, current source delivery; expose `retrieve_context` | `artifact_client.py`, new `evidence_service.py`, registries | Question finds evidence without requiring the agent to know its file; lexical fallback works |
| D. Controller delivery and reuse | Small new-chat header, per-turn appended bundles, visibility subtraction, durable idempotence | New `evidence_session.py`, `chat/controller.py`, `controller_loop.py`, `controller_prompts.py`, storage/history integration | One request event per user turn; follow-up adds only missing evidence; prior cache prefix survives |
| E. Versioned deltas | Immediate invalidations, graph-pending state, selected neighborhood diffs; optional Rust/semantic metadata enrichment | `controller.py`, evidence service/session, `semantic_index.py`; Rust `graph.rs`, `parser.rs`, `service.rs`, `resolver.rs` as needed | Changed/deleted code cannot remain silently fresh; delta reports graph lag and removed relationships |
| F. Wider integration and rollout | Reuse service in task planning/execution, update prompts, run comparative evaluation | `orchestrator/engine.py`, `planning/agent.py`, `planning/prompts.py`, context metrics/evaluation scripts | Same contract across paths; quality/cost/cache results justify enabling the default |

Pilot A–D first. Keep the existing changed-files delta notice until E is complete. B yields an immediate standalone benefit; no speculative parser replacement is required for the pilot.

## Validation

Use existing graph, retrieval, controller payload/durable-history, memory compaction, and read-evidence tests as foundations. Add behavioral tests that cover:

- Unqualified symbols across files, case handling, ambiguous matches, and external markers.
- Incoming-only and balanced queries on a file with more outbound neighbors than the maximum result limit.
- Multiple edge kinds and a two-hop caller/declaration/implementation path with correct endpoints/direction.
- Budget exhaustion, very long identifiers, endpoint closure, incomplete neighborhoods, and missing indexes.
- A fresh request, a related request needing new files, a topic change, an explicit continuation, and a non-code message.
- Semantic cold/failure fallback and current-source validation when an indexed chunk is old.
- Identical visible source, overlapping ranges, changed content, shifted line numbers, and compaction that removes the original source event.
- Successful edits using automatically delivered source; failed edits when its revision has changed; access/root restrictions identical to manual read paths.
- Restart/cancellation/retry without duplicate evidence events or rerunning mutations; pinned legacy seed bytes remain unchanged.
- Edit/delete/external changes, removed graph edges, lagging graph/semantic generations, and shadow-workspace divergence.
- Provider request structure and cache-prefix stability across turns and native/structured tool paths.

Record, without requiring source text in summary telemetry: evidence selection reasons, lexical/semantic candidate counts, selected graph coverage, omitted/reused/delivered source ranges, retrieval CPU/wall time, final rendered size, model steps, and actual provider input/cached/output/reasoning usage where available. Label all estimates and missing usage values.

Run a paired evaluation across a fixed repository revision, model, reasoning effort, acceptance checks, and explicit cold/warm cache conditions:

| Arm | Behavior |
|---|---|
| Tools baseline | Existing tools, automatic code seed disabled |
| Current | Current frozen hybrid seed and tools |
| Proposed | Small header, request evidence, visibility reuse; add E as a separate ablation |

Use at least 12 fixed scenarios with three paired repetitions per arm initially: structural navigation, localized fixes, signature changes with callers, implementation dispatch, tests, cross-file changes, follow-ups, topic changes, non-code turns, and edits with indexing lag. Treat this as a pilot; increase repetitions if model variance obscures the result. Evaluate accepted patches/tests and factual grounding, not just tool counts. Record source reads inside commands as far as instrumentation permits and label blind spots.

Proposed promotion criteria: no regression in deterministic access/revision/cache tests; no observed accepted-result quality regression in the pilot; lower median billed token cost on code tasks, with a provisional target of at least 15% against Current; and no material p95 end-to-end latency increase. Report actual distributions and uncertainty. If quality or cost is inconclusive, keep the feature opt-in and investigate rather than converting the target into a claim.

## Rollout and scope

Introduce a proposed process/config flag `CRUCIBLE_STRUCTURED_RETRIEVAL_ENABLED` with explicit pilot settings. Preserve the flag-off path and rollback without deleting conversation history. Freeze per-chat header/serialization configuration so a process restart does not silently rewrite an existing prefix. Separate stored raw evidence from model-visible history metadata, and expose evidence generation/budget information in debug artifacts.

Catalog/prompt slimming and whole-history compaction tuning remain separate measured changes so their savings are not attributed to retrieval. Community summaries, cross-repository indexing, expanded document ingestion, formal verification, and Graphify installation are future work rather than dependencies of this plan.
