# Instruction-aware candidate scoring comparison — 18 October 2026

**Keep the current implementation unchanged. This tested Kev recipe is not a reliable replacement.** Instructions reduced unwanted deliveries from old conversation context on the new cases, but also suppressed most useful candidates. The earlier diagnostic cases look more favorable to Kev; that improvement did not carry over to the newly authored cases. The current BGE trial also misses many useful files, so this is not evidence that its current policy is satisfactory.

The earlier [candidate delivery trial](</Users/pradeepkumar/projects/AI editor/docs/candidate-delivery-trial-2026-10-18.md>) and its results are preserved. Nine baseline source/result files were hashed before this comparison and all nine still match. No product code, model selection, settings or running backend were changed by this experiment. The temporary local model server stopped after evaluation.

## What was tested

We used **Kev-0.8B**, the cached winner of the [previous memory decision-model comparison](</Users/pradeepkumar/projects/AI editor/docs/superpowers/evals/2026-10-15-memory-kev-vs-reranker.md>). That earlier recommendation concerned memory selection; it does not establish code-candidate performance. Qwen was not downloaded or tested in this round. Nimble and Laya were not run.

The four configurations received identical candidate pools:

| Configuration | Conversation handling | Candidate acceptance |
|---|---|---|
| Current BGE trial | Existing cached embedding selector chooses recap/summary/previous answer at cosine >=0.55, then one bounded BGE batch | Sigmoid score >=0.10 |
| Kev, query only | Current request, no conversation background; explicit inspection-relevance rubric | Native P(true)>0.50 |
| Kev, plain context | Current request plus all raw recap/summary/previous answer; simple relevance instruction | Native P(true)>0.50 |
| Kev, conditional context | Same raw fields; current request takes priority; ignore unrelated background, resolve continuations, allow no candidates | Native P(true)>0.50 |

The conditional instruction implements the proposed experiment: it asks the model to ignore unrelated recap or summary without separate embedding comparisons or per-segment scoring. All candidates are submitted in **one catalog request** with an independent boolean decision for each file. The native runtime uses shared prefill and multiple readouts/slots; one HTTP request is not a claim of one forward pass or constant work regardless of catalog size. There are no generated explanations.

The complete rubric, inputs and labels were frozen in [protocol.json](</Users/pradeepkumar/projects/AI editor/docs/experiments/2026-10-18-instruction-reranker/protocol.json>) before inference. Protocol SHA-256: `96aaa479cc541a275d78e50af00fa67cfdfbaddd6b4f710cf86808e0cf0fb3be`.

## Cases and interpretation

There are **66 requests**, each run three times per configuration. Repetitions measure latency and stability, not additional labeled examples.

- 24 earlier calibration cases: 12 unrelated, 12 coding/follow-up. Eleven coding requests have an expected file in the frozen pool.
- 20 earlier held-out diagnostic cases: ten unrelated, ten coding/follow-up. Nine coding requests have an expected file in the pool. These were already inspected during earlier experiments, so they are not a fresh independent validation set.
- 22 newly authored cases: six unrelated, 16 coding/follow-up. All expected files are present. These include selective recap/summary relevance, topic switches, implicit continuations, general questions, status requests, and greetings followed by genuine code requests.

The new cases were authored and labeled before inference, but have **not been independently human-labeled**. Their fixed seven-file pool uses actual file paths and selected AST symbol names/types, without source bodies. Earlier cases retain their frozen hybrid-retrieval metadata. The two sets differ in metadata and task distribution; they should be read separately.

“Recovered” means at least one expected file passes the threshold, not that every necessary file was delivered or that an agent completed the task correctly. Unlisted coding files are not automatically counted as false positives because expected-path labels are incomplete. For unrelated cases, no code inspection is needed, so any delivered file counts as an unwanted delivery.

## Fixed-policy results

Each cell is requests, not candidate pairs. The coding denominator counts requests whose expected file was available in the pool. Two earlier coding misses are therefore attributed to the frozen retrieval pool rather than to the judge.

| Configuration | Earlier holdout: expected file recovered | Earlier holdout: unwanted deliveries | New cases: expected file recovered | New cases: unwanted deliveries | New follow-ups recovered |
|---|---:|---:|---:|---:|---:|
| Current BGE trial | 2/9 | 0/10 | 3/16 | 0/6 | 1/3 |
| Kev, query only | 6/9 | 2/10 | 1/16 | 0/6 | 0/3 |
| Kev, plain context | 8/9 | 3/10 | 4/16 | 4/6 | 1/3 |
| Kev, conditional context | 7/9 | 3/10 | 1/16 | 0/6 | 0/3 |

On the new cases, adding the conditional instruction to Kev eliminated four unwanted request-level deliveries compared with plain context, while losing three of its four recovered coding requests. It did not improve useful-file recovery relative to query only. On the earlier holdout it recovered one more coding request than query only, but also admitted one more unrelated request.

This is not just a threshold issue. Before any acceptance cutoff, expected-file mean reciprocal rank on the new coding cases was **0.679 for BGE**, **0.475 for query-only Kev**, **0.579 for plain-context Kev**, and **0.513 for conditional-context Kev**. Rank alone does not measure all useful-file coverage, but lowering a cutoff cannot correct the ordering itself.

## Cutoffs selected on calibration only

The frozen selection rule requires zero unrelated deliveries on calibration, then maximizes expected-file query recovery, minimizing delivered rows on ties. No cutoff was selected using either holdout. The final tie breaker is the lower numeric cutoff.

| Configuration | Calibration-selected cutoff | Calibration recovered | Earlier holdout recovered / unwanted | New cases recovered / unwanted |
|---|---:|---:|---:|---:|
| BGE | >=0.588395 | 3/11 | 1/9; 0/10 | 0/16; 0/6 |
| Kev, query only | >0.498394 | 9/11 | 6/9; 2/10 | 1/16; 0/6 |
| Kev, plain context | >0.751542 | 3/11 | 2/9; 1/10 | 0/16; 0/6 |
| Kev, conditional context | >0.537280 | 9/11 | 6/9; 3/10 | 1/16; 0/6 |

Values above are rounded for display; [analysis.json](</Users/pradeepkumar/projects/AI editor/docs/experiments/2026-10-18-instruction-reranker/analysis.json>) retains exact cutoffs. Calibration did not produce a policy that reliably retains useful new code candidates. These are diagnostic cutoffs, not proposed product defaults.

## Concrete decisions

- **Topic switch:** “Actually investigate authentication refresh handling instead.” The BGE selector retained the old visibility recap and summary, then selected `candidate_delivery.py` at 0.103 while scoring the expected authentication file near zero. This demonstrates the suspected embedding gate weakness. Conditional Kev rejected every candidate, including the authentication file at 0.339; it avoided the old-file delivery but did not recover the new location.
- **Continuation:** “Go ahead with that change,” with an explicit recap naming `CandidateDelivery.deliver`. Neither current BGE nor conditional Kev recovered that file at their fixed cutoffs. Plain Kev selected other candidate metadata instead. Explicit background alone did not make this reliable.
- **Greeting plus coding:** “Hello! Please inspect the code that filters candidate rows.” Conditional Kev recovered the expected gate file at 0.574. This case was not treated as a greeting-only bypass.
- **Acknowledgement with old coding background:** “Thanks, that explains it.” Plain Kev delivered candidate files; conditional Kev rejected all. The instruction helped here.
- **Earlier implicit follow-up:** “What about its failure handling?” Conditional Kev recovered an expected file that query-only Kev missed. However, it recovered only one of the two earlier held-out follow-ups and none of the three new ones at the fixed cutoff.

Exact per-file scores, including all rejected expected files, are retained in the raw results. There is no post-hoc relabeling of these cases.

## Latency and memory

Both evaluations ran sequentially on the same development Mac. BGE and its embedder reported `mps:0`. The cached native runtime reports an Apple M3 Pro Metal device and Kev was launched with `-ngl all`; the log level did not emit individual layer-offload details. This is not a benchmark on a 16 GB MacBook Air.

| Configuration | Timed catalog requests | Median | p95 | Maximum |
|---|---:|---:|---:|---:|
| Current BGE trial, including context selector | 198 | 40 ms | 65 ms | 242 ms |
| Kev, query only | 198 | 827 ms | 1,001 ms | 1,117 ms |
| Kev, plain context | 198 | 417 ms | 509 ms | 750 ms |
| Kev, conditional context | 198 | 838 ms | 995 ms | 1,187 ms |

Conditional Kev is about **21 times the median scoring latency** of this BGE replay, adding roughly **0.80 seconds** before retrieval-independent downstream work. Query-only Kev uses the same long rubric; the much shorter plain rubric is faster even though it includes background. These arms change wording and input length together, so their latency difference is not solely a cost of interpreting context.

BGE process peak RSS was **1.14 GiB**, including the embedder. Kev sampled process peak RSS was **3.47 GiB**, covering all its arms. RSS is not complete unified-memory accounting, and a lifetime resource peak and periodically sampled process peak are not identical measurements. Cold model load was about 5.84 seconds for BGE plus embedder and 1.02 seconds for Kev; cold startup is excluded from the latency table.

Timings cover context selection/formatting plus BGE scoring, or the complete Kev local HTTP catalog request and score parsing. Retrieval, disk reads, result-file writes, primary agent calls, and production queue contention are excluded. BGE’s context cache is reused across repetitions. All decisions were identical across three repetitions, with no scoring/request failures: 198 BGE and 594 Kev timed requests completed.

The previous trial’s local timing ran without GPU access. Those CPU measurements are preserved and must not be used as the latency baseline for this GPU-capable comparison.

## Limits and next experiment

This isolates candidate judgment on **fixed pools**. It does not rerun retrieval with model-selected context, so it cannot establish the quality or latency of replacing context selection throughout the pipeline. A scorer cannot recover a file absent from its pool. BGE receives its existing 512-token bounded pair representation; Kev sees the full catalog and raw background within an 8,192-token slot. The comparison measures practical policies, not the isolated effect of model weights. Candidate order was fixed, and order sensitivity was not evaluated.

No end-to-end task quality, agent fallback reads, total session tokens, provider cost or live stale-source behavior was measured here. Sending fewer candidates while missing useful locations can increase later tool calls, so fewer rows are not proof of token savings. Source delivery and visibility logic were not changed.

**Do not adopt this Kev rubric as the default.** Preserve the BGE trial as the baseline, while treating its low recovery and context-switch failures as unresolved. A separate Qwen experiment remains reasonable: the official [Qwen3-Reranker-0.6B model card](https://huggingface.co/Qwen/Qwen3-Reranker-0.6B) supports custom instructions and yes/no relevance scoring. That capability is not evidence it will solve this benchmark. Use a frozen rubric, retain rejection and useful-file recovery together, and add new independently reviewed cases before making a release claim. The tested Kev interface and format are documented by its [GGUF model card](https://huggingface.co/ggml-org/Kev-0.8B-GGUF).

## Reproduction and retained evidence

All files for this comparison are under [the experiment directory](</Users/pradeepkumar/projects/AI editor/docs/experiments/2026-10-18-instruction-reranker>):

- `baseline-manifest.json`: original hashes and baseline configuration; `validation.json` confirms all nine original files are unchanged and validates all timed outputs.
- `freeze.py`, `protocol.json`, `protocol.sha256`: input construction, frozen labels/rubrics and fingerprint. Freezing refuses to overwrite an existing protocol. Earlier reused metadata is embedded in the protocol; reconstructing the freeze also needs the earlier ignored raw-pair file.
- `run.py`, `bge-results.json`, `kev-results.json`: runners and all raw decisions/timings; result runners refuse to overwrite previous results.
- `analyze.py`, `analysis.json`: calibration-only selection, all split metrics, ranking, timings and stability.
- `device-check.json`: native runtime device inventory and GPU configuration caveat. The verbose local server log is ignored by Git.

Kev used cached `ggml-org/Kev-0.8B-GGUF`, revision `e551e319d483ff57e1ff208924b349d397cffc1c`, BF16 weight SHA-256 `5bb957b9369e71b44dd6b80546992033f5fbdd128061727f122c7869e2d90de9`, with cached llama.cpp b11642 (`2639a3b4e`). Model hashes were checked before launch. Network model downloads were disabled; candidate metadata stayed local. The local test server is confirmed stopped.
