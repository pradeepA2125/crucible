# Retrieval and candidate-pipeline latency — 18 October 2026

**The vector database path is not the main source of the roughly 300 ms retrieval time.** Query embedding plus semantic search took about 30 ms. Snapshot loading/parsing and Python graph processing account for most of the wrapper's remaining time.

## Measured candidate pipeline

The actual controller and a new-turn candidate delivery instance were run with the existing hybrid index. Each configuration used seven earlier fixture queries and three warm repetitions, for 21 timed samples. Initial model loading, the first query, and a pass across all seven query shapes were excluded from warm statistics. BGE and Qwen ran in separate sequential processes on Metal. There was no main-model provider call, backend restart or production configuration change.

| Stage | BGE trial median | Qwen plain-context median |
|---|---:|---:|
| Embedding-based recap/summary selection | 7 ms | None; plain context retains raw background |
| Hybrid retrieval and candidate construction | 300 ms | 314 ms |
| Candidate reranking/filtering | 51 ms | 385 ms |
| **Measured total through candidate delivery** | **339 ms** | **699 ms** |
| **Total p95** | **391 ms** | **826 ms** |

Totals were measured directly; component medians need not sum to the median total. Qwen's earlier 327 ms scoring result came from a different, fixed-pool benchmark. It was not added to retrieval to invent an end-to-end figure.

These timings exclude primary model calls, memory recall, prompt assembly and long-history source-visibility checks. The delivery history was empty, so this measures initial discovery rather than the cheaper reuse path or the cost of validating many visible reads. Model load was about 5.76 seconds for the BGE/embedder combination and 4.53 seconds for Qwen/embedder; first-query totals after load were 579 ms and 987 ms respectively. These are development-host measurements, not production latency guarantees.

## Snapshot load versus processing

A separate low-overhead run instrumented the existing retrieval methods with temporary process-local wrappers. It used the same seven requests for three warm repetitions after an excluded warm-up pass. It did not load a reranker.

| Retrieval component | Warm median |
|---|---:|
| Read graph snapshot text | 19 ms |
| Decode snapshot JSON | 64 ms |
| **Read + decode, measured together** | **84 ms** |
| Query embedding + vector database search | 30 ms |
| Graph/candidate processing, excluding semantic query | 198 ms |
| Other wrapper/deallocation work | 6 ms |
| **Measured retrieval total** | **314 ms** |

These are medians of separate distributions, so they will not sum exactly. The “processing” figure is the measured context-building duration minus its nested semantic query. No cProfile-instrumented durations are used in this table.

## What is processed

The snapshot is roughly 32 MB, with about 26,000 graph nodes and 71,000 edges. On each request, the discovery path:

1. Reads and decodes the snapshot, normalizes/copies node metadata and applies path/test eligibility rules.
2. Scores node names and paths against current-request keywords and supplemental context terms, then combines those scores with semantic file scores and sorts matches.
3. Builds node lookup data and walks graph edges to identify relationships and connected files.
4. Selects the bounded file catalog and constructs its symbol locations, read hints and relationship metadata.

This is metadata and graph work; it does not deliver full source bodies in discovery mode. The index is already built. Existing path normalization is cached, but the snapshot decoding, substantial per-node work and graph traversal are still repeated. A diagnostic call profile confirms tens of thousands of path-eligibility checks and repeated path-object parsing; cProfile increases execution time and is used only to identify work, not to establish latency.

The next optimization targets are a parsed/normalized snapshot cache with revision-aware invalidation, reusable node/file/adjacency lookups, and per-file path classification rather than repeated per-symbol path parsing. Query-dependent scores and filters must remain query-dependent. No such product optimization was applied by this measurement.

## Evidence

The [experiment directory](</Users/pradeepkumar/projects/AI editor/docs/experiments/2026-10-18-instruction-reranker>) contains:

- `profile_pipeline.py`, `pipeline-bge.json`, `pipeline-qwen.json`: actual controller/delivery runs and per-stage measurements. Both runs verified semantic hits for every query and used the same unchanged snapshot during their measured runs.
- `profile_retrieval_stages.py`, `retrieval-stages.json`: low-overhead snapshot read/decode, semantic query and processing breakdown.
- `profile_retrieval.py`, `retrieval-call-profile.json`: diagnostic call counts and hot functions, with profiler-overhead caveat.

All inference stayed local. Background index maintenance was suppressed in the measurement process; the index was not rebuilt. The live watcher may update snapshots between separate diagnostic runs, so the diagnostic profiles are not an assertion that the graph stayed unchanged throughout the entire conversation. Original baseline source/result hashes remain unchanged. The scripts pass Ruff; pipeline output checks verify semantic results, device selection and stage accounting.
