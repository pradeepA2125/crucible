# Graphify and our Rust indexer: context and token use

Analysis date: 17 October 2026. This is a source inspection and read-only local probe, not a matched model benchmark. No product behavior was changed.

Our indexer already contains the central capability under discussion: a persistent symbol graph with file/line locations and Calls, Imports, References, Inherits, and Implements edges. The likely opportunity is improving how agents retrieve and consume that graph. Replacing Rust parsing with another indexer is not justified by this inspection.

## What was inspected

- Graphify's public `v8` branch: `graphify/serve.py`, `graphify/always_on/agents-md.md`, architecture documentation, and published benchmarks. Cloud internals were not available for this comparison.
- Our Rust parser, graph model, service, and LSP resolver.
- Our Python graph walker, initial retrieval construction, planning/execution registries, controller payload builder, and tool loop.
- The existing local snapshot, generated 16 October 2026 at 22:06:43 IST: 40,531 nodes, 88,503 edges, and 1,263 File nodes. The snapshot is persisted state, not a fresh rebuild of the current checkout.
- Thirty most recently modified completed main-chat turns with saved controller artifacts, selected from the 60 most recently modified thread directories. These cover nine distinct chats. Experiments, UI work, and follow-up turns are included; this is not a representative task suite.

## The useful differences

Graphify's public query implementation scores question terms against indexed labels, paths, rationale, and attributes, chooses seeds, traverses their graph neighborhood, and renders nodes and actual connecting edges. It also provides path queries. Its default output target is approximately 2,000 tokens, with exceptions that can exceed that target. Its installed instruction tells assistants to query before their first source search/read. Sources: [query code](https://github.com/Graphify-Labs/graphify/blob/v8/graphify/serve.py), [installed instruction](https://github.com/Graphify-Labs/graphify/blob/v8/graphify/always_on/agents-md.md).

Our corresponding differences are below. These are differences in delivery and integration, rather than proof that Graphify produces better answers or lower bills.

### 1. The agent-facing graph tool requires the entry point to be known

`GraphWalker._resolve_roots` accepts an exact workspace-relative file or `file:Symbol`, with case-sensitive symbol matching. It does not accept an unqualified symbol or a question. See `services/agentd-py/agentd/retrieval/graph_walker.py:421` and the tool schema at `services/agentd-py/agentd/planning/registry.py:99`.

Notably, the Rust graph already implements `GraphQueryMode::SymbolName` and a symbol-name index at `services/indexer-rs/src/graph.rs:426`. The Python agent tool independently walks the snapshot and does not expose that lookup mode. This is an integration gap, not missing index data.

Local probes:

| Input to our walker | Outcome |
|---|---|
| `retrieval seed` | No matching root |
| `_compute_retrieval_seed` | No matching root |
| `services/agentd-py/agentd/chat/controller.py:_compute_retrieval_seed` | Five neighbors; 786 characters including roots |

The successful result includes `load_context`, `as_prompt_payload`, `compact_context_enabled`, and `bounded_tree`. It is useful compact context once the entry point is known. The agent must currently find that entry point through another surface, such as search, initial evidence, or existing conversation context.

### 2. The initial context largely removes the graph's explanatory structure

`RetrievalContext.as_prompt_payload` emits repository structure, file outlines, evidence excerpts, diagnostics, stats, and `graph_neighbor_files`. That last field is a list of paths; it does not retain the source/target symbols, relation kind, or direction that explains why a neighbor matters. The computed `graph_neighbors`, `related_files`, and `related_symbols` fields are not serialized directly. See `services/agentd-py/agentd/retrieval/artifact_client.py:76`.

Evidence excerpts still provide useful source context. The narrower finding is that the initial graph expansion becomes a list of places to investigate, rather than a compact explanation of the connections between them. The agent then needs additional queries/reads to reconstruct those connections.

### 3. Availability is not translating into use in the sampled turns

The thirty-turn sample contains 312 saved controller-step artifacts. In those saved actions:

| Observation | Count |
|---|---:|
| Turns with `query_graph` in the tool catalog | 30 |
| Issued `query_graph` calls | 0 |
| Issued `read_file` calls | 179 |
| Issued `search_code` calls | 21 |
| Issued `list_directory` calls | 22 |

Counts are issued calls from each turn's saved controller actions, excluding replayed history. They do not include separate child/task traces or source reads performed inside shell commands. Missing artifacts may omit actions. These numbers show non-use in this sample; they do not show that every sampled task needed graph traversal or that initial retrieval provided no benefit.

Automatic hybrid retrieval is not a `query_graph` action and is not counted above. When `load_context` runs, `_build_context` combines keyword overlap on symbol names/paths with semantic file scores (configured weights 0.35 and 0.65); semantic retrieval requires an enabled, ready index. Thus zero graph-tool calls must not be interpreted as zero index-assisted context. In the controller, `_retrieval_seed` is invoked each turn but returns the existing seed after the first computation. Fresh tool results append to history on demand; the post-edit `retrieval_refresh` callback appends a changed-files note, not newly retrieved code excerpts. Task orchestration separately calls `load_context` for task setup and certain execution/approval paths.

Some prompts explicitly position graph use after reading. For example, the planning registry describes it as “Use this AFTER reading a file.” The controller requires behavioral claims to be grounded in source excerpts, at `services/agentd-py/agentd/chat/controller_prompts.py:435`. That source-grounding rule is appropriate. It means a graph can save discovery reads, but generally cannot replace implementation reads.

### 4. There is a reproducible selection problem on files with many connections

File-query results are sorted with outgoing dependencies first, alphabetically, and then truncated to the shared limit. See `services/agentd-py/agentd/retrieval/graph_walker.py:340`.

For `services/agentd-py/agentd/chat/controller.py`, the snapshot contains 83 distinct outgoing workspace files and 82 distinct incoming workspace files. The public walker returns:

| Requested limit | Outgoing returned | Incoming returned | Truncated |
|---|---:|---:|---|
| 20, the default | 20 | 0 | Yes |
| 60, the maximum | 60 | 0 | Yes |

The output warns about truncation; it does not falsely claim completeness. Nevertheless, increasing the limit cannot reveal incoming dependents in this case. Separate direction controls, balanced budgets, or pagination would make the result more useful and reduce recovery queries/searches.

### 5. Multi-hop output loses the full connecting path

`GraphNeighbor` records the reached node, relation kind, local direction, and distance. It does not record the predecessor from which the node was reached. The renderer prints an arrow and a distance, not the actual source and target of each hop. See `services/agentd-py/agentd/retrieval/graph_walker.py:53` and `services/agentd-py/agentd/planning/registry.py:385`.

At depth one this is straightforward. At depth two or three, interpreting how an implementation connects through a declaration can require another query. Returning explicit edge triples or a short path would retain the evidence already discovered by traversal.

The Rust `GraphQueryResponse` already carries nodes and edges; the Python surface reduces this structure into neighbor records.

### 6. Initial context is fixed to the chat, while requests evolve

`ChatController._retrieval_seed` computes and persists one seed for the lifetime of the chat, intentionally preserving the provider's cache prefix. Later user goals do not replace it. After edits, the refresh callback adds a pointer note rather than recomputing a graph slice. See `services/agentd-py/agentd/chat/controller.py:696` and `:1293`.

This is a valid cache optimization, but caching and relevance are different concerns. A seed built for the first topic can become weak context for a later task. A small stable workspace header plus bounded goal-specific evidence in the changing tail would preserve the distinction. The effect on billed tokens must be measured because changing the tail and shortening the prefix have provider-dependent cache costs.

### 7. Other context can dominate the total

In the thirty-turn sample, compact-JSON logical character counts were:

| Component | Median | Maximum |
|---|---:|---:|
| System instructions/catalog | 67,518 | 71,901 |
| Initial retrieval seed | 25,068 | 33,661 |
| Repository structure inside seed | 3,415 | 3,415 |
| History at the first saved step | 151,216 | 1,433,497 |

These are characters, not provider tokens. Nested seed fields are not additive to the seed total. The historical 10 October profile had an 84,985-character tree, but that is not the tree size in these newer traces and should not be presented as their current bottleneck.

Reducing discovery reads affects only part of the total. System/catalog overhead, accumulated tool results, command/browser/image work, reasoning/output, retries, and repeated model rounds still contribute. History compaction exists in the code; this analysis does not claim it is absent or broken. The saved histories show that a graph alone does not prevent context growth.

## Additional implementation observations

- The execution registry constructs a new `GraphWalker` for every query at `services/agentd-py/agentd/tools/registry.py:543`, whereas planning retains one. The first local query took about 2.15 seconds; subsequent queries on the same walker took about 0.6–11.4 milliseconds. This single cold/warm probe concerns latency and caching, not model-token savings.
- Our graph nodes retain a declaration line but no source end range or signature field; edges retain endpoints and kind but no call-site location or extraction provenance. See `services/indexer-rs/src/graph.rs:16`. Those additions could make source retrieval more precise, but their quality and storage costs need evaluation.
- The snapshot returned three adjacent declaration candidates for `_compute_retrieval_seed`, at lines 718, 719, and 720. This merits checking against a fresh build before diagnosing its parser cause.
- External targets account for many stored edges. External references include legitimate library/builtin calls, so their count must not be treated as an unresolved-workspace error rate.
- Our resolver already asks language servers for definitions and implementations (`services/indexer-rs/src/resolver.rs:1`). There is no evidence here that our underlying graph must be replaced to obtain useful structural context.

## What to change and measure first

1. Expose unqualified symbol lookup and a bounded question-to-evidence operation using the existing graph and optional semantic retrieval. Return ranked seed symbols, explicit relationships, source locations/ranges, and only the relevant missing excerpts.
2. Preserve relationship triples in initial/task-specific evidence; add predecessor paths and balanced inbound/outbound selection. Avoid asking the model to reconstruct discarded graph structure.
3. Keep the stable chat prefix small and supply bounded evidence for the current task. Reuse already-visible source. Existing duplicate-call protection is based on normalized arguments plus file identity/revision metadata; range coverage is a separate possible improvement, not a reason to discard the current safeguards.
4. Evaluate identical tasks under three conditions: tools with no initial retrieval; current retrieval/tool behavior; bounded task-specific graph evidence. Keep model, effort, repository revision, cache warmness, and acceptance checks fixed. Repeat runs. Report actual uncached input, cached input, output/reasoning tokens, billed cost, steps, redundant delivered source, graph use, completion time, and accepted-result quality.

The public savings headline has not been reproduced here. The supported conclusion is that we already have the main indexing ingredients, while the agent-facing retrieval path leaves useful graph information unused or discarded and cannot control the rest of the controller's context budget.
