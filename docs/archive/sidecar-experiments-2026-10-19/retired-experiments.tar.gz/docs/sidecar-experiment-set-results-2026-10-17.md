# Sidecar experiment set: combined findings and decision

Date: 2026-10-17. Branch: `codex/sidecar-reliability-experiments`.

This completes the scoped follow-up set: current complete-function selection, shared source admission budget, moved symbols after edits, source loss through compaction, omitted evidence, and implementation tasks scored by executable checks. It builds on the [initial lifecycle/context experiments](sidecar-experiments-2026-10-17.md) and [verified-range reuse experiments](sidecar-source-reuse-experiments-2026-10-17.md).

**Decision:** retain the reproduced lifecycle fixes. Prefer verified source delivery with current syntax selection over the earlier unverified bundles and stale-range delivery. Keep the delivery prototypes opt-in: this small experiment supports the design, not a broad production token-saving claim or deployment. No running extension/backend was upgraded or reconfigured; all live trials used isolated synthetic workspaces.

## Completed scope

| Experiment | What was checked | Result |
|---|---|---|
| Complete function | Return statement is 40 lines beyond the start, outside the old excerpt | Current-syntax delivery supplies the complete function; previous range delivery needs another read. |
| Moved symbol | External edit inserts 60 lines, changes the return, and leaves the graph at its old positions | Exact named function is located in current syntax and delivered with the current file hash. |
| Related versus different request | Unchanged follow-up and a switch to another file | Visible current bodies can be reused; a different request selects new source. |
| Compaction | Real compactor removes source; summary carries an obsolete value | Current body is restored and the current value/location is returned. |
| Shared budget | Whole serialized source entries must fit a single admission budget | Unit fixture admits one of two bodies; zero-budget live variant omits bodies and the model retrieves needed source. |
| Edit-read watermark | Syntax inspection reads bytes that the model never receives | Inspection and budget-omitted source do not advance the existing stale-edit read watermark. Only admitted or already-visible current bodies do. |
| Degraded selection | Parse error, ambiguous symbol name, unsupported language or incomplete source inspection | Explicit bounded-range fallback; no complete-function claim. |
| Selection race | File changes between syntax inspection and delivery | Revision mismatch explicitly downgrades the selection claim. |
| Implementation: moved function | Fix negative-input clamping after external movement | Actual edits are scored by sealed input combinations and public tests. |
| Implementation: two-file contract | Change discount percentage units and adapt its caller, preserving the caller's old interface | Actual edited behavior is checked independently in both files, including error cases. |

## Implementation

`CRUCIBLE_VERIFIED_SOURCE_REUSE_ENABLED=1` enables verified source delivery. Adding `CRUCIBLE_SOURCE_SYNTAX_ENABLED=1` selects the new complete-function/budget path. Both default off. The previous request-bundle prototype remains separately off by default.

The syntax prototype supports **Python functions**, including asynchronous functions and decorators. It uses `ast.parse` on a complete bounded read of the current file. An exact function name present in the request takes precedence over old indexed positions. Duplicate current function names are surfaced as ambiguity. Otherwise current declarations within hinted ranges can supply candidates. This is a deliberately scoped prototype, not a universal symbol resolver.

Syntax inspection uses the existing registry's permissions, path checks and read leases. A request-local context variable suppresses read observation for inspection-only bytes. Each selected body is then read through the same tool pipeline and bound to its actual `DeliveredRead` hash/ranges. If the revision changed between selection and delivery, the complete-function claim is downgraded. Actual source bodies and revisions remain visible in outgoing history, with the manifest in the payload tail after compaction.

`CRUCIBLE_SOURCE_BUDGET_CHARS` defaults to **16,000 serialized source-entry characters** for the syntax path. The available tool-result budget, when present, can lower that limit. Whole new entries are admitted or omitted; omissions include path, range, required size and current revision. Already-visible matching bodies require no additional body admission space. There is no forced refusal of model reads: the agent can fetch omitted or insufficient evidence normally.

This budget bounds appended source entries, not the entire provider request: the existing seed, history, manifest, system prompt and schemas still consume context. There is no promise of a universally correct final-wire token budget. Syntax inspection and hash revalidation incur backend I/O and parsing on each model request; these are not counted as eliminated filesystem reads.

## Read-only matrix

Same `gpt-6.1-sol` model and high reasoning effort for all variants. Each has five scored turns: initial question, different request, unchanged follow-up, external move/edit, and post-compaction question. Functions begin after 300 comment lines and return after 40 additional function-body lines; the external edit moves one function another 60 lines. The graph remains unchanged.

All **20/20 answers** returned the correct integer and exact source location.

| Variant | Model calls | Model-requested reads | Reported input tokens | Cached input | Uncached input |
|---|---:|---:|---:|---:|---:|
| Baseline | 9 | 4 | 75,221 | 59,904 | 15,317 |
| Verified old ranges | 9 | 4 | 86,350 | 61,440 | 24,910 |
| Current complete functions | 5 | 0 | 41,072 | 28,800 | 12,272 |
| Complete-function selector, zero source budget | 9 | 4 | 82,979 | 54,528 | 28,451 |

Current complete-function delivery reduced model calls from **9 to 5**, total reported input by **45.4%**, and uncached input by **19.9%**, relative to this baseline run. Every zero-budget omission was handled correctly; the unchanged follow-up reused its already-visible manual read. The extra inspection/manifest overhead makes zero-budget mode more expensive than baseline. A production policy should avoid speculative inspection when useful delivery is impossible.

These are provider-reported token totals, not character estimates. Cached tokens are included in input totals; subtracting them describes uncached input but does not calculate billing. Run order/cache behavior can materially affect those figures. This is a small deterministic synthetic corpus, not a statistically representative benchmark.

Raw matrix: [moved-functions-budget.json](experiments/2026-10-17-complete-source/moved-functions-budget.json).

## Implementation trials

Three variants receive each task: baseline, verified old ranges and current complete-function delivery. Each trial first has an ordinary read-only question to pin its initial seed. The moved-function case is then changed externally. The implementation turn uses the real controller, real patch engine, shadow workspace and promotion path, rather than scripted edits.

Only read/search/list, todos, edits and the exact fixture unittest command are available. The model can run `python3 -m unittest discover -s tests -v`; all other shell commands are refused. The additional correctness oracle remains outside the model's workspace and runs afterward in a fresh Python process. The runner checks public tests and verifies that their contents were not changed. The oracle is separately tested to fail on original buggy behavior and pass on the expected fix.

Detailed measurements and all before/after source are retained in [implementation.json](experiments/2026-10-17-complete-source/implementation.json). The table in [summary.json](experiments/2026-10-17-complete-source/summary.json) aggregates model calls, tools and provider usage without mixing the initial warm-up question into edit-turn totals.

| Task / variant | Model calls | Reported input tokens | Sealed checks | Public tests unchanged |
|---|---:|---:|---|---|
| Moved clamp / baseline | 4 | 39,764 | Pass | Yes |
| Moved clamp / verified old ranges | 5 | 65,044 | Pass | Yes |
| Moved clamp / current complete functions | 3 | 31,320 | Pass | Yes |
| Two-file contract / baseline | 5 | 57,068 | Pass | Yes |
| Two-file contract / verified old ranges | 4 | 52,934 | Pass | Yes |
| Two-file contract / current complete functions | 4 | 52,531 | Pass | Yes |

All **6/6 implementation trials** passed sealed checks and public tests without modifying the tests. Current complete-function delivery used **7 model calls** across the two tasks versus baseline's **9**, with **13.4% fewer reported input tokens**. The gains are smaller than for simple questions. The old-range variant improved one task but worsened the other; adding verified excerpts alone is not a reliable efficiency improvement. On the two-file task the complete-function variant still searched before editing, which is appropriate when the task needs caller evidence beyond one function body. Every implementation variant ran the public test command and submitted actual changes; no runtime/tool failures were recorded.

The six warm-up questions, twenty read-only matrix turns and six edit turns give **32 completed live turns** in this final experiment set. They are not independent random samples, and each implementation comparison contains only one run per task/variant. Timing and token counts can vary with model behavior and cache state. No cached-token breakdown was added to the implementation runner, so its input reductions must not be interpreted as equal billing reductions.

## Validation and practical limits

The focused suite passes **154 tests**, including the prior retrieval/read/history/compaction/native serialization regressions, seven current-syntax/budget/race tests and two sealed-oracle validation tests. Ruff and `git diff --check` pass for this iteration. The Rust implementation is unchanged from the earlier lifecycle-fix iteration, whose full 56-test suite passed.

The completed experiment set validates the mechanism under the tested conditions. It does not establish production code-review quality, complete impact traversal, embedding quality or a replacement decision between indexing engines. Live trials use graph/keyword fallback; no embedding model or real LSP ran. Production memory-v2, child-agent inheritance, shadow overlays and all language-specific syntax selectors remain outside this set.

Python syntax selection currently requires a full file within the existing bounded reader's limits. Larger files, unsupported languages and invalid syntax fall back rather than claiming complete bodies. Revision checks reduce stale-range errors but do not lock source through model inference; existing stale-edit guards remain necessary. Manifest and source budgeting must eventually be integrated with final provider request preparation before enabling broadly.

## Adoption decision

- **Keep:** lifecycle corrections and their regression tests.
- **Keep as the preferred opt-in design:** current source body delivery, file hash/range provenance, visible-body reuse, restoration after compaction, current syntax re-resolution and explicit budget omissions.
- **Do not enable by default:** the unverified append-every-query bundle, old-range-only delivery, or this Python-only prototype across all production workspaces.
- **Do not claim:** a general 80% saving, superiority over another indexer, or correctness from an empty/bounded graph result.

The set is complete. Production work is distinct from further deliberation: integrate language-aware body selection and aggregate admission at the provider boundary, preserve existing edit/read safeguards, and make per-task measurements visible. The experiments favor improving the evidence the harness delivers and can reuse; they provide no reason to replace the Rust indexer wholesale.
