"""Frozen-pool local BGE versus Kev comparison; no hosted provider or product changes.

Run 'bge' then 'kev' sequentially with the installed local-model Python environment.
Kev uses already-cached weights and a temporary loopback-only native decision server.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import random
import socket
import subprocess
import sys
import threading
import time
import urllib.request
from pathlib import Path

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
TMP = Path("/private/tmp/crucible-decision-models-2026-10-15")
sys.path.insert(0, str(ROOT / "services/agentd-py"))
PROTOCOL_BYTES = (OUT / "protocol.json").read_bytes()
PROTOCOL_HASH = hashlib.sha256(PROTOCOL_BYTES).hexdigest()
P = json.loads(PROTOCOL_BYTES)
if PROTOCOL_HASH != (OUT / "protocol.sha256").read_text().strip():
    raise RuntimeError("Frozen protocol changed")
REPETITIONS = 3


def save(path: Path, data: dict) -> None:
    path.write_text(json.dumps(data, indent=2) + "\n")


def new_result(name: str) -> tuple[Path, dict]:
    target = OUT / (name + "-results.json")
    if target.exists():
        raise RuntimeError("Do not overwrite an existing run: " + str(target))
    return target, {"protocol_sha256": PROTOCOL_HASH, "repetitions": REPETITIONS,
                    "cases": {}, "completed": False}


def run_bge() -> None:
    import resource

    import torch

    from agentd.local_models import LocalModels
    from agentd.memory.reranker import Reranker
    from agentd.retrieval.context_selection import SemanticContextSelector

    target, data = new_result("bge")
    capability = LocalModels(True)
    selector = SemanticContextSelector.from_env({"CRUCIBLE_CODE_CANDIDATE_TRIAL": "1"}, capability)
    assert selector is not None
    ranker = Reranker(local_models=capability, bounded=True)
    started = time.perf_counter()
    selector.embedder.warmup()
    ranker.warmup()
    if not capability.ready("reranker") or not capability.ready("embedder"):
        raise RuntimeError("Local BGE models did not become ready")
    data.update(model="BAAI/bge-reranker-base", activation="sigmoid", max_length=512,
                load_seconds=time.perf_counter() - started,
                device=str(ranker._model.model.device), mps_available=torch.backends.mps.is_available(),
                embedder_device=str(selector.embedder._model.device), threads=torch.get_num_threads())
    if not data["device"].startswith("mps"):
        raise RuntimeError("This comparison requires Metal/MPS; retain prior CPU runs separately")
    for case in P["cases"]:
        data["cases"][case["id"]] = {"runs": []}
    order = [c["id"] for c in P["cases"]]
    by_id = {c["id"]: c for c in P["cases"]}
    rng = random.Random(20261018)
    for repetition in range(REPETITIONS):
        rng.shuffle(order)
        for ident in order:
            case = by_id[ident]
            started = time.perf_counter()
            signals = selector.select(case["query"], recap=case["recap"], summary=case["summary"],
                                      closing=case["closing"])
            formatted = {"Q": case["query"], "R": "\n".join(
                signals.get(k, "") for k in ("recap", "summary")), "C": signals.get("closing", "")}
            result = ranker.score_context(formatted, case["documents"])
            data["cases"][ident]["runs"].append({
                "scores": result.scores, "seconds": time.perf_counter() - started,
                "selected_context": signals, "retained_query": result.query,
                "max_pair_tokens": result.max_pair_tokens,
                "truncated_signals": result.truncated_signals,
                "truncated_documents": result.truncated_documents,
            })
        save(target, data)
        print("BGE repetition", repetition + 1, "complete", flush=True)
    data["sampled_peak_rss_bytes"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    data["completed"] = True
    save(target, data)


HTTP = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def http(port: int, path: str, payload=None, timeout=30):
    request = urllib.request.Request(
        f"http://127.0.0.1:{port}" + path,
        data=json.dumps(payload).encode() if payload is not None else None,
        headers={"Content-Type": "application/json"},
    )
    with HTTP.open(request, timeout=timeout) as response:
        return json.load(response)


def payload(case: dict, arm: str) -> dict:
    state = {"current_request": case["query"]}
    if arm != "query_only":
        state.update(recap=case["recap"], summary=case["summary"],
                     previous_answer=case["closing"])
    state["candidates"] = [{"id": f"c{i}", "metadata": doc}
                           for i, doc in enumerate(case["documents"])]
    rule = P["plain_rule"] if arm == "plain_context" else P["rule"]
    questions = {
        f"c{i}": {"type": "noul", "instructions": f"Judge candidate c{i}. " + rule,
                   "criteria": {"true": "Inspecting this file materially helps satisfy the current request.",
                                "false": "This file is irrelevant or unnecessary for the current request."}}
        for i in range(len(case["documents"]))
    }
    return {"state": state, "questions": questions}


def answers(raw: object, count: int) -> list[float]:
    found = {}

    def visit(value):
        if isinstance(value, dict):
            for key, item in value.items():
                if key in {f"c{i}" for i in range(count)} and isinstance(item, dict) and "noul" in item:
                    number = float(item["noul"])
                    if not math.isfinite(number) or not 0 <= number <= 1:
                        raise ValueError("Invalid native decision probability")
                    found[key] = number
                visit(item)
        elif isinstance(value, list):
            for item in value:
                visit(item)

    visit(raw)
    if len(found) != count:
        raise ValueError("Missing native decisions; do not invent zero scores")
    return [found[f"c{i}"] for i in range(count)]


def run_kev() -> None:
    target, data = new_result("kev")
    model = TMP / "ggml-org--Kev-0.8B-GGUF/Kev-0.8B-BF16.gguf"
    metadata = json.loads((ROOT / ".crucible/state/eval/memory-decision-models-2026-10-15/manifest.json")
                          .read_text())["models"][0]
    digest = hashlib.sha256()
    with model.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    if digest.hexdigest() != metadata["sha256"]:
        raise RuntimeError("Cached Kev weight hash changed")
    with socket.socket() as probe:
        probe.bind(("127.0.0.1", 0))
        port = probe.getsockname()[1]
    command = [str(TMP / "llama-b11642/llama-b11642/llama-server"), "-m", str(model),
               "--host", "127.0.0.1", "--port", str(port), "-c", "65536", "-np", "8",
               "-b", "4096", "-ub", "1024", "-ngl", "all", "--no-webui"]
    data.update(model="ggml-org/Kev-0.8B-GGUF BF16", weight_sha256=digest.hexdigest(),
                model_revision=metadata["revision"], command=command, rss_samples_kib=[])
    stop = threading.Event()
    with (OUT / "kev-server.log").open("w") as log:
        started = time.perf_counter()
        process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT)

        def sample():
            while not stop.wait(.25):
                try:
                    data["rss_samples_kib"].append(int(subprocess.check_output(
                        ["ps", "-o", "rss=", "-p", str(process.pid)], text=True).strip()))
                except (ValueError, subprocess.CalledProcessError):
                    pass

        sampler = threading.Thread(target=sample, daemon=True)
        sampler.start()
        try:
            for _ in range(120):
                if process.poll() is not None:
                    raise RuntimeError("Temporary Kev server exited; inspect its log")
                try:
                    if http(port, "/health", timeout=1).get("status") == "ok":
                        break
                except Exception:
                    pass
                time.sleep(.5)
            else:
                raise RuntimeError("Kev startup deadline reached")
            data["load_seconds"] = time.perf_counter() - started
            data["server_props"] = http(port, "/props")
            arms = ["query_only", "plain_context", "conditional_context"]
            for arm in arms:
                answers(http(port, "/v1/systemone", payload(P["cases"][12], arm)),
                        len(P["cases"][12]["documents"]))
            by_id = {c["id"]: c for c in P["cases"]}
            order = [(c["id"], arm) for c in P["cases"] for arm in arms]
            for ident, arm in order:
                data["cases"].setdefault(ident, {})[arm] = {"runs": []}
            rng = random.Random(20261018)
            for repetition in range(REPETITIONS):
                rng.shuffle(order)
                for index, (ident, arm) in enumerate(order):
                    case = by_id[ident]
                    body = payload(case, arm)
                    started = time.perf_counter()
                    try:
                        raw = http(port, "/v1/systemone", body)
                        row = {"scores": answers(raw, len(case["documents"])),
                               "seconds": time.perf_counter() - started}
                    except Exception as exc:
                        row = {"error": type(exc).__name__ + ": " + str(exc),
                               "seconds": time.perf_counter() - started}
                    data["cases"][ident][arm]["runs"].append(row)
                    if index % 22 == 0:
                        save(target, data)
                        print("Kev repetition", repetition + 1, "catalogs", index + 1,
                              "/", len(order), flush=True)
                save(target, data)
            data["completed"] = True
        except Exception as exc:
            data["fatal_error"] = type(exc).__name__ + ": " + str(exc)
            raise
        finally:
            process.terminate()
            try:
                process.wait(timeout=15)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)
            stop.set()
            sampler.join(timeout=2)
            data["server_stopped"] = process.poll() is not None
            data["sampled_peak_rss_kib"] = max(data["rss_samples_kib"], default=0)
            save(target, data)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("model", choices=("bge", "kev"))
    args = parser.parse_args()
    run_bge() if args.model == "bge" else run_kev()
