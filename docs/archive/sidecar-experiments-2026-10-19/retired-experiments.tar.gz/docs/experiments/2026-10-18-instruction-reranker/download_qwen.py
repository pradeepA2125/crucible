"""Download public, revision-pinned Qwen weights into a disposable local cache."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path

os.environ["HF_HUB_DISABLE_IMPLICIT_TOKEN"] = "1"
from huggingface_hub import HfApi, snapshot_download

OUT = Path(__file__).resolve().parent
TARGET = Path("/private/tmp/crucible-qwen-reranker-2026-10-18")


def main() -> None:
    manifest = OUT / "qwen-model-manifest.json"
    if manifest.exists():
        raise RuntimeError("Keep the existing pinned model manifest")
    info = HfApi(token=False).model_info("Qwen/Qwen3-Reranker-0.6B")
    print("Downloading public Qwen revision", info.sha, flush=True)
    snapshot_download(repo_id=info.id, revision=info.sha, token=False, local_dir=TARGET,
                      allow_patterns=["*.json", "*.safetensors", "*.txt", "*.model"],
                      max_workers=4)
    files = {}
    for path in sorted(TARGET.iterdir()):
        if not path.is_file():
            continue
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
                digest.update(block)
        files[path.name] = {"bytes": path.stat().st_size, "sha256": digest.hexdigest()}
    manifest.write_text(json.dumps({"repo": info.id, "revision": info.sha,
                                    "local_dir": str(TARGET), "files": files}, indent=2) + "\n")
    print("Downloaded and hashed", len(files), "files", flush=True)


if __name__ == "__main__":
    main()
