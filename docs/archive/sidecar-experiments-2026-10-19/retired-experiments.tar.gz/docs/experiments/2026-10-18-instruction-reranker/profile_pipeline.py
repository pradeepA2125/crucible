"""Time actual discovery retrieval plus candidate scoring; no live backend changes."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import random
import statistics
import sys
import time
from pathlib import Path

os.environ.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
                  CRUCIBLE_CODE_CANDIDATE_TRIAL="1", TOKENIZERS_PARALLELISM="false")
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
sys.path.insert(0, str(ROOT / "services/agentd-py"))


def main(mode: str, result_tag: str = "") -> None:
    import torch

    from agentd.chat.controller import ChatController
    from agentd.chat.storage import ChatThreadStore
    from agentd.local_models import LocalModels
    from agentd.memory.embedder import Embedder
    from agentd.orchestrator.broadcaster import EventBroadcaster
    from agentd.orchestrator.scripted_engine import ScriptedReasoningEngine
    from agentd.retrieval.artifact_client import RetrievalArtifactClient
    from agentd.retrieval.candidate_delivery import CandidateDelivery
    from agentd.retrieval.candidate_gate import CandidateRelevanceGate, candidate_document
    from agentd.retrieval.context_selection import SemanticContextSelector
    from agentd.retrieval.semantic_index import SemanticIndex

    target = OUT / f"pipeline-{result_tag + '-' if result_tag else ''}{mode}.json"
    if target.exists():
        raise RuntimeError("Preserve previous pipeline results")
    if not torch.backends.mps.is_available():
        raise RuntimeError("Comparable pipeline timing requires MPS")
    torch.set_num_threads(6)
    capability = LocalModels(True)
    embedder = Embedder(local_models=capability)
    start = time.perf_counter()
    embedder.warmup()
    assert capability.ready("embedder")
    stages = {}
    selector = None
    if mode == "bge":
        base_selector = SemanticContextSelector.from_env(os.environ, capability)
        base_gate = CandidateRelevanceGate.from_env(os.environ, capability)
        assert base_selector is not None and base_gate is not None
        base_gate.ranker.warmup()
        assert str(base_gate.ranker._model.model.device).startswith("mps")

        class Selector:
            def select(self, *args, **kwargs):
                tick = time.perf_counter()
                value = base_selector.select(*args, **kwargs)
                stages["context_selection_ms"] = (time.perf_counter() - tick) * 1000
                return value

        selector = Selector()
        score_device = str(base_gate.ranker._model.model.device)
    else:
        from transformers import AutoModelForCausalLM, AutoTokenizer

        from run_qwen import conversation

        qprotocol = json.loads((OUT / "qwen-protocol.json").read_text())
        manifest = json.loads((OUT / "qwen-model-manifest.json").read_text())
        local = Path(manifest["local_dir"])
        tokenizer = AutoTokenizer.from_pretrained(local, local_files_only=True,
                                                  trust_remote_code=False, padding_side="left")
        model = AutoModelForCausalLM.from_pretrained(
            local, local_files_only=True, trust_remote_code=False,
            dtype=torch.bfloat16, attn_implementation="sdpa").eval().to("mps")
        no, yes = [tokenizer.convert_tokens_to_ids(t) for t in ("no", "yes")]

        class QwenGate:
            @torch.inference_mode()
            def filter(self, query, candidates, **signals):
                if not candidates:
                    return []
                case = {"query": query, **signals}
                q = conversation(case, "plain_context")
                texts = [qprotocol["prefix"] +
                         f"<Instruct>: {qprotocol['plain_rule']}\n<Query>: {q}\n<Document>: " +
                         candidate_document(c) + qprotocol["suffix"] for c in candidates]
                encoded = tokenizer(texts, add_special_tokens=False, padding=True,
                                    truncation=False, return_tensors="pt")
                assert encoded["input_ids"].shape[1] <= qprotocol["max_length"]
                logits = model(**{k: v.to(model.device) for k, v in encoded.items()},
                               logits_to_keep=1, use_cache=False).logits[:, -1, :]
                scores = torch.softmax(torch.stack([logits[:, no], logits[:, yes]], 1).float(),
                                       dim=1)[:, 1].cpu().tolist()
                assert len(scores) == len(candidates) and all(math.isfinite(s) for s in scores)
                return [c for c, s in zip(candidates, scores, strict=True) if s > .5]

        base_gate = QwenGate()
        score_device = str(model.device)
    torch.mps.synchronize()
    model_load_ms = (time.perf_counter() - start) * 1000
    snapshot = ROOT / ".crucible/index-snapshot.json"
    assert snapshot.exists()  # no automatic snapshot build permitted in this profile
    snapshot_before = hashlib.sha256(snapshot.read_bytes()).hexdigest()
    generated = int(json.loads(snapshot.read_text()).get("generated_at_ms", 0))
    index = SemanticIndex(ROOT / ".crucible/vector-index", local_models=capability)
    assert index.open_existing(ROOT) and index.is_ready()
    query_impl = index.query

    def index_query(*args, **kwargs):
        tick = time.perf_counter()
        value = query_impl(*args, **kwargs)
        stages["semantic_query_ms"] = (time.perf_counter() - tick) * 1000
        stages["semantic_hits"] = len(value)
        return value

    index.query = index_query

    class Client(RetrievalArtifactClient):
        def load_context(self, *args, **kwargs):
            tick = time.perf_counter()
            value = super().load_context(*args, **kwargs)
            stages["retrieval_ms"] = (time.perf_counter() - tick) * 1000
            stages["candidates_before_gate"] = len(value[0].discovery_candidates)
            return value

    client = Client(semantic_index=index)
    client._last_indexed_snapshot_ms = generated

    def no_build(*args, **kwargs):
        raise RuntimeError("Index maintenance is outside this read-only profile")

    client._request_background_build = no_build

    class Gate:
        def filter(self, *args, **kwargs):
            tick = time.perf_counter()
            value = base_gate.filter(*args, **kwargs)
            torch.mps.synchronize()
            stages["reranking_ms"] = (time.perf_counter() - tick) * 1000
            stages["candidates_after_gate"] = len(value)
            return value

    controller = ChatController(
        workspace_path=str(ROOT), reasoning_engine=ScriptedReasoningEngine(None, []),
        thread_store=ChatThreadStore(ROOT / f".tmp/instruction-reranker/profile-{mode}.sqlite3"),
        orchestrator=None, broadcaster=EventBroadcaster(), retrieval_client=client,
        candidate_gate=Gate(), context_selector=selector)
    fixture = json.loads((ROOT / "docs/validation/2026-10-18-candidate-trial/local-pipeline.json")
                         .read_text())
    queries = [r["query"] for r in fixture["rows"]]
    recap = "We are investigating code candidate retrieval, ranking and freshness in the controller."
    summary = "Keep context source-free and bounded. Inspect candidate ranking and graph relationships."

    def one(query):
        stages.clear()
        stages["context_selection_ms"] = 0.
        torch.mps.synchronize()
        tick = time.perf_counter()
        session = CandidateDelivery(
            ROOT, query, lambda q: controller._compute_code_candidates(q, recap=recap,
                                                                       summary=summary),
            lambda: client.snapshot_version(str(ROOT)))
        output = session.deliver([])
        torch.mps.synchronize()
        elapsed = (time.perf_counter() - tick) * 1000
        assert "retrieval_ms" in stages and "reranking_ms" in stages and "semantic_hits" in stages
        assert stages["semantic_hits"] > 0, "Do not mistake lexical-only fallback for hybrid retrieval"
        assert capability.ready("embedder")
        stages["total_ms"] = elapsed
        stages["other_ms"] = elapsed - sum(stages[k] for k in
                                          ["context_selection_ms", "retrieval_ms", "reranking_ms"])
        return {"query": query, **stages,
                "paths": [r[0] for r in json.loads(output)["candidates"]] if output else []}

    first = one(queries[0])
    for q in queries:
        one(q)
    samples = []
    order = list(range(len(queries)))
    rng = random.Random(20261018)
    for repetition in range(3):
        rng.shuffle(order)
        for i in order:
            row = one(queries[i])
            samples.append({"repetition": repetition + 1, **row})
        print(mode, "repetition", repetition + 1, "complete", flush=True)
    stats = {}
    for key in ["context_selection_ms", "semantic_query_ms", "retrieval_ms", "reranking_ms",
                "other_ms", "total_ms"]:
        values = sorted(r[key] for r in samples)
        stats[key] = {"median": round(statistics.median(values), 2),
                      "p95": round(values[math.ceil(len(values) * .95) - 1], 2),
                      "max": round(max(values), 2)}
    assert hashlib.sha256(snapshot.read_bytes()).hexdigest() == snapshot_before
    data = {"mode": mode, "completed": True, "score_device": score_device,
            "embedder_device": str(embedder._model.device), "model_load_ms": model_load_ms,
            "snapshot_sha256": snapshot_before, "snapshot_unchanged": True,
            "recap": recap, "summary": summary, "first_query": first,
            "warmup": "One initial query plus all seven query shapes excluded from warm stats",
            "note": "Actual controller + new-turn CandidateDelivery with empty visible-read history; "
                    "existing hybrid index, index maintenance suppressed; no primary model call. "
                    "Qwen plain uses raw context without embedding context selection.",
            "samples": samples, "stats": stats}
    target.write_text(json.dumps(data, indent=2) + "\n")
    print(json.dumps(stats), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["bge", "qwen"])
    parser.add_argument("--result-tag", default="")
    args = parser.parse_args()
    main(args.mode, args.result_tag)
