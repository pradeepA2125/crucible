"""Check complete Qwen output and preserve the earlier baseline/report evidence."""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]


def check_hashes(base: Path, files: dict[str, str]) -> dict[str, bool]:
    checked = {s: hashlib.sha256((base / s).read_bytes()).hexdigest() == expected
               for s, expected in files.items()}
    if not all(checked.values()):
        raise RuntimeError("Earlier evidence changed: " + str(checked))
    return checked


def main() -> None:
    baseline = json.loads((OUT / "baseline-manifest.json").read_text())
    prior = json.loads((OUT / "pre-qwen-evidence.json").read_text())
    p = json.loads((OUT / "protocol.json").read_text())
    qp = json.loads((OUT / "qwen-protocol.json").read_text())
    data = json.loads((OUT / "qwen-results.json").read_text())
    if not data["completed"]:
        raise RuntimeError("Qwen evaluation incomplete")
    counts, lengths, errors = {}, [], []
    for c in p["cases"]:
        for arm in qp["arms"]:
            runs = data["cases"][c["id"]][arm]["runs"]
            if len(runs) != qp["repetitions"]:
                raise RuntimeError("Missing repetitions")
            for r in runs:
                if "error" in r:
                    errors.append({"id": c["id"], "arm": arm, "error": r["error"]})
                    continue
                if len(r["scores"]) != len(c["documents"]) or not all(
                        math.isfinite(s) and 0 <= s <= 1 for s in r["scores"]):
                    raise RuntimeError("Missing or invalid candidate score")
                lengths += r["pair_token_lengths"]
                counts[arm] = counts.get(arm, 0) + 1
    if errors:
        raise RuntimeError("Inference failures: " + str(errors))
    result = {"baseline_unchanged": check_hashes(
        ROOT, {s: d["sha256"] for s, d in baseline["files"].items()}),
        "earlier_report_and_results_unchanged": check_hashes(ROOT, prior),
        "qwen_input_artifacts_unchanged": check_hashes(OUT, qp["preserved"]),
        "timed_batches_per_arm": counts, "timed_candidate_pairs": len(lengths),
        "max_pair_tokens": max(lengths), "no_truncation": max(lengths) <= qp["max_length"],
        "device": data["device"], "errors": errors}
    (OUT / "qwen-validation.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
