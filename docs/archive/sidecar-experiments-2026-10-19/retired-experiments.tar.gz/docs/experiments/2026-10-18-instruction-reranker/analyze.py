"""Matched-pool metrics; errors remain missing decisions, never synthetic rejection."""
from __future__ import annotations

import hashlib
import json
import math
import statistics
from pathlib import Path

OUT = Path(__file__).resolve().parent
P = json.loads((OUT / "protocol.json").read_text())


def metrics(cases: list[dict], scores: dict[str, list[float]], cutoff: float, *, kev: bool) -> dict:
    result = {"queries": len(cases), "missing_decisions": 0, "unrelated_queries": 0,
              "unrelated_deliveries": 0, "unrelated_candidates_delivered": 0,
              "code_queries": 0, "retrievable_code_queries": 0, "expected_file_queries_recovered": 0,
              "code_queries_with_any_delivery": 0, "expected_files": 0, "expected_files_selected": 0,
              "rows_before": 0, "rows_delivered": 0, "followups": 0, "followups_recovered": 0}
    ranks = []
    for case in cases:
        values = scores.get(case["id"])
        if values is None or len(values) != len(case["paths"]):
            result["missing_decisions"] += 1
            continue
        selected = [i for i, s in enumerate(values) if s > cutoff] if kev else [
            i for i, s in enumerate(values) if s >= cutoff]
        hit = any(case["relevant"][i] for i in selected)
        result["rows_before"] += len(values)
        result["rows_delivered"] += len(selected)
        if case["kind"] == "unrelated":
            result["unrelated_queries"] += 1
            result["unrelated_deliveries"] += bool(selected)
            result["unrelated_candidates_delivered"] += len(selected)
        else:
            result["code_queries"] += 1
            result["retrievable_code_queries"] += any(case["relevant"])
            result["expected_file_queries_recovered"] += hit
            result["code_queries_with_any_delivery"] += bool(selected)
            result["expected_files"] += sum(case["relevant"])
            result["expected_files_selected"] += sum(case["relevant"][i] for i in selected)
            if any(case["relevant"]):
                ordered = sorted(range(len(values)), key=lambda i: (-values[i], i))
                ranks.append(1 / (1 + next(i for i, index in enumerate(ordered)
                                          if case["relevant"][index])))
            if case["kind"] == "followup":
                result["followups"] += 1
                result["followups_recovered"] += hit
    result["expected_file_mrr_without_cutoff"] = round(statistics.mean(ranks), 4) if ranks else None
    return result


def summarize(name: str, data: dict, arm: str | None) -> dict:
    scores, latencies, changes = {}, [], []
    max_delta = 0.
    failures = []
    for case in P["cases"]:
        entry = data["cases"].get(case["id"], {})
        if arm is not None:
            entry = entry.get(arm, {})
        runs = entry.get("runs", [])
        valid = [r for r in runs if "scores" in r]
        failures.extend({"id": case["id"], "error": r["error"]} for r in runs if "error" in r)
        if valid:
            scores[case["id"]] = valid[0]["scores"]
            for run in valid[1:]:
                max_delta = max(max_delta, max((abs(a - b) for a, b in zip(
                    valid[0]["scores"], run["scores"], strict=True)), default=0))
            fixed = .5 if arm else .1
            selections = {tuple(i for i, s in enumerate(run["scores"])
                                if (s > fixed if arm else s >= fixed)) for run in valid}
            if len(selections) > 1:
                changes.append(case["id"])
        latencies += [r["seconds"] for r in valid]
    train = [c for c in P["cases"] if c["split"] == "calibration"]
    thresholds = sorted({0., 1., *[s for c in train for s in scores.get(c["id"], [])]})
    options = [{"cutoff": t, **metrics(train, scores, t, kev=bool(arm))} for t in thresholds]
    options = [m for m in options if not m["missing_decisions"] and m["unrelated_deliveries"] == 0]
    best = max(options, key=lambda m: (m["expected_file_queries_recovered"],
                                       -m["rows_delivered"],
                                       -m["cutoff"])) if options else None
    evaluated = {}
    for split in ("calibration", "holdout", "fresh_holdout"):
        subset = [c for c in P["cases"] if c["split"] == split]
        evaluated[split] = {"fixed": metrics(subset, scores, .5 if arm else .1, kev=bool(arm))}
        if best is not None:
            evaluated[split]["calibrated"] = metrics(subset, scores, best["cutoff"], kev=bool(arm))
    latency = sorted(latencies)
    return {"name": name, "arm": arm, "completed": data["completed"],
            "fixed_cutoff": .5 if arm else .1,
            "calibration_choice": best, "evaluated": evaluated,
            "latency_samples": len(latency),
            "latency_median_ms": round(statistics.median(latency) * 1000, 2) if latency else None,
            "latency_p95_ms": round(latency[math.ceil(len(latency) * .95) - 1] * 1000, 2)
            if latency else None,
            "latency_max_ms": round(max(latency) * 1000, 2) if latency else None,
            "fixed_selection_changes_across_repeats": changes,
            "max_score_delta_across_repeats": max_delta, "failures": failures,
            "first_run_scores": scores}


def main() -> None:
    digest = hashlib.sha256((OUT / "protocol.json").read_bytes()).hexdigest()
    baseline = json.loads((OUT / "bge-results.json").read_text())
    kev = json.loads((OUT / "kev-results.json").read_text())
    if not baseline["completed"] or not kev["completed"]:
        raise RuntimeError("Do not label a partial run as complete")
    if any(d["protocol_sha256"] != digest for d in (baseline, kev)):
        raise ValueError("Protocol hash mismatch")
    rows = [summarize("BGE strict trial", baseline, None)]
    rows += [summarize("Kev-0.8B", kev, arm) for arm in
             ("query_only", "plain_context", "conditional_context")]
    (OUT / "analysis.json").write_text(json.dumps(rows, indent=2) + "\n")
    for row in rows:
        print(row["name"], row["arm"], "p50_ms", row["latency_median_ms"],
              "p95_ms", row["latency_p95_ms"], "calibrated_cutoff",
              row["calibration_choice"]["cutoff"] if row["calibration_choice"] else None)
        for split, result in row["evaluated"].items():
            for policy, m in result.items():
                print(" ", split, policy, "unrelated delivered", m["unrelated_deliveries"],
                      "/", m["unrelated_queries"], "code recovered",
                      m["expected_file_queries_recovered"], "/", m["retrievable_code_queries"],
                      "followups recovered", m["followups_recovered"], "/", m["followups"])


if __name__ == "__main__":
    main()
