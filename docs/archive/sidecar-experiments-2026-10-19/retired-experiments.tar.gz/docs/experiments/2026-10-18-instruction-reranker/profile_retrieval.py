"""Read-only diagnostic call profile; cProfile overhead is not a latency benchmark."""
from __future__ import annotations

import cProfile
import hashlib
import json
import os
import pstats
import sys
import time
from pathlib import Path

os.environ.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", TOKENIZERS_PARALLELISM="false")
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
sys.path.insert(0, str(ROOT / "services/agentd-py"))


def main() -> None:
    import torch

    from agentd.local_models import LocalModels
    from agentd.memory.embedder import Embedder
    from agentd.retrieval.artifact_client import RetrievalArtifactClient
    from agentd.retrieval.candidates import retrieval_query
    from agentd.retrieval.semantic_index import SemanticIndex

    out = OUT / "retrieval-call-profile.json"
    if out.exists():
        raise RuntimeError("Preserve previous profile")
    assert torch.backends.mps.is_available()
    torch.set_num_threads(6)
    models = LocalModels(True)
    embedder = Embedder(local_models=models)
    embedder.warmup()
    assert models.ready("embedder")
    index = SemanticIndex(ROOT / ".crucible/vector-index", local_models=models)
    assert index.open_existing(ROOT)
    snap = ROOT / ".crucible/index-snapshot.json"
    sha = hashlib.sha256(snap.read_bytes()).hexdigest()
    snapshot = json.loads(snap.read_text())
    client = RetrievalArtifactClient(semantic_index=index)
    client._last_indexed_snapshot_ms = int(snapshot["generated_at_ms"])

    def no_build(*args, **kwargs):
        raise RuntimeError("No index updates in read-only profile")

    client._request_background_build = no_build
    query = "Explain how index changes reach retrieval and how source freshness is checked."
    combined = retrieval_query(
        query, recap="We are investigating code candidate retrieval, ranking and freshness in the controller.",
        summary="Keep context source-free and bounded. Inspect candidate ranking and graph relationships.")
    for _ in range(2):
        client.load_context(str(ROOT), combined, discovery_only=True, current_query=query)
    profiler = cProfile.Profile()
    tick = time.perf_counter()
    context, _ = profiler.runcall(client.load_context, str(ROOT), combined,
                                 discovery_only=True, current_query=query)
    elapsed = (time.perf_counter() - tick) * 1000
    rows = []
    for (file, line, name), (primitive, calls, own, cumulative, _) in pstats.Stats(profiler).stats.items():
        rows.append({"file": file, "line": line, "function": name, "calls": calls,
                     "primitive_calls": primitive, "self_ms": round(own * 1000, 3),
                     "cumulative_ms": round(cumulative * 1000, 3)})
    assert hashlib.sha256(snap.read_bytes()).hexdigest() == sha
    data = {"query": query, "snapshot_bytes": snap.stat().st_size,
            "graph_nodes": len(snapshot["graph"]["nodes"]),
            "graph_edges": len(snapshot["graph"]["edges"]),
            "profiled_elapsed_ms": elapsed, "candidates": len(context.discovery_candidates),
            "note": "cProfile introduces overhead; use unprofiled pipeline benchmark for latency.",
            "by_self_time": sorted(rows, key=lambda r: -r["self_ms"])[:35],
            "by_cumulative_time": sorted(rows, key=lambda r: -r["cumulative_ms"])[:35]}
    out.write_text(json.dumps(data, indent=2) + "\n")
    print(json.dumps({k: data[k] for k in ["snapshot_bytes", "graph_nodes", "graph_edges",
                                          "profiled_elapsed_ms"]}), flush=True)
    print(json.dumps(data["by_self_time"][:12]), flush=True)


if __name__ == "__main__":
    main()
