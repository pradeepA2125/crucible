"""Separate Qwen extension of the frozen comparison; never overwrite earlier runs."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import random
import time
from pathlib import Path

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["HF_HUB_DISABLE_IMPLICIT_TOKEN"] = "1"
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
OUT = Path(__file__).resolve().parent
PREFIX = ('<|im_start|>system\nJudge whether the Document meets the requirements based on the '
          'Query and the Instruct provided. Note that the answer can only be "yes" or "no".'
          '<|im_end|>\n<|im_start|>user\n')
SUFFIX = '<|im_end|>\n<|im_start|>assistant\n<think>\n\n</think>\n\n'
ARMS = ["query_only", "plain_context", "conditional_context"]


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path: Path, value: dict) -> None:
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def freeze() -> None:
    target = OUT / "qwen-protocol.json"
    if target.exists():
        raise RuntimeError("Qwen protocol already frozen")
    source = json.loads((OUT / "protocol.json").read_text())
    if digest(OUT / "protocol.json") != (OUT / "protocol.sha256").read_text().strip():
        raise RuntimeError("Original protocol changed")
    p = {"source_protocol_sha256": digest(OUT / "protocol.json"),
         "preserved": {name: digest(OUT / name) for name in
                       ["bge-results.json", "kev-results.json", "analysis.json",
                        "baseline-manifest.json", "qwen-model-manifest.json"]},
         "arms": ARMS, "rule": source["rule"], "plain_rule": source["plain_rule"],
         "prefix": PREFIX, "suffix": SUFFIX,
         "query_encoding": "JSON current_request plus raw recap/summary/previous_answer, except query_only",
         "document_encoding": "Individual frozen candidate metadata, one batch for whole pool",
         "fixed_cutoff": .5, "acceptance": "strict greater than cutoff; ties reject",
         "calibration_selection_rule": source["selection_rule"],
         "repetitions": 3, "seed": 20261018, "max_length": 8192,
         "dtype": "bfloat16", "device": "mps", "attention": "sdpa",
         "inputs_truncation": "none; fail if any full formatted pair exceeds max_length",
         "note": "All original cases already inspected in BGE/Kev comparison. No Qwen prompt tuning. "
                 "Same long conditional rubric and simple plain rubric; this is a policy comparison."}
    save(target, p)
    (OUT / "qwen-protocol.sha256").write_text(digest(target) + "\n")
    print("Frozen Qwen extension", digest(target), flush=True)


def conversation(case: dict, arm: str) -> str:
    value = {"current_request": case["query"]}
    if arm != "query_only":
        value.update(recap=case["recap"], summary=case["summary"], previous_answer=case["closing"])
    return json.dumps(value, ensure_ascii=False)


def run() -> None:
    import resource

    import torch
    import transformers
    from transformers import AutoModelForCausalLM, AutoTokenizer

    target = OUT / "qwen-results.json"
    if target.exists():
        raise RuntimeError("Keep the existing Qwen run")
    p = json.loads((OUT / "qwen-protocol.json").read_text())
    if digest(OUT / "qwen-protocol.json") != (OUT / "qwen-protocol.sha256").read_text().strip():
        raise RuntimeError("Qwen protocol changed")
    for name, expected in p["preserved"].items():
        if digest(OUT / name) != expected:
            raise RuntimeError("Earlier evidence changed: " + name)
    if digest(OUT / "protocol.json") != p["source_protocol_sha256"]:
        raise RuntimeError("Original protocol changed")
    source = json.loads((OUT / "protocol.json").read_text())
    model_manifest = json.loads((OUT / "qwen-model-manifest.json").read_text())
    local = Path(model_manifest["local_dir"])
    for name, metadata in model_manifest["files"].items():
        if digest(local / name) != metadata["sha256"]:
            raise RuntimeError("Pinned model file changed: " + name)
    if not torch.backends.mps.is_available():
        raise RuntimeError("Use the Metal-capable environment for a comparable evaluation")
    torch.set_num_threads(6)
    data = {"protocol_sha256": p["source_protocol_sha256"],
            "qwen_protocol_sha256": digest(OUT / "qwen-protocol.json"),
            "model": model_manifest["repo"], "revision": model_manifest["revision"],
            "torch": torch.__version__, "transformers": transformers.__version__,
            "threads": torch.get_num_threads(), "completed": False, "cases": {}}
    started = time.perf_counter()
    tokenizer = AutoTokenizer.from_pretrained(local, local_files_only=True, trust_remote_code=False,
                                              padding_side="left")
    model = AutoModelForCausalLM.from_pretrained(local, local_files_only=True,
                                                trust_remote_code=False, dtype=torch.bfloat16,
                                                attn_implementation="sdpa").eval().to("mps")
    torch.mps.synchronize()
    data.update(load_seconds=time.perf_counter() - started, device=str(model.device),
                dtype=str(model.dtype), attention=model.config._attn_implementation)
    yes, no = [tokenizer.convert_tokens_to_ids(t) for t in ("yes", "no")]
    if len({yes, no, tokenizer.unk_token_id}) < 3:
        raise RuntimeError("Invalid yes/no token mapping")
    data["answer_token_ids"] = {"yes": yes, "no": no}

    @torch.inference_mode()
    def score(query: str, documents: list[str], rule: str) -> dict:
        texts = [p["prefix"] + f"<Instruct>: {rule}\n<Query>: {query}\n<Document>: {doc}" +
                 p["suffix"] for doc in documents]
        encoded = tokenizer(texts, add_special_tokens=False, padding=True,
                            truncation=False, return_tensors="pt")
        lengths = encoded["attention_mask"].sum(1).tolist()
        if max(lengths) > p["max_length"]:
            raise RuntimeError("Input exceeds frozen limit; do not silently truncate")
        inputs = {k: v.to(model.device) for k, v in encoded.items()}
        logits = model(**inputs, logits_to_keep=1, use_cache=False).logits[:, -1, :]
        pair_logits = torch.stack([logits[:, no], logits[:, yes]], dim=1).float()
        scores = torch.log_softmax(pair_logits, dim=1)[:, 1].exp().cpu().tolist()
        if not all(math.isfinite(s) and 0 <= s <= 1 for s in scores):
            raise RuntimeError("Invalid yes/no scores")
        return {"scores": scores, "pair_token_lengths": lengths,
                "no_yes_logits": pair_logits.cpu().tolist()}

    # Public sanity input validates direction/format without tuning on repository labels.
    data["public_smoke"] = score("Which planet is known as the Red Planet?",
                                 ["Mars is known as the Red Planet.",
                                  "A banana is a fruit."],
                                 "Given a query, retrieve relevant passages that answer the query.")
    if not data["public_smoke"]["scores"][0] > data["public_smoke"]["scores"][1]:
        raise RuntimeError("Public yes/no direction sanity failed")
    for arm in p["arms"]:
        case = source["cases"][12]
        score(conversation(case, arm), case["documents"],
              p["plain_rule"] if arm == "plain_context" else p["rule"])
    by_id = {c["id"]: c for c in source["cases"]}
    order = [(c["id"], arm) for c in source["cases"] for arm in p["arms"]]
    for ident, arm in order:
        data["cases"].setdefault(ident, {})[arm] = {"runs": []}
    rng = random.Random(p["seed"])
    try:
        for repetition in range(p["repetitions"]):
            rng.shuffle(order)
            for index, (ident, arm) in enumerate(order):
                case = by_id[ident]
                torch.mps.synchronize()
                started = time.perf_counter()
                try:
                    row = score(conversation(case, arm), case["documents"],
                                p["plain_rule"] if arm == "plain_context" else p["rule"])
                    torch.mps.synchronize()
                    row["seconds"] = time.perf_counter() - started
                except Exception as exc:
                    row = {"error": type(exc).__name__ + ": " + str(exc),
                           "seconds": time.perf_counter() - started}
                data["cases"][ident][arm]["runs"].append(row)
                if index % 22 == 0:
                    save(target, data)
                    print("Qwen repetition", repetition + 1, "catalogs", index + 1,
                          "/", len(order), flush=True)
            save(target, data)
        data["completed"] = True
    finally:
        data["peak_process_rss_bytes"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        data["final_mps_allocated_bytes"] = torch.mps.current_allocated_memory()
        data["final_mps_driver_bytes"] = torch.mps.driver_allocated_memory()
        save(target, data)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["freeze", "run"])
    args = parser.parse_args()
    freeze() if args.action == "freeze" else run()
