"""Compare frozen old/new discovery with identical snapshot and semantic matches."""
from __future__ import annotations

import argparse
import dataclasses
import hashlib
import importlib.util
import json
import os
import random
import statistics
import sys
import time
from pathlib import Path
from types import SimpleNamespace

os.environ.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", TOKENIZERS_PARALLELISM="false")
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
TMP = ROOT / ".tmp/retrieval-optimization"
sys.path.insert(0, str(ROOT / "services/agentd-py"))


def freeze() -> None:
    import torch

    from agentd.local_models import LocalModels
    from agentd.memory.embedder import Embedder
    from agentd.retrieval.candidates import retrieval_query
    from agentd.retrieval.semantic_index import SemanticIndex

    target = TMP / "semantic.json"
    assert not target.exists()
    assert torch.backends.mps.is_available()
    models = LocalModels(True)
    embedder = Embedder(local_models=models)
    embedder.warmup()
    index = SemanticIndex(ROOT / ".crucible/vector-index", local_models=models)
    assert index.open_existing(ROOT)
    cases = json.loads((OUT / "protocol.json").read_text())["cases"]
    inputs = []
    for case in cases:
        query = retrieval_query(case["query"], recap=case["recap"], summary=case["summary"],
                                closing=case["closing"])
        results = index.query(query, top_k=40, exclude_tests="test" not in case["query"].lower())
        assert results
        inputs.append({"id": case["id"], "query": query, "current_query": case["query"],
                       "matches": [{"score": r.score, "chunk": {
                           k: getattr(r.chunk, k) for k in
                           ["path", "name", "kind", "line_start", "line_end"]}} for r in results]})
    target.write_text(json.dumps(inputs) + "\n")
    print("Frozen", len(inputs), "query inputs and actual semantic matches", flush=True)


def run(mode: str) -> None:
    import resource

    target = OUT / f"discovery-cache-{mode}.json"
    assert not target.exists()
    if mode == "before":
        spec = importlib.util.spec_from_file_location("retrieval_before", TMP / "artifact_client_before.py")
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        Client = module.RetrievalArtifactClient
    else:
        from agentd.retrieval.artifact_client import RetrievalArtifactClient as Client
    cases = json.loads((TMP / "semantic.json").read_text())

    class Index:
        def is_ready(self):
            return True

        def query(self, query, **kwargs):
            return [SimpleNamespace(score=r["score"], chunk=SimpleNamespace(**r["chunk"]))
                    for r in next(c for c in cases if c["query"] == query)["matches"]]

    client = Client(snapshot_path_template=str(TMP / "snapshot.json"), semantic_index=Index())
    client._last_indexed_snapshot_ms = 2**63 - 1
    raw_snapshot = (TMP / "snapshot.json").read_bytes()
    snapshot_hash = hashlib.sha256(raw_snapshot).hexdigest()
    del raw_snapshot
    outputs, samples = {}, []
    cold_ms = None
    for repetition in range(4):
        order = list(range(len(cases)))
        random.Random(20261018 + repetition).shuffle(order)
        for i in order:
            c = cases[i]
            tick = time.perf_counter()
            context, _ = client.load_context(str(ROOT), c["query"], discovery_only=True,
                                             current_query=c["current_query"])
            elapsed = (time.perf_counter() - tick) * 1000
            if cold_ms is None:
                cold_ms = elapsed
            payload = dataclasses.asdict(context)
            payload.pop("snapshot_age_sec")
            encoded = json.dumps(payload, sort_keys=True, default=lambda x: x.model_dump(mode="json"))
            digest = hashlib.sha256(encoded.encode()).hexdigest()
            if c["id"] in outputs:
                assert outputs[c["id"]] == digest
            outputs[c["id"]] = digest
            if repetition:
                samples.append({"id": c["id"], "ms": elapsed})
        print(mode, "pass", repetition + 1, "complete", flush=True)
    values = sorted(s["ms"] for s in samples)
    assert hashlib.sha256((TMP / "snapshot.json").read_bytes()).hexdigest() == snapshot_hash
    data = {"mode": mode, "snapshot_sha256": snapshot_hash, "cases": len(cases),
            "samples": samples, "output_hashes": outputs, "first_query_ms": cold_ms,
            "median_ms": statistics.median(values), "p95_ms": values[int(len(values) * .95)],
            "peak_rss_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            "note": "Frozen actual semantic matches; timing excludes embedding/vector lookup. "
                    "All discovery context fields compared except advancing snapshot age."}
    target.write_text(json.dumps(data, indent=2) + "\n")
    print(mode, "median_ms", data["median_ms"], "p95_ms", data["p95_ms"], flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["freeze", "before", "after"])
    mode = parser.parse_args().mode
    freeze() if mode == "freeze" else run(mode)
