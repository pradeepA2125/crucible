"""Recount raw fixed-policy scores and distinguish earlier experimental metrics."""
from __future__ import annotations

import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
EARLIER = OUT.parent / "2026-10-18-candidate-reranker"


def count(cases: list[dict], runs: dict, arm: str | None, cutoff: float) -> dict:
    result = {"coding_requests": 0, "retrievable_coding_requests": 0,
              "coding_requests_any_delivery": 0, "coding_requests_expected_file": 0,
              "unrelated_requests": 0, "unrelated_requests_any_delivery": 0,
              "followups": 0, "followups_expected_file": 0}
    for c in cases:
        entry = runs[c["id"]]
        rows = (entry[arm] if arm else entry)["runs"]
        assert len(rows) == 3 and all("scores" in r for r in rows)
        values = rows[0]["scores"]
        assert len(values) == len(c["paths"]) == len(c["relevant"])
        selected = [v > cutoff if arm else v >= cutoff for v in values]
        hit = any(s and rel for s, rel in zip(selected, c["relevant"], strict=True))
        if c["kind"] == "unrelated":
            result["unrelated_requests"] += 1
            result["unrelated_requests_any_delivery"] += bool(any(selected))
        else:
            result["coding_requests"] += 1
            result["retrievable_coding_requests"] += any(c["relevant"])
            result["coding_requests_any_delivery"] += bool(any(selected))
            result["coding_requests_expected_file"] += hit
            if c["kind"] == "followup":
                result["followups"] += 1
                result["followups_expected_file"] += hit
    return result


def main() -> None:
    protocol = json.loads((OUT / "protocol.json").read_text())
    existing = json.loads((OUT / "analysis.json").read_text()) + json.loads(
        (OUT / "qwen-analysis.json").read_text())
    outputs = []
    for name, arms in (("bge", [None]), ("kev", ["query_only", "plain_context",
                                                 "conditional_context"]),
                       ("qwen", ["query_only", "plain_context", "conditional_context"])):
        raw = json.loads((OUT / f"{name}-results.json").read_text())
        assert raw["completed"]
        for arm in arms:
            row = next(r for r in existing if r["arm"] == arm and
                       (r["name"].startswith({"bge": "BGE", "kev": "Kev", "qwen": "Qwen"}[name])))
            splits = {}
            for split in ("calibration", "holdout", "fresh_holdout"):
                result = count([c for c in protocol["cases"] if c["split"] == split],
                               raw["cases"], arm, .5 if arm else .1)
                prior = row["evaluated"][split]["fixed"]
                assert result["coding_requests_expected_file"] == prior["expected_file_queries_recovered"]
                assert result["coding_requests_any_delivery"] == prior["code_queries_with_any_delivery"]
                assert result["unrelated_requests_any_delivery"] == prior["unrelated_deliveries"]
                splits[split] = result
            outputs.append({"model": name, "arm": arm, "fixed_cutoff": .5 if arm else .1,
                            "median_ms": row["latency_median_ms"], "splits": splits})
    embedding = json.loads((EARLIER / "embedding-context-results.json").read_text())
    segments = next(r for r in embedding["results"] if r["segment"] == "both")
    h = segments["holdout"]
    raw_rows = [r for r in embedding["rows"] if r["split"] == "holdout"]
    threshold = segments["calibration"]["cutoff"]
    assert sum(r["expected"] and r["cosine"] >= threshold for r in raw_rows) == h["relevant_kept"]
    catalog = next(r for r in json.loads((EARLIER / "summary.json").read_text())
                   if r["policy"] == "catalog" and r["mode"] == "hybrid"
                   and r["variant"] == "metadata_query")
    result = {"source": "Independent recount of existing raw scores; no model reruns or new cutoffs",
              "fixed_policy_comparison": outputs,
              "earlier_embedding_only": {"shared_cutoff": threshold, "holdout": h,
                                         "cutoff_055_holdout": next(
                                             r["holdout"] for r in segments["sweep"]
                                             if r["holdout"]["cutoff"] == .55)},
              "earlier_query_only_catalog_gate": {
                  "selected_cutoff": catalog["selected_on_calibration"]["cutoff"],
                  "holdout": catalog["holdout"]}}
    (OUT / "comparison-reconciled.json").write_text(json.dumps(result, indent=2) + "\n")
    print("Verified all seven policies against raw scores and existing analyses.")
    print("Earlier context segments retained:", h["relevant_kept"], "/", h["relevant_segments"])
    for row in outputs:
        m = row["splits"]["fresh_holdout"]
        print(row["model"], row["arm"], "any", m["coding_requests_any_delivery"],
              "expected", m["coding_requests_expected_file"], "unrelated",
              m["unrelated_requests_any_delivery"], "median_ms", row["median_ms"])


if __name__ == "__main__":
    main()
