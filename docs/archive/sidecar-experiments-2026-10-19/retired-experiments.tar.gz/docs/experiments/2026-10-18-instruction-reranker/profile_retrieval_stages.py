"""Low-overhead retrieval stage timings; wrappers live only in this process."""
from __future__ import annotations

import json
import math
import os
import statistics
import sys
import time
from pathlib import Path

os.environ.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", TOKENIZERS_PARALLELISM="false")
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
sys.path.insert(0, str(ROOT / "services/agentd-py"))


def main() -> None:
    import torch

    from agentd.local_models import LocalModels
    from agentd.memory.embedder import Embedder
    from agentd.retrieval.artifact_client import RetrievalArtifactClient
    from agentd.retrieval.candidates import retrieval_query
    from agentd.retrieval.semantic_index import SemanticIndex

    target = OUT / "retrieval-stages.json"
    if target.exists():
        raise RuntimeError("Preserve previous measurement")
    assert torch.backends.mps.is_available()
    torch.set_num_threads(6)
    models = LocalModels(True)
    embedder = Embedder(local_models=models)
    embedder.warmup()
    index = SemanticIndex(ROOT / ".crucible/vector-index", local_models=models)
    assert models.ready("embedder") and index.open_existing(ROOT)
    snapshot = ROOT / ".crucible/index-snapshot.json"
    client = RetrievalArtifactClient(semantic_index=index)
    client._last_indexed_snapshot_ms = 2**63 - 1  # suppress maintenance in this process only
    stages = {}
    read, decode, build, search = Path.read_text, json.loads, client._build_context, index.query

    def timed_read(path, *args, **kwargs):
        tick = time.perf_counter()
        text = read(path, *args, **kwargs)
        if path == snapshot:
            stages["snapshot_read_ms"] = (time.perf_counter() - tick) * 1000
            stages["snapshot_chars"] = len(text)
        return text

    def timed_decode(text, *args, **kwargs):
        tick = time.perf_counter()
        value = decode(text, *args, **kwargs)
        if isinstance(text, str) and len(text) > 1_000_000:
            stages["snapshot_decode_ms"] = (time.perf_counter() - tick) * 1000
        return value

    def timed_build(*args, **kwargs):
        tick = time.perf_counter()
        result = build(*args, **kwargs)
        stages["context_build_including_semantic_ms"] = (time.perf_counter() - tick) * 1000
        return result

    def timed_search(*args, **kwargs):
        tick = time.perf_counter()
        result = search(*args, **kwargs)
        stages["semantic_embedding_and_search_ms"] = (time.perf_counter() - tick) * 1000
        stages["semantic_hits"] = len(result)
        return result

    queries = [r["query"] for r in decode(read(
        ROOT / "docs/validation/2026-10-18-candidate-trial/local-pipeline.json"))["rows"]]
    Path.read_text, json.loads = timed_read, timed_decode
    client._build_context, index.query = timed_build, timed_search
    samples = []
    try:
        for repetition in range(4):
            for query in queries:
                combined = retrieval_query(
                    query, recap="We are investigating code candidate retrieval, ranking and freshness in the controller.",
                    summary="Keep context source-free and bounded. Inspect candidate ranking and graph relationships.")
                stages.clear()
                tick = time.perf_counter()
                client.load_context(str(ROOT), combined, discovery_only=True, current_query=query)
                total = (time.perf_counter() - tick) * 1000
                assert stages["semantic_hits"] > 0
                stages["retrieval_total_ms"] = total
                stages["load_and_decode_ms"] = stages["snapshot_read_ms"] + stages["snapshot_decode_ms"]
                stages["graph_processing_ms"] = (stages["context_build_including_semantic_ms"] -
                                                  stages["semantic_embedding_and_search_ms"])
                stages["other_ms"] = total - stages["load_and_decode_ms"] - stages["context_build_including_semantic_ms"]
                if repetition:
                    samples.append({"query": query, **stages})
    finally:
        Path.read_text, json.loads = read, decode
    stats = {}
    for key in [k for k in samples[0] if k.endswith("_ms")]:
        values = sorted(s[key] for s in samples)
        stats[key] = {"median": round(statistics.median(values), 2),
                      "p95": round(values[math.ceil(len(values) * .95) - 1], 2)}
    target.write_text(json.dumps({"samples": samples, "stats": stats,
                                 "note": "Seven queries x three warm repetitions; first pass excluded. "
                                         "No reranker, background index maintenance or hosted calls."},
                                indent=2) + "\n")
    print(json.dumps(stats), flush=True)


if __name__ == "__main__":
    main()
