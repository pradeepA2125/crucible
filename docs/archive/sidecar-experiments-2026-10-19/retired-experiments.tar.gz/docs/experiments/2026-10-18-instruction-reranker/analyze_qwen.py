"""Analyze Qwen separately, preserving all BGE/Kev results and the original analysis."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from analyze import summarize

OUT = Path(__file__).resolve().parent


def main() -> None:
    protocol = json.loads((OUT / "qwen-protocol.json").read_text())
    data = json.loads((OUT / "qwen-results.json").read_text())
    if not data["completed"]:
        raise RuntimeError("Qwen has not completed")
    if data["qwen_protocol_sha256"] != hashlib.sha256(
            (OUT / "qwen-protocol.json").read_bytes()).hexdigest():
        raise RuntimeError("Frozen Qwen protocol changed")
    if data["protocol_sha256"] != protocol["source_protocol_sha256"]:
        raise RuntimeError("Candidate protocol mismatch")
    for name, expected in protocol["preserved"].items():
        if hashlib.sha256((OUT / name).read_bytes()).hexdigest() != expected:
            raise RuntimeError("Original evidence changed: " + name)
    rows = [summarize("Qwen3-Reranker-0.6B", data, arm) for arm in protocol["arms"]]
    (OUT / "qwen-analysis.json").write_text(json.dumps(rows, indent=2) + "\n")
    for row in rows:
        print(row["arm"], "p50_ms", row["latency_median_ms"], "p95_ms", row["latency_p95_ms"],
              "calibrated_cutoff", row["calibration_choice"]["cutoff"],
              "failures", len(row["failures"]))
        for split, result in row["evaluated"].items():
            for policy, m in result.items():
                print(" ", split, policy, "unrelated delivered", m["unrelated_deliveries"],
                      "/", m["unrelated_queries"], "code recovered",
                      m["expected_file_queries_recovered"], "/", m["retrievable_code_queries"],
                      "followups recovered", m["followups_recovered"], "/", m["followups"])


if __name__ == "__main__":
    main()
