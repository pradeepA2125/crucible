"""Read-only local trial with actual cached models; no agent provider calls."""
from __future__ import annotations

import json
import os
import sys
import time
from dataclasses import asdict
from pathlib import Path

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["CRUCIBLE_CODE_CANDIDATE_TRIAL"] = "1"
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
DIRECTORY = Path(__file__).resolve().parent
ROOT = DIRECTORY.parents[2]
sys.path.insert(0, str(ROOT / "services/agentd-py"))

from agentd.chat.controller import ChatController  # noqa: E402
from agentd.chat.storage import ChatThreadStore  # noqa: E402
from agentd.local_models import LocalModels  # noqa: E402
from agentd.orchestrator.broadcaster import EventBroadcaster  # noqa: E402
from agentd.orchestrator.scripted_engine import ScriptedReasoningEngine  # noqa: E402
from agentd.retrieval.artifact_client import RetrievalArtifactClient  # noqa: E402
from agentd.retrieval.candidate_delivery import CandidateDelivery  # noqa: E402
from agentd.retrieval.candidate_gate import CandidateRelevanceGate  # noqa: E402
from agentd.retrieval.context_selection import SemanticContextSelector  # noqa: E402
from agentd.retrieval.semantic_index import SemanticIndex  # noqa: E402
from agentd.tools.files import _read_file_sync  # noqa: E402


def main() -> None:
    models = LocalModels(True)
    selector = SemanticContextSelector.from_env(os.environ, models)
    gate = CandidateRelevanceGate.from_env(os.environ, models)
    assert selector is not None and gate is not None
    selector.embedder.warmup()
    gate.ranker.warmup()
    assert models.ready("embedder") and models.ready("reranker")
    index = SemanticIndex(ROOT / ".crucible/vector-index", local_models=models)
    assert index.open_existing(ROOT)
    client = RetrievalArtifactClient(semantic_index=index)
    controller = ChatController(
        workspace_path=str(ROOT), reasoning_engine=ScriptedReasoningEngine(None, []),
        thread_store=ChatThreadStore(ROOT / ".tmp/candidate-trial/local.sqlite3"),
        orchestrator=None, broadcaster=EventBroadcaster(), retrieval_client=client,
        candidate_gate=gate, context_selector=selector,
    )
    recap = "We are investigating code candidate retrieval, ranking and freshness in the controller."
    summary = "Keep context source-free and bounded. Inspect candidate ranking and graph relationships."
    queries = [
        "hello", "Thanks for checking that.", "What is the status of our work?", "continue",
        "Inspect services/agentd-py/agentd/retrieval/candidates.py and explain how "
        "render_candidates limits the number of files.",
        "Explain how index changes reach retrieval and how source freshness is checked.",
        "Investigate how teams coordinate proposals, agent reports and finalization.",
    ]
    rows = []
    for query in queries:
        start = time.perf_counter()
        text = controller._compute_code_candidates(query, recap=recap, summary=summary)
        rows.append({"query": query, "code_candidates": json.loads(text) if text else None,
                     "elapsed_ms": round((time.perf_counter() - start) * 1000, 2)})
        print(query[:65], "files", len(rows[-1]["code_candidates"]["candidates"]) if text else 0,
              "elapsed_ms", rows[-1]["elapsed_ms"], flush=True)
    query = queries[4]
    session = CandidateDelivery(
        ROOT, query, lambda q: controller._compute_code_candidates(q),
        lambda: client.snapshot_version(str(ROOT)))
    before = session.deliver([])
    history = []
    if before:
        for row in json.loads(before)["candidates"]:
            output = _read_file_sync(path=row[0], start_line=None, end_line=None,
                                     shadow_root=ROOT, max_lines=2000, max_chars=100000)
            if not output.is_error and output.delivered_read is not None:
                history.append({"role": "tool_result", "tool": "read_file", "is_error": False,
                                "content": output.output,
                                "delivered_read": asdict(output.delivered_read)})
    after = session.deliver(history)
    evicted = session.deliver([])
    visibility = {"query": query,
                  "before_reads": json.loads(before) if before else None,
                  "after_reads": json.loads(after) if after else None,
                  "after_evicting_reads": json.loads(evicted) if evicted else None}
    result = {"semantic_cutoff": selector.cutoff, "candidate_cutoff": gate.cutoff,
              "rows": rows, "visibility": visibility,
              "note": "Actual local model and retrieval output, no main model calls or source bodies."}
    out = ROOT / "docs/validation/2026-10-18-candidate-trial/local-pipeline.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2) + "\n")
    print("Visibility catalogs:", [bool(x) for x in (before, after, evicted)], flush=True)


if __name__ == "__main__":
    main()
