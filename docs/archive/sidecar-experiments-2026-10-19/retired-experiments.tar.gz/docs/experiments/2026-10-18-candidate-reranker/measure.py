"""Local, read-only retrieval/reranker calibration. Run with local-model extras.

Uses cached models only; no provider requests, index builds or snapshot writes.
Raw candidate documents stay under ignored .tmp; published scores contain no bodies.
"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "services/agentd-py"))

from agentd.memory.recall_context import context_pairs  # noqa: E402
from agentd.memory.reranker import Reranker  # noqa: E402
from agentd.retrieval.artifact_client import RetrievalArtifactClient  # noqa: E402
from agentd.retrieval.candidates import retrieval_query  # noqa: E402
from agentd.retrieval.semantic_index import SemanticIndex  # noqa: E402


def document(candidate: dict, *, source: bool) -> str:
    path = candidate["path"]
    symbols = candidate.get("symbols", [])
    metadata = f"File: {path}\nSymbols: " + ", ".join(
        f"{s.get('name')} ({s.get('kind')})" for s in symbols
    )
    if not source:
        return metadata
    absolute = (ROOT / path).resolve()
    if not absolute.is_relative_to(ROOT):
        return metadata
    try:
        with absolute.open() as handle:
            lines = handle.read(100_000).splitlines()
    except (OSError, UnicodeError):
        return metadata
    starts = [r[0] for r in candidate.get("ranges", [])]
    starts += [s.get("line") for s in symbols]
    starts = [i for i in starts if isinstance(i, int) and i > 0][:3] or [1]
    # Keep bounded evidence local; no source is sent in code_candidates.
    excerpts = ["\n".join(lines[max(0, i - 1):i + 23]) for i in starts]
    return metadata + "\nCode:\n" + "\n\n".join(excerpts)


def main() -> None:
    directory = Path(__file__).resolve().parent
    cases = json.loads((directory / "cases.json").read_text())
    snapshot = json.loads((ROOT / ".crucible/index-snapshot.json").read_text())
    semantic = SemanticIndex(ROOT / ".crucible/vector-index")
    if not semantic.open_existing(ROOT):
        raise RuntimeError("Existing semantic index required; this experiment never builds one")
    clients = {"graph": RetrievalArtifactClient(),
               "hybrid": RetrievalArtifactClient(semantic_index=semantic)}
    ranker = Reranker(bounded=True)
    ranker.score_pairs([("warmup", "warmup")])
    codec = ranker._model.tokenizer
    rows = []
    raw = []
    started = time.perf_counter()
    for mode, client in clients.items():
        for i, case in enumerate(cases):
            query = retrieval_query(case["query"], recap=case["recap"], closing=case["closing"])
            context = client._build_context(
                snapshot, query, 0, str(ROOT), discovery_only=True,
                current_query=case["query"],
            )
            candidates = context.discovery_candidates
            paths = [c["path"] for c in candidates]
            relevant = [any(part in path for part in case["expected"]) for path in paths]
            for source in (False, True):
                docs = [document(c, source=source) for c in candidates]
                for contextual in (False, True):
                    signals = {"Q": case["query"]}
                    if contextual:
                        signals.update(R=case["recap"], C=case["closing"])
                    pairs, budget = context_pairs(signals, docs, codec)
                    tick = time.perf_counter()
                    scores = ranker.score_pairs(pairs) if pairs else []
                    rows.append({
                        "id": case["id"], "split": case["split"], "kind": case["kind"],
                        "query": case["query"], "mode": mode,
                        "variant": ("source" if source else "metadata") +
                                   ("_context" if contextual else "_query"),
                        "paths": paths, "relevant": relevant, "scores": scores,
                        "latency_ms": round((time.perf_counter() - tick) * 1000, 2),
                        "max_pair_tokens": budget.max_pair_tokens,
                    })
                    raw.append({"id": case["id"], "mode": mode,
                                "variant": rows[-1]["variant"], "pairs": pairs})
            if i % 8 == 0:
                print(f"{mode}: {i + 1}/{len(cases)} queries scored", flush=True)
    (directory / "scores.json").write_text(json.dumps({
        "model": "BAAI/bge-reranker-base", "activation": "sigmoid", "max_length": 512,
        "elapsed_seconds": round(time.perf_counter() - started, 2), "rows": rows,
    }, indent=2) + "\n")
    raw_path = ROOT / ".tmp/candidate-reranker/scored-pairs.json"
    raw_path.parent.mkdir(parents=True, exist_ok=True)
    raw_path.write_text(json.dumps(raw))
    print(f"Saved {len(rows)} scoring rows to {directory / 'scores.json'}", flush=True)


if __name__ == "__main__":
    main()
