"""Offline context-selection experiment: cached segment vectors, one query encode.

Tests segment relatedness only, not whether a request needs repository code.
No per-segment reranker calls, source reads, index builds or provider requests.
"""
from __future__ import annotations

import json
import os
import statistics
import sys
import time
from pathlib import Path

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

DIRECTORY = Path(__file__).resolve().parent
ROOT = DIRECTORY.parents[2]
sys.path.insert(0, str(ROOT / "services/agentd-py"))

from agentd.memory.embedder import Embedder  # noqa: E402

RECAP = "We are investigating code candidate retrieval, ranking and freshness in the chat controller."
SUMMARY = (
    "Keep repository context source-free and bounded to eight candidate files. "
    "Investigate candidate ranking, graph relationships, context freshness, and prompt size."
)


def cases() -> list[dict]:
    rows = []

    def add(split, kind, query, expected, recap=RECAP, summary=SUMMARY):
        rows.append({"id": len(rows) + 1, "split": split, "kind": kind, "query": query,
                     "recap": recap, "summary": summary, "expected": expected})

    for split, queries in (
        ("calibration", ["continue", "yes, check that next",
                         "How does that work across multiple files?"]),
        ("holdout", ["Go ahead with the next step.", "What about its failure handling?"]),
    ):
        for q in queries:
            add(split, "followup", q, [True, True])
    for split, queries in (
        ("calibration", ["hello", "thanks for checking that", "What should I have for lunch?",
                         "Great, that is all I needed."]),
        ("holdout", ["Hi again!", "Perfect, thank you very much.",
                     "Suggest a name for my new cat.", "No more changes needed."]),
    ):
        for q in queries:
            add(split, "unrelated", q, [False, False])
    for split, queries in (
        ("calibration", ["Where are code candidates selected and rendered?",
                         "How should candidate retrieval handle stale index results?",
                         "Can we reduce the candidate payload token size?"]),
        ("holdout", ["Which graph relationships should we include for candidate files?",
                     "Why does every chat turn retrieve a candidate catalog?",
                     "How do summary and recap affect code candidate ranking?"]),
    ):
        for q in queries:
            add(split, "explicit_related", q, [True, True])
    for split, queries in (
        ("calibration", ["Fix the OAuth refresh token expiry bug.",
                         "Change the team tile maximize button in the webview.",
                         "Make the terminal support cancelling background commands."]),
        ("holdout", ["Why does the Anthropic provider time out while streaming?",
                     "Add keyboard shortcuts to the settings panel.",
                     "Implement pagination in the chat thread list API."]),
    ):
        for q in queries:
            add(split, "new_code_topic", q, [False, False])
    auth = "We are fixing OAuth refresh tokens and expiry handling in provider authentication."
    candidates = "Candidate retrieval is limited to eight files, with compressed symbols and relationships."
    for split, q, expected, recap, summary in (
        ("calibration", "How are OAuth refresh tokens renewed?", [True, False], auth, candidates),
        ("holdout", "Why do refreshed authentication tokens expire early?", [True, False], auth, candidates),
        ("calibration", "How many candidate files are allowed in the compressed catalog?",
         [False, True], auth, candidates),
        ("holdout", "Where is the eight-file candidate limit enforced?", [False, True], auth, candidates),
    ):
        add(split, "selective", q, expected, recap, summary)
    return rows


def metrics(rows: list[dict], cutoff: float) -> dict:
    relevant = [r for r in rows if r["expected"]]
    unrelated = [r for r in rows if not r["expected"]]
    return {
        "cutoff": cutoff,
        "relevant_segments": len(relevant),
        "relevant_kept": sum(r["cosine"] >= cutoff for r in relevant),
        "unrelated_segments": len(unrelated),
        "unrelated_dropped": sum(r["cosine"] < cutoff for r in unrelated),
        "followup_segments": sum(r["kind"] == "followup" for r in relevant),
        "followup_segments_kept": sum(r["kind"] == "followup" and r["cosine"] >= cutoff
                                      for r in relevant),
    }


def main() -> None:
    queries = cases()
    model = Embedder()
    model.warmup()
    texts = list(dict.fromkeys(row[key] for row in queries for key in ("recap", "summary")))
    tick = time.perf_counter()
    vectors = model.embed(texts)
    assert len(vectors) == len(texts)
    cached = dict(zip(texts, vectors, strict=True))
    cache_fill_ms = (time.perf_counter() - tick) * 1000
    rows, latencies = [], []
    for case in queries:
        tick = time.perf_counter()
        encoded = model.embed([case["query"]])
        assert len(encoded) == 1
        query = encoded[0]
        for i, key in enumerate(("recap", "summary")):
            cosine = sum(a * b for a, b in zip(query, cached[case[key]], strict=True))
            rows.append({"id": case["id"], "split": case["split"], "kind": case["kind"],
                         "query": case["query"], "segment": key,
                         "expected": case["expected"][i], "cosine": cosine})
        latencies.append((time.perf_counter() - tick) * 1000)
    results = []
    for segment in ("both", "recap", "summary"):
        relevant_rows = [r for r in rows if segment == "both" or r["segment"] == segment]
        train = [r for r in relevant_rows if r["split"] == "calibration"]
        holdout = [r for r in relevant_rows if r["split"] == "holdout"]
        choices = [metrics(train, cutoff) for cutoff in {0.0, *[r["cosine"] for r in train]}]
        choices = [m for m in choices if m["relevant_kept"] / m["relevant_segments"] >= .95]
        best = max(choices, key=lambda m: (m["unrelated_dropped"], m["cutoff"]))
        results.append({"segment": segment, "calibration": best,
                        "holdout": metrics(holdout, best["cutoff"]),
                        "sweep": [{"calibration": metrics(train, c), "holdout": metrics(holdout, c)}
                                  for c in (.3, .35, .4, .45, .5, .55, .6, .65)]})
    data = {"model": "BAAI/bge-small-en-v1.5", "cases": queries, "rows": rows,
            "cache_fill_ms": round(cache_fill_ms, 2),
            "query_with_comparison_median_ms": round(statistics.median(latencies), 2),
            "query_with_comparison_max_ms": round(max(latencies), 2), "results": results}
    (DIRECTORY / "embedding-context-results.json").write_text(json.dumps(data, indent=2) + "\n")
    print(json.dumps({k: v for k, v in data.items() if k not in {"cases", "rows"}}, indent=2))


if __name__ == "__main__":
    main()
