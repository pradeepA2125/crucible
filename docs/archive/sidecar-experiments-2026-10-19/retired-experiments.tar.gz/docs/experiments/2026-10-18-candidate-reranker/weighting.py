"""Offline exploratory BGE ablation: score fusion versus embedded instructions.

Reuses frozen candidate metadata from measure.py; no new retrieval or source reads.
The same holdout is reused for exploration, not an independent final validation.
"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

DIRECTORY = Path(__file__).resolve().parent
ROOT = DIRECTORY.parents[2]
sys.path.insert(0, str(ROOT / "services/agentd-py"))

from analyze import metrics  # noqa: E402

from agentd.memory.reranker import Reranker  # noqa: E402

INSTRUCTION = (
    "Judge whether the candidate code helps answer the current request. "
    "Use recap and summary only to resolve references in the current request. "
    "If the current request is unrelated to recap or summary, ignore that context. "
    "Give low relevance when answering the current request does not require repository code."
)
SUMMARY = (
    "Keep repository context source-free and bounded to eight candidate files. "
    "Investigate candidate ranking, graph relationships, context freshness, and prompt size."
)


def main() -> None:
    baseline = json.loads((DIRECTORY / "scores.json").read_text())["rows"]
    cases = {c["id"]: c for c in json.loads((DIRECTORY / "cases.json").read_text())}
    raw = json.loads((ROOT / ".tmp/candidate-reranker/scored-pairs.json").read_text())
    documents = {(r["mode"], r["id"]): [doc for _, doc in r["pairs"]]
                 for r in raw if r["variant"] == "metadata_query"}
    ranker = Reranker(bounded=True)
    ranker.score_pairs([("warmup", "warmup")])
    rows, components = [], []
    started = time.perf_counter()
    for i, row in enumerate(r for r in baseline if r["variant"] == "metadata_query"):
        case = cases[row["id"]]
        docs = documents[row["mode"], row["id"]]
        signals = {"Q": case["query"], "R": case["recap"],
                   "S": SUMMARY if case["recap"] else ""}
        scores = {"Q": row["scores"]}
        for key in ("R", "S"):
            if signals[key]:
                scores[key] = ranker.score_context({"Q": signals[key]}, docs).scores
        components.append({"id": row["id"], "mode": row["mode"], "signals": signals,
                           "scores": scores})

        def append(variant: str, values: list[float]) -> None:
            rows.append({**row, "variant": variant, "scores": values})

        append("query_only", scores["Q"])
        for name, weights in (
            ("query_80_recap_10_summary_10", {"Q": .8, "R": .1, "S": .1}),
            ("query_50_recap_25_summary_25", {"Q": .5, "R": .25, "S": .25}),
            ("query_20_recap_40_summary_40", {"Q": .2, "R": .4, "S": .4}),
        ):
            total = sum(weights[key] for key in scores)
            fused = [sum(weights[key] * values[j] for key, values in scores.items()) / total
                     for j in range(len(docs))]
            append(name, fused)
        combined = {"Q": case["query"], "R": case["recap"], "C": case["closing"]}
        if signals["S"]:
            combined["R"] += "\nConversation summary:\n" + signals["S"]
        append("combined_context", ranker.score_context(combined, docs).scores)
        combined["Q"] += "\n\nRanking instructions:\n" + INSTRUCTION
        append("combined_with_instructions", ranker.score_context(combined, docs).scores)
        if i % 16 == 0:
            print(f"Scored {i + 1}/88 frozen catalogs", flush=True)

    summary = []
    for mode in ("graph", "hybrid"):
        for variant in dict.fromkeys(row["variant"] for row in rows):
            selection = [r for r in rows if r["mode"] == mode and r["variant"] == variant]
            train = [r for r in selection if r["split"] == "calibration"]
            holdout = [r for r in selection if r["split"] == "holdout"]
            thresholds = sorted({0.0, *[s for r in train for s in r["scores"]]})
            choices = [metrics(train, t, "catalog") for t in thresholds]
            choices = [m for m in choices if m["code_query_delivery_rate"] >= .95]
            best = min(choices, key=lambda m: (m["unrelated_deliveries"], m["rows_kept"],
                                                -m["cutoff"]))
            evaluated = metrics(holdout, best["cutoff"], "catalog")
            summary.append({"mode": mode, "variant": variant, "calibration": best,
                            "holdout": evaluated})
            print(mode, variant, "cutoff", round(best["cutoff"], 6),
                  "holdout unrelated delivered", evaluated["unrelated_deliveries"],
                  "code delivered", evaluated["code_deliveries_any_path"], flush=True)
    (DIRECTORY / "weighting-results.json").write_text(json.dumps({
        "model": "BAAI/bge-reranker-base", "instruction": INSTRUCTION,
        "summary_fixture": SUMMARY, "elapsed_seconds": round(time.perf_counter() - started, 2),
        "components": components, "rows": rows, "summary": summary,
    }, indent=2) + "\n")


if __name__ == "__main__":
    main()
