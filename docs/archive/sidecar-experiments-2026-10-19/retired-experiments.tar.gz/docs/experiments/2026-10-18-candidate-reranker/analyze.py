"""Choose cutoffs on calibration cases, then report untouched holdout metrics."""
from __future__ import annotations

import json
import statistics
from itertools import product
from pathlib import Path

DIRECTORY = Path(__file__).resolve().parent


def metrics(rows: list[dict], cutoff: float, policy: str = "per_candidate") -> dict:
    negatives = [r for r in rows if r["kind"] == "unrelated"]
    positives = [r for r in rows if r["kind"] != "unrelated"]
    found = [r for r in positives if any(r["relevant"])]

    def accepted(row: dict) -> bool:
        return any(s >= cutoff for s in row["scores"])

    def correct(row: dict) -> bool:
        if policy == "catalog":
            return accepted(row) and any(row["relevant"])
        return any(s >= cutoff and relevant
                   for s, relevant in zip(row["scores"], row["relevant"], strict=True))

    return {
        "cutoff": cutoff,
        "unrelated_queries": len(negatives),
        "unrelated_deliveries": sum(accepted(r) for r in negatives),
        "code_queries": len(positives),
        "retrieval_hits_before_gate": len(found),
        "correct_code_deliveries": sum(correct(r) for r in positives),
        "code_deliveries_any_path": sum(accepted(r) for r in positives),
        "retention_given_retrieval_hit": (sum(correct(r) for r in found) / len(found)
                                          if found else None),
        "code_query_delivery_rate": (sum(accepted(r) for r in positives) / len(positives)
                                     if positives else None),
        "rows_kept": (sum(len(r["scores"]) for r in rows if accepted(r))
                      if policy == "catalog"
                      else sum(s >= cutoff for r in rows for s in r["scores"])),
        "rows_before": sum(len(r["scores"]) for r in rows),
    }


def main() -> None:
    data = json.loads((DIRECTORY / "scores.json").read_text())
    results = []
    for policy, mode in product(("per_candidate", "catalog"), ("graph", "hybrid")):
        for variant in ("metadata_query", "metadata_context", "source_query", "source_context"):
            rows = [r for r in data["rows"] if r["mode"] == mode and r["variant"] == variant]
            train = [r for r in rows if r["split"] == "calibration"]
            holdout = [r for r in rows if r["split"] == "holdout"]
            cutoffs = sorted({0.0, *[s for r in train for s in r["scores"]]})
            options = [metrics(train, c, policy) for c in cutoffs]
            # Prioritize recall: don't sacrifice >5% of retrievable coding requests
            # merely to make the irrelevant-message rejection rate look good.
            metric = ("code_query_delivery_rate" if policy == "catalog"
                      else "retention_given_retrieval_hit")
            eligible = [m for m in options if m[metric] >= .95]
            best = min(eligible, key=lambda m: (m["unrelated_deliveries"], m["rows_kept"],
                                                -m["cutoff"]))
            latencies = [r["latency_ms"] for r in rows]
            results.append({
                "policy": policy, "mode": mode, "variant": variant,
                "selected_on_calibration": best,
                "holdout": metrics(holdout, best["cutoff"], policy),
                "median_inference_ms": round(statistics.median(latencies), 2),
                "max_inference_ms": max(latencies),
                "sweep": [{"calibration": metrics(train, c, policy),
                           "holdout": metrics(holdout, c, policy)}
                          for c in (0.0, .001, .005, .01, .025, .05, .1, .2, .3, .5)],
            })
    (DIRECTORY / "summary.json").write_text(json.dumps(results, indent=2) + "\n")
    for r in results:
        t, h = r["selected_on_calibration"], r["holdout"]
        print(r["policy"], r["mode"], r["variant"], "cutoff", round(t["cutoff"], 6),
              "calibration false deliveries", t["unrelated_deliveries"],
              "holdout false deliveries", h["unrelated_deliveries"],
              "holdout retained", h["correct_code_deliveries"],
              "/", h["retrieval_hits_before_gate"],
              "code_queries_delivered", h["code_deliveries_any_path"], "/", h["code_queries"],
              "median_ms", r["median_inference_ms"])


if __name__ == "__main__":
    main()
