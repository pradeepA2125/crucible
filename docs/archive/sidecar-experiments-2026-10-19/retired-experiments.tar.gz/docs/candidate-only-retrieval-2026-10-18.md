# Candidate-only retrieval for chat

Conditional-delivery update: the later strict workspace trial adds semantic
context selection, per-row relevance rejection, visible-read suppression and
refresh. See [the trial report](candidate-delivery-trial-2026-10-18.md).

Implemented on `codex/sidecar-reliability-experiments`, 18 October 2026, following
the user's decision to remove the initial retrieval seed and automatic source
delivery. No push, live backend restart or provider calls were performed for this
change. It supersedes the earlier seed-restructure and verified-delivery designs
for the chat controller.

## Model-facing contract

Each user turn retrieves a small candidate catalog. There is **no initial seed,
repository map, automatic source body or source-verification manifest**. The
catalog contains only schema-once candidate rows and relationships between those
rows. It occupies the request tail, after conversation history. It is recomputed
for the next user turn, not accumulated as artificial read results in history.
Model steps within the same user turn reuse the same catalog; tool reads and
search remain available for investigation.

```json
{
  "columns": ["path", "symbols", "ranges"],
  "symbol_columns": ["name", "kind", "line"],
  "candidates": [
    ["src/routes.py", [["handle", "Function", 25]], [[25, 48]]],
    ["src/cache.py", [["lookup", "Function", 10]], []]
  ],
  "relation_columns": ["from_index", "to_index", "kind"],
  "relations": [[0, 1, "imports"]]
}
```

This example illustrates the format, not a claim about repository files. Actual
delivery is minified JSON text in `code_candidates`. Relationship endpoints refer
to zero-based candidate row indices. The outer request can JSON-escape this text;
the measured embedding overhead is included separately in the size results.

Limits: **8 files, 3 symbols per file, 3 range hints per file, 6 relationships,
5,000 characters for the catalog**. Entries and relationships are admitted whole;
the serializer never slices a row or emits references to an omitted row. Long
entries can be omitted. The short global contract says that candidates are
incomplete, possibly stale discovery hints and that source must be read before
relying on or editing it. There is no per-file certification metadata or promise
of exhaustive coverage.

## Retrieval signals and backend work

- Current query: first in the retrieval input, capped at 1,600 characters.
- Thread recap: up to 400 characters.
- Compaction summary: up to 600 characters, read using the same thread key as the
  memory harness.
- Previous substantive answer: up to 400 characters, using recall's existing
  notice/progress filtering.

These are retrieval inputs, not extra text appended to the model prompt. Existing
memory behavior is preserved. This uses similar signals to memory recall, not a
claim that code retrieval has adopted the memory reranker's trained scoring.

The existing hybrid retrieval pipeline still supplies graph lexical and semantic
matching when the semantic index is ready. Current-request lexical matches have
priority; background-only lexical contributions are capped and lower-weighted to
help follow-ups without dominating explicit topic changes. Semantic matches use
the combined bounded context. Candidate symbol slots prioritize semantic chunk
metadata, then graph-ranked symbols. Test files do not consume slots unless the
request mentions tests/specs; explicitly named relative source paths can appear
even when absent from the snapshot, without invented line locations.

The discovery-only backend path skips source extraction, outline expansion and
repository-tree walking. It does not replace ordinary source tools or the task
planner's existing context serializer. A missing/broken retrieval index degrades
to the agent's normal tools; it does not reuse a stale catalog as if refreshed.
If no scored candidates or explicit paths exist, the model receives no catalog.

## What was retired and preserved

Removed from the active chat path:

- Initial seed computation, pinning and replay.
- Automatic source selection, reading, reuse and manifest injection.
- The verified-source workspace setting, environment mapping and API status flag.
- The experimental seed, source-reuse and syntax-selection modules and their
  obsolete experiment-specific tests. Recoverable copies are under
  `/tmp/crucible-candidate-only-retired-2026-10-18` for this local session.

Preserved: normal tools and their source metadata, permissions/approvals, stale
edit guards, memory/recap/compaction, conversation history, current edit feedback,
and index/semantic lifecycle corrections. Existing saved seeds are retained in
storage/checkpoints for compatibility but are **not sent** by the controller.
Old source reads already in conversation history are not silently deleted.

The tool catalog and provider-native output/action schemas remain unchanged.
Optional capability loading is a separate workstream.

## Local footprint

Same four query labels as the prior measurement, with current local graph-only
retrieval. Counts use `o200k_base`, not a verified provider tokenizer. There are no
source bodies or verification manifests to add to these candidate block counts.

| Query | Candidate block | Whole JSON-embedded field | Files | Relationships |
|---|---:|---:|---:|---:|
| Recorded explicit-file request | 358 | 381 | 8 | 0 |
| Broad controller/provider/edit tracing | 383 | 408 | 8 | 1 |
| Broad indexing/retrieval/freshness | 321 | 349 | 8 | 0 |
| Broad team coordination | 391 | 420 | 8 | 1 |

Replacing only the recorded request's old seed/automatic source path and updating
the associated prompt contract projects **28,063 → 21,120 estimated first-input
tokens (24.7% smaller)**. The catalog and other instructions still account for
most of the request. The baseline actual provider input was 27,448; there is no
new provider measurement for candidate-only delivery. Current-snapshot graph-only
selection also differs from the recorded original hybrid selection. These are
payload projections, not an answer-quality or end-to-end savings experiment.

Counts are in [measurements.json](validation/2026-10-18-candidate-only/measurements.json).
Raw context examples remain in ignored local scratch files.

## Validation and tradeoffs

Focused checks cover bounds and references, schema-once encoding, source-free
discovery, topic changes and follow-ups, recap/summary retrieval inputs, semantic
symbol selection, per-turn refresh/restart, compaction, legacy-seed suppression,
retrieval failure and normal source reads. Existing stale-edit/read-observation,
memory, native serialization, planner and rewind checks are included. Prompt
snapshots were updated for the new discovery contract; the memory payload and
response schema stayed unchanged. Extension runtime-setting tests and build also
pass. Full counts are recorded in the completion message.

The first model request is smaller, but an additional read/search round can repeat
the remaining prompt and erase that saving. A bounded candidate list can miss
relevant files, and recap context can introduce false positives. Graph hints can
be stale or incorrectly resolved. Candidates never grant source-read authority or
prove graph correctness. Whole-task token/cost/latency and accepted multi-file
changes need a matched model evaluation before claiming production savings.

The running live backend retains its loaded behavior until restarted. This
implementation does not automatically restart it or mutate stored chat history.

## Optional local relevance experiment

The controller now supports an opt-in metadata/query relevance gate using the
existing ready local reranker. The default remains direct delivery: calibration
did not establish a safe rejection threshold. Missing, disabled, loading or failed
local models preserve the original candidates. See
[the calibration report](candidate-reranker-calibration-2026-10-18.md) for measured
tradeoffs, the experimental cutoff override and its limitations. This gate does
not implement visibility deduplication or add any source/score manifest.
