# Selecting recap and summary before one reranker pass

Implementation update: the later user-authorized strict trial is documented in
[candidate-delivery-trial-2026-10-18.md](candidate-delivery-trial-2026-10-18.md).
The measurements below describe the preceding experiments; the final status
section below is historical.

18 October 2026. Exploratory local experiments on
`codex/sidecar-reliability-experiments`. No live provider call, model download,
backend restart or change to default delivery. The existing optional candidate
gate remains off unless a cutoff is explicitly configured.

## Proposed architecture

The user's proposed flow is feasible:

1. Cache a vector for each bounded recap/summary segment, keyed by exact text and
   embedding model identity. Refresh only when the corresponding text changes.
2. Embed the current request once. Compare its vector with the cached recap and
   summary vectors using cosine similarity.
3. Select recap and summary independently. The current request always remains.
4. Retrieve candidates using the selected context and run one final reranker
   batch, not one batch for every context segment.

If context selection is intended to affect retrieval, it must happen before the
current combined retrieval query is constructed. Merely filtering the reranker's
input would leave old-context candidates in the retrieval pool. Likewise,
filtering context is distinct from deciding whether any repository candidates
should be sent at all.

There remains an embedding cost. The query vector can be shared with other
retrieval only when the input text and model match exactly. Semantic retrieval
of a combined query plus selected context can require a further embedding; an
embedding of the current request alone cannot be silently substituted for it.
Local model work also shares the existing model lock, so contention matters.

Unavailable/disabled local models should preserve the ordinary retrieval path.
An uncertain context decision should preserve context until a stronger decision
mechanism has been evaluated; absence of a clear match is not proof of irrelevance.

## Embedding experiment

The cached existing `BAAI/bge-small-en-v1.5` was used offline, with the same
unit-normalized vector wrapper as memory. Four distinct recap/summary texts were
embedded and cached. Each of 29 requests then required one query embedding and
two vector comparisons. No reranker was called in this experiment.

The manually labeled cases comprise five vague follow-ups, eight unrelated
messages, six explicit related requests, six new coding topics and four cases
where only one segment is relevant. Fifteen cases were used for calibration and
14 for evaluation. This is a small synthetic/context-selection dataset, not a
representative production sample. Short-message dependency labels assume that
the active task is the coding task described in the supplied context.

Warm query encoding plus comparisons took **6.51 ms median**, **17.38 ms maximum**
on this machine; initial context-cache fill took **13.61 ms** after model warmup.
These timings exclude model startup, lock contention, retrieval and the final
reranker. They do not predict latency on other hardware or longer inputs.

The selective examples show the useful part of the approach:

| Request | Cosine with recap | Cosine with summary | Intended selection |
|---|---:|---:|---|
| How are OAuth refresh tokens renewed? | 0.862 | 0.387 | Authentication recap only |
| Why do refreshed authentication tokens expire early? | 0.853 | 0.438 | Authentication recap only |
| How many candidate files are allowed in the compressed catalog? | 0.513 | 0.779 | Candidate summary only |
| Where is the eight-file candidate limit enforced? | 0.577 | 0.778 | Candidate summary only |

The difficult cases show why a universal hard cutoff is premature:

| Request | Cosine with coding recap | Cosine with coding summary | Context needed? |
|---|---:|---:|---|
| continue | 0.475 | 0.528 | Yes |
| Go ahead with the next step. | 0.471 | 0.451 | Yes |
| thanks for checking that | 0.539 | 0.517 | No |
| Hi again! | 0.522 | 0.506 | No |

Similarity is topical resemblance, not a reliable test of conversational
dependency. A short request can depend on context without naming its topic.
Cosine values are not calibrated confidence probabilities.

Selecting a shared cutoff to retain at least 95% of relevant calibration
segments produced approximately **0.475**. Evaluation retained **10/12 relevant
segments**, but dropped only **4/16 irrelevant segments**. It lost both context
segments for one of the two evaluation follow-up requests. Separate recap and
summary cutoffs did not solve this: both still lost the same follow-up context.
At 0.55, 14/16 irrelevant segments were dropped but every follow-up segment was
also lost. At 0.45, all relevant segments survived, but only 1/16 irrelevant
segments was dropped. None of these values is proposed as a production cutoff.

Even perfect recap/summary selection would not fix the separate bare `hello`
versus `profile-live-hello.py` match: the current query itself can retrieve that
file. The existing single-reranker catalog gate still requires independent
evaluation for that decision.

## Earlier weighting and instruction ablation

Before the user ruled out separate reranker passes for latency, the cached BGE
reranker was tested with explicit score mixtures and embedded ranking guidance.
Those runs are experiments only; no per-segment reranker passes were added to the
application. This direction is not being pursued for the latency-sensitive path.

Four metadata score configurations were compared on the prior frozen catalogs:
query only, query/recap/summary weights of 80/10/10, 50/25/25 and 20/40/40. Missing
signals were excluded and the remaining weights renormalized. A fixed synthetic
candidate-summary text was supplied only for cases with a recap. The previous
answer remained in the combined-input comparisons but not in the three-way
score mixtures.

On hybrid evaluation, query-only and 50/25/25 both suppressed 9/10 unrelated
messages and retained 8/10 coding requests, at independently selected cutoffs.
80/10/10 and 20/40/40 suppressed 8/10 unrelated messages and retained 8/10 coding
requests. These mixtures did not establish an improvement.

For a single combined input, adding summary context suppressed 7/10 unrelated
messages and retained 9/10 coding requests. Adding the explicit instruction to
ignore unrelated recap/summary suppressed 6/10 unrelated messages and retained
8/10 coding requests. A greeting with old coding context still passed. Cutoffs
were selected using calibration cases only, but this reuses an already inspected
evaluation set and is exploratory rather than independent confirmation.

The current memory context format's 65/20/15 values allocate token budgets; they
do not assign attention weights or multiply score contributions. Our current
optional code gate uses the current query only.

BGE-base's documented interface is a query/document relevance classifier, with
no chat-style instruction role. Injected guidance is ordinary input text and
cannot be assumed to enforce the conditional rule. Qwen3-Reranker explicitly
supports a custom instruction field, which makes it a more suitable model for
testing that rule, but it has not been downloaded or evaluated here. Official
references: [BGE model card](https://huggingface.co/BAAI/bge-reranker-base),
[Qwen3 reranker model card](https://huggingface.co/Qwen/Qwen3-Reranker-0.6B).

## Artifacts and status

All new work in this follow-up is experimental scripts/results/documentation.
There is no production context-selector implementation or adopted cutoff.
Ruff and `git diff --check` pass for the new scripts/documentation. No application
behavior changed, so the previous backend test results remain applicable.

- `docs/experiments/2026-10-18-candidate-reranker/embedding_context.py`:
  reproducible offline embedding-only evaluation, including its labeled cases.
- `docs/experiments/2026-10-18-candidate-reranker/embedding-context-results.json`:
  vectors' similarity scores, selected cutoffs, sweeps and timings; no source bodies.
- `docs/experiments/2026-10-18-candidate-reranker/weighting.py` and
  `weighting-results.json`: the earlier weighting/instruction ablation.

The embedding experiment runs independently of the prior retrieval measurement.
The weighting script requires the frozen ignored scoring pairs produced by
`measure.py` and should not be confused with a production implementation.
