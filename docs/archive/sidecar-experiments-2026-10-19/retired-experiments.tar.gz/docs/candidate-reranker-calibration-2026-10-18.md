# Local reranker gate calibration

Implementation update: the user subsequently accepted false negatives for a
stricter opt-in trial. See
[candidate-delivery-trial-2026-10-18.md](candidate-delivery-trial-2026-10-18.md).
The global default remains unchanged; the trial uses different rejection policy
and cutoffs from the recall-first calibration below.

18 October 2026, `codex/sidecar-reliability-experiments`. Local inference only;
no external provider requests, live restart, index rebuild or model downloads.

## Decision

The existing `BAAI/bge-reranker-base` can be used for an optional relevance gate,
but this experiment did **not** find a safe default rejection cutoff. Candidate
delivery remains unchanged unless an experimental cutoff is explicitly set.

A metadata-only, current-query **catalog** gate selected approximately
**0.001335** on the hybrid calibration set. On holdout it suppressed 9/10
unrelated requests but also suppressed 2/10 coding requests. It still accepted
the bare `hello` calibration case because the repository contains a hello probe.
The score is a sigmoid-normalized model output, **not a confidence probability**.

## Experiment

44 manually labeled queries: 22 unrelated messages and 22 coding requests,
including five short contextual follow-ups. There are 24 calibration cases
(12 unrelated, 12 coding) and 20 holdout cases (10 unrelated, 10 coding).
Unrelated cases include both standalone conversation and unrelated messages
following a coding recap. Generic questions such as a general explanation of a
mutex are labeled as not requiring this repository's code.

Each query ran against the existing local graph snapshot and the existing
semantic index, without rebuilding either. Four scoring inputs were compared:

- File path plus selected symbol names, current query only.
- The same metadata, query plus recap and previous answer.
- Metadata plus bounded current code, query only.
- Metadata plus bounded current code and conversation context.

Source excerpts in the last two variants were read only for the local reranker,
never appended to the agent prompt. No new source-delivery mechanism was added.
Those experimental excerpts use up to three 24-line windows inside the first
100,000 characters of each file. They can miss later code or inherit stale index
line locations; this is not a test of complete function bodies or code comprehension.
Inputs use the existing 512-token bounded sigmoid model and token-budgeted
`context_pairs` implementation, including a maximum 256-token document budget.
The experiment produced 352 scoring rows (44 queries × 2 retrieval modes ×
4 input variants), usually up to eight pairs per row.

Two rejection policies were analyzed. Per-candidate filtering removes each row
below threshold. Catalog filtering sends the original complete catalog if any
row reaches threshold, otherwise sends none. The latter avoids discarding graph
neighbors just because they are individually weak semantic matches.

For catalog filtering, choose the cutoff using calibration cases only to retain
at least 95% of coding requests, then minimize unrelated deliveries and row count.
With only 12 coding calibration cases, that constraint requires preserving all 12.
For per-candidate filtering the analogous constraint preserves at least 95% of
queries with a manually expected path already present in retrieval.

## Results

Hybrid retrieval, catalog rejection. Each row uses its own calibration-selected
cutoff; thresholds are not interchangeable between representations or models.

| Local scoring input | Cutoff | Unrelated holdout requests suppressed | Coding holdout requests delivered | Median reranker inference |
|---|---:|---:|---:|---:|
| Metadata, current query | 0.001335 | 9/10 | 8/10 | 113 ms |
| Metadata, with context | 0.010563 | 7/10 | 8/10 | 117 ms |
| Bounded code, current query | 0.000280 | 8/10 | 9/10 | 396 ms |
| Bounded code, with context | 0.037192 | 7/10 | 7/10 | 406 ms |

These counts say whether a coding request received its original catalog, not
whether the response was correct. Before any gate, hybrid retrieval contained a
manually expected path for 20/22 coding requests (11/12 calibration, 9/10 holdout).
Metadata/query catalog rejection reduced holdout expected-path delivery to 7/10.
Graph-only baseline expected-path coverage was much lower: 4/12 calibration and
4/10 holdout. Different query-level cutoffs were selected for graph-only retrieval;
the hybrid cutoff must not be assumed to transfer to it.

Per-candidate filtering was worse: preserving expected-path recall required
cutoffs around 0.000037, which rejected none of the unrelated hybrid queries.
That floor reflects weak/uninformative candidate evidence, not useful confidence.

Examples of overlapping scores, hybrid metadata/query variant:

- `hello`: maximum score approximately **0.069689**, due to the hello probe file.
- `What prevents simultaneous MPS model calls from crashing?`: maximum score
  approximately **0.000190**, despite being a legitimate code request.
- `What about its failure handling?`, following a coding recap: maximum score
  approximately **0.000265**. Adding context raised it to approximately 0.004243,
  but context also increased unrelated-message acceptance.

The model can prefer a lexical greeting match over a valid code request. Neither
more source nor a single normalized-score threshold reliably resolves the
distinction between semantic similarity and whether code is needed at all.

The reported latency is warm reranker inference only, on this machine. It excludes
retrieval, model startup and contention with other local-model calls. Metadata
hybrid p95 was approximately 143 ms; bounded-code hybrid p95 approximately 418 ms.
The full experiment took about 111 seconds after initial reranker warmup.

## Optional implementation and fallback

`agentd/retrieval/candidate_gate.py` provides an experimental metadata/query
catalog gate. The chat controller calls it in the existing off-event-loop
candidate computation. It uses the existing local model capability and readiness
state. It does not load models when the capability is disabled, loading or
unavailable. Scoring failure passes candidates through and the existing ranker
failure handling prevents repeated failing inference.

The managed install's existing `crucible.localModels` / `CRUCIBLE_LOCAL_MODELS`
choice remains authoritative. No new hardware detector or extension setting was
added. A controller without a shared local-model capability also passes through.

No cutoff is set by default. A process environment override enables experiments:

```text
CRUCIBLE_CODE_CANDIDATE_MIN_SCORE=0.001335268490947783
```

That value reproduces the metadata/query hybrid calibration choice. It is **not
recommended as a production default**, including with graph-only retrieval or a
different reranker model. Missing, invalid or out-of-range values leave the gate
off. Model readiness is checked on every gate call so a loading model can become
available without blocking the request. The bounded model instance is shared
with bounded memory recall when that mode is active; a legacy unbounded memory
ranker uses a separate model-cache key if this experiment is enabled.

On acceptance, the original catalog and ordering remain. On rejection, candidate
rows are omitted; explicit paths named by the user can still appear as bare
locators through the existing renderer. Relationships are emitted only when both
endpoints survive rendering. No scores, gate explanations, source bodies or new
manifest are added to the request. This does not implement visibility deduplication.

## Limits and next step

This is a small exploratory dataset from one repository and one local index
state. Expected paths are manually chosen, not exhaustive relevance judgments.
The holdout was excluded from cutoff selection, but it was inspected to compare
variants; it is not an independent final validation set for future decisions.
Existing indexed content can be stale. The semantic model does not certify source
or graph correctness. No end-to-end agent accuracy or task-token savings were
measured.

The next useful experiment is a semantic **code-needed versus no-code-needed**
decision evaluated on a larger independent set, rather than a stricter similarity
cutoff. Keeping direct delivery as the default avoids silently losing discovery
for legitimate requests while that is unresolved.

## Implementation validation

103 focused backend tests pass, covering capability fallback, invalid cutoff and
score handling, factory wiring, controller integration, payloads/history,
retrieval, memory and prompt snapshots. Ruff, the new module's mypy check and
`git diff --check` pass. A separate real local-model check confirmed the configured
gate accepted `hello` and the candidate-selection question, rejected an
acknowledgement, and incorrectly rejected the MPS question. Results are recorded
in `docs/experiments/2026-10-18-candidate-reranker/local-gate-check.json`.

## Reproduction

Use a Python environment containing the repository and local-model extras, with
both BGE models cached and an already-built `.crucible/vector-index`:

```sh
python docs/experiments/2026-10-18-candidate-reranker/measure.py
python docs/experiments/2026-10-18-candidate-reranker/analyze.py
```

Scripts force offline Hugging Face/Transformers mode. They read the existing
snapshot/index and current bounded source; they never build the semantic index.
Raw scoring pairs remain in ignored `.tmp/candidate-reranker/scored-pairs.json`.
Cases, body-free scores and cutoff sweeps are in
`docs/experiments/2026-10-18-candidate-reranker/`.
