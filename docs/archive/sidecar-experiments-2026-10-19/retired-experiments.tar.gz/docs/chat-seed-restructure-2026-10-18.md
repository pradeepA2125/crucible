# Chat seed restructuring

> Superseded for the chat path by [candidate-only per-turn retrieval](candidate-only-retrieval-2026-10-18.md). This document preserves the earlier implementation and measurements.

Implemented on `codex/sidecar-reliability-experiments`, 18 October 2026. No commit,
push, backend restart or new provider calls were performed for this change.
The updated backend builds the new format for new chats; already pinned seeds,
including legacy seeds, remain unchanged across turns and restart.

## Representation

The chat seed now has three main segments:

1. `repository_map`: existing directory summaries, selected to retain candidate
   ancestors and shallow orientation, capped at 48 entries / 4,000 serialized
   characters. Omitted-directory counts and expansion instructions remain visible.
2. `candidates`: a unified entry per file containing retrieval match reasons,
   symbol identities/locations and bounded read ranges. Relevant existing outline
   symbols fill up to eight slots per file; matched evidence symbols are retained
   even if they exceed that outline limit. Omitted outline counts remain visible.
   Neighbor files and previously internal `related_files` preserve broad discovery;
   naming a file does not narrow this seed to that file. Maximum 64 file entries.
3. `relationships`: up to 16 directed file-level summaries of actual graph
   calls/imports/references/inheritance/implementation edges, when available.
   These are discovery hints, not exhaustive dependency claims.

Actionable diagnostics and confidence notes remain. Empty legacy fields and raw
snapshot counts are omitted. The seed explicitly identifies itself as a pinned,
potentially stale discovery hint, not current-source proof.

With verified source delivery enabled, file excerpts and symbol snippets are
represented by selection metadata in the seed. Current bodies come through the
existing permission-checked, hash-validated source-delivery path, avoiding a second
copy in the pinned seed. Every legacy automatic-read range is retained in the
measured cases. A failed or over-budget automatic read still requires ordinary
tool reads; metadata alone never grants an edit-read authorization.

With verified delivery disabled, source excerpts/snippets remain as unverified
`source_hints` grouped under their files. Only identical hints are deduplicated;
overlapping hints are not assumed to share a file revision. This compatibility
mode does not promise smaller payloads for every query.

## Code boundary

- `services/agentd-py/agentd/retrieval/seed.py`: new chat-only representation builder.
- `services/agentd-py/agentd/chat/controller.py`: constructs the new representation
  when initially computing a seed; existing durable pinning/replay is preserved.
- `services/agentd-py/agentd/retrieval/source_reuse.py`: accepts grouped v2 read
  ranges while retaining legacy evidence parsing and existing freshness checks.
- `services/agentd-py/agentd/retrieval/artifact_client.py`: retains bounded directed
  relationship hints and consistently uses normalized workspace-relative graph
  endpoints. This also corrects neighbor discovery that previously resolved
  relative endpoints against the process directory. Normalization remains cached.
- `services/agentd-py/tests/test_chat_seed.py`: thirteen new cases, including actual
  chat delivery, restart/legacy replay, broad coverage, TypeScript/Rust bounded
  reads, graph direction/containment and ordinary reads after preparation failure.

The task planner's serializer contract, tool catalog, capability guidance, model
configuration and source validation/authorization rules were not restructured.
The shared neighbor-normalization correction applies to retrieval generally.

## Local size measurements

These are `o200k_base` estimates, not authoritative provider counts. All before/
after comparisons use the same counting method and the same context per case.
The three broad cases use one captured local snapshot, graph-only retrieval and
current workspace excerpts. They are not hybrid-quality or model-task benchmarks.
Raw prompts/source are retained only in ignored local scratch files. The checked-in
[measurements](validation/2026-10-18-seed-restructure/measurements.json) contain counts
and case labels, not copied source bodies.

With verified delivery enabled:

| Case | Old seed | New seed | Reduction | Visible candidate files, old → new |
|---|---:|---:|---:|---:|
| Recorded explicit-file request, original hybrid evidence | 6,854 | 3,030 | 55.8% | 32 → 32 |
| Broad controller/provider/edit investigation | 7,158 | 4,496 | 37.2% | 39 → 45 |
| Broad indexing/retrieval/freshness investigation | 6,949 | 4,434 | 36.2% | 36 → 45 |
| Broad team coordination investigation | 6,343 | 3,838 | 39.5% | 33 → 45 |

Every previously visible candidate path and automatic-read range was retained in
these comparisons. This is coverage preservation relative to the input context,
not proof that retrieval found every file relevant to the task.

For the recorded request, replacing only the seed reduces the reconstructed full
input from **28,063 to 24,239 estimated tokens (13.6%)**, holding instructions,
tools, delivered source and other content fixed. The original actual provider
input was 27,448; there is no newly measured provider count for this representation.

With verified delivery disabled, the recorded seed is 5,253 estimated tokens
(23.4% smaller). Broad sample changes range from 7.6% smaller to 1.8% larger:
additional candidate files and relationship metadata can outweigh outline savings
when all source hints must remain. Initial savings do not establish total-task
savings: expanded reads may add model rounds and input later.

## Validation and remaining limits

- **113 focused tests pass**, covering new seed cases, existing source reuse and
  syntax selection, retrieval/cache behavior, legacy planner integration, native
  serialization, controller schemas and memory-loop wiring.
- New seed module passes strict mypy with imports followed silently. Ruff passes
  for the new module, new tests and source reuse; no additional lint findings were
  introduced in the artifact client, which has pre-existing lint findings.
- `git diff --check` passes.

The existing current-source tests continue to cover same-size/same-mtime writes,
compaction, deleted/disallowed paths and partial preparation. There is no claim of
zero possible stale behavior: graph/outline hints remain historical, and source
freshness depends on the actual current read/validation path. Broad-task answer
quality, accepted edits, expanded reads and whole-task provider usage still need a
matched model evaluation before claiming production savings. The live backend was
not restarted during this implementation.
