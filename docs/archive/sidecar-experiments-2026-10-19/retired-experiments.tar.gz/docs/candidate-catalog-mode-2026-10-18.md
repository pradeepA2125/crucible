# Compact catalog when code reranking is disabled

Choose `crucible.performance.candidateScorer: "none"` to deliver a compact code-candidate catalog without Qwen, BGE candidate filtering, or the recap/summary embedding selector. The backend environment equivalent is `CRUCIBLE_CODE_CANDIDATE_SCORER=none`. This choice does not disable memory models or the semantic retrieval query embedding. Disabling all local models also selects catalog delivery; semantic search availability then follows the existing capability checks.

This no-reranker catalog is available when automatic delivery is selected. As of the user's 2026-10-19 choice, this workspace uses `candidateDelivery: "on_demand"`, so neither automatic catalog path runs. To return to this catalog mode, select `candidateDelivery: "automatic"` and `candidateScorer: "none"`, then restart the backend. The installed extension's setting schema includes these options; an already running editor may need a reload for its dropdown to refresh.

Catalog contents:

- At most four retrieved files, prioritizing explicit file paths from the query.
- Up to three selected symbols per file, preserving each name, kind, and declaration line.
- Up to three suggested read ranges per file, not assumed to be complete function boundaries.
- Selected relationships between delivered files, preserving direction, edge kind, and zero-based row indexes, bounded by the existing six-link limit.
- A short pointer to `read_file`, `search_code`, and optional semantic/graph tools.

All these fields remain discovery hints. No source body is added automatically. Format headers appear once; cells contain compact JSON values so unusual names and paths cannot break the row structure. The existing 5,000-character ceiling is enforced on complete rows and relationships. Empty catalogs are omitted. There is no relevance cutoff in this mode: unrelated requests can receive false-positive candidates.

With the candidate trial enabled, the existing verified visible-source suppression, refresh rules, and historical-catalog replacement remain active. Catalogs are held internally as structured JSON for these checks and rendered as compact text only for delivery. The non-trial path also supports the format, but retains its existing per-turn delivery behavior.

Example layout from the current repository index:

`docs/validation/2026-10-18-candidate-catalog/example.txt`

This example used lexical discovery without a semantic model or a main-model call. Its four-file catalog measured **258 `o200k_base` field-envelope tokens**. Its ranges are empty because that retrieval supplied none; the formatter preserves all supplied ranges rather than inventing function boundaries. Non-empty and multiple ranges are covered by the delivery tests. It demonstrates formatting, not hybrid-retrieval quality or a production token-saving claim. The query and measurement are recorded alongside it in `example-metadata.json`.

Implementation: `retrieval/candidates.py` renders the text; `chat/controller.py` applies the no-reranker cap and mode; `retrieval/candidate_delivery.py` renders after visibility filtering; candidate scorer and context-selector factories respect the explicit `none` choice.

Validation: **116 focused backend tests** and **32 extension setting tests** passed. Coverage includes multiple symbols/ranges, relationship endpoints, unusual file names, complete-row budgets, explicit path prioritization, both trial/non-trial delivery, local-model opt-out, no scorer/selector calls, visible-source suppression, and request-history replacement. TypeScript, extension build, Ruff, targeted mypy, and `git diff --check` also passed. Changes remain uncommitted on `codex/sidecar-reliability-experiments`.
