# Initial-request prompt audit

Date: 18 October 2026. Branch: `codex/sidecar-reliability-experiments`.

The live harness is unchanged by this audit. Analysis uses the first successful live integration request: a new chat asking for the integer returned by one explicitly named function in one explicitly named file. The actual provider reported **27,448 input tokens**, 107 output tokens, one request, and zero cached input tokens.

## Measurement boundary

The audit reads the recorded controller artifact, splits its system prompt using recorded component boundaries, and reconstructs the native input and six action functions through the existing transport conversion. Token estimates use a locally installed `o200k_base` tokenizer. That tokenizer is **not established as the selected model's authoritative tokenizer**; it gives 28,063 tokens for visible text plus serialized native function definitions, about 2.2% above provider-reported input. Provider role/function framing is not exactly allocated locally. Component token counts are estimates and boundary tokenization means independently counted parts need not add perfectly.

Character counts from the recorded logical components and local token counts are different measurement layers. The captured logical system is 79,725 characters; the transport adds 481 characters of native-action instructions. Its logical seed field is 22,746 characters under compact JSON accounting; the seed value is 23,369 characters using the transport's ordinary JSON serialization.

Measurements and offline projections contain sizes, paths and tool names, not copied prompt/source bodies: [component measurements](validation/2026-10-18-prompt-audit/measurements.json), [offline projections](validation/2026-10-18-prompt-audit/offline-projections.json).

## Breakdown

| Component | Estimated tokens | Interpretation for this request |
|---|---:|---|
| Tool catalog | 7,972 | 57 tool descriptions and argument schemas; much broader than the question |
| Core controller rules | 3,962 | Lifecycle, source grounding, editing, todos, output behavior and examples |
| Team + agent-dispatch guidance | 2,545 | Detailed protocols supplied although no delegation was needed |
| Batching guidance | 1,216 | Dependency rules, repeated anti-redundancy guidance and worked examples |
| Skills catalog + matching guidance | 1,005 | Two frontend skills; neither applied to this source-value question |
| Other feature guidance + native-action directions | about 1,225 | Web, memory, MCP, sessions and native calling instructions |
| Retrieval seed | 6,854 | Broad workspace context despite one explicit target |
| Native action definitions | 1,198 | Six controller actions, rather than 57 separate native tool functions |
| Remaining request content | about 2,086 | User messages, recalled-memory catalog, verified source, evidence manifest, per-step instructions and framing |
| Reconstructed visible total | 28,063 | Local estimate; actual provider input was 27,448 |

System instructions and tool catalog account for approximately 17,925 estimated tokens, around 64% of the reconstructed total. The seed is another approximately 24%. This makes the new verified source entry a small part of the first-request cost, not the main driver.

The remaining request content includes a 10-entry memory candidate catalog at approximately 639 tokens, a 648-token per-step instruction, a 325-token source manifest, a 118-token recap instruction, and a 159-token source-read content envelope. Native/history framing changes the exact attribution. The source entry was 902 serialized characters before conversion; its plain source body contains only the target function. Matching source entry hashes/ranges and visibility must be retained.

## How much was useful?

A byte count cannot establish a universal useful-versus-useless percentage. Controller contracts and available capabilities can help without being quoted or called, and broad code changes need more context than this lookup. The useful question is which content was needed for this task and which could have been deferred without changing permissions or losing access to evidence.

For this exact-file lookup:

- The answer required the current two-line function and its return location. The verified source supplied that fact.
- The seed included outlines for **10 files and 217 symbols**. One file and one outline symbol were the target; the other nine files' 216 outline entries were unnecessary to derive this answer.
- The planner evidence contained **6 file excerpts and 16 symbol snippets**. One file and one symbol were the target. The same target source also appeared in verified delivery, so the seed and delivered body duplicated some code.
- The seed's tree cost approximately 1,141 tokens, outlines 2,396, excerpts/snippets 2,943, and neighbor paths 314. Those figures are nested within the 6,854-token seed and must not be added to it again.
- **21 browser tools** consumed approximately 3,405 tokens of the compact tool catalog. No browser tool was needed or called in the seven successful live checks.
- The **12 team tools** consumed approximately 1,408 catalog tokens, in addition to approximately 1,637 tokens of main-team teaching. Team capability should remain discoverable for appropriate work, but that full manual is not needed for a literal-value lookup.
- The actual two skill descriptions used approximately **227 tokens**. Their system teaching used **778 tokens**, and the per-turn skill check another **346 tokens**. Consolidating the repeated matching protocol offers more opportunity than removing the descriptions.
- The memory catalog included lessons about landing-page work, README work and Memory Inspector. Their applies-when conditions did not concern this function-value lookup. This is evidence of a relevance/budget opportunity, not a reason to discard user constraints or all memory.
- Project instruction files contributed **zero characters** in this request, so they are not the source of its overhead.

The content cannot honestly be labelled 90% useless. It is, however, substantially over-provisioned for the measured request.

## Offline trimming projections

These are local payload-size projections, **not new provider measurements or correctness benchmarks**. They do not change the live prompt. All comparisons use the same local counting method and the same captured request.

| Projection | Estimated initial input | Reduction against reconstructed baseline |
|---|---:|---:|
| Recorded baseline | 28,063 | — |
| Scope seed to the explicit file | 21,461 | 6,602 tokens / 23.5% |
| Also remove worked examples from batch/team guides | 20,435 | 7,628 / 27.2% |
| Also defer browser schemas behind a capability loader | 17,087 | 10,976 / 39.1% |

**Seed scoping:** retain the target file's outline, excerpt and symbol entry; drop unrelated outlines/excerpts, the broad repository tree and neighbor-path list for this explicit-file request. All 57 tool definitions, instructions, verified source and native action schemas remain. The model can still search, read and traverse the graph if it needs other files. The first seed remains frozen once selected, preserving the existing cache discipline. This policy must not be applied blindly to architecture questions, unknown-entry-point investigations or multi-file tasks.

**Example removal:** the projection removes only worked-example tails from the batching and team guidance. It retains their preceding scheduler, permission, budget and lifecycle rules. Real evaluation must check tool-argument validity, dependent command ordering, team budgets and approvals; deleting examples can regress those behaviors even if it looks textually redundant.

**Browser deferral:** this is a design-size projection. A `load_capability` tool does not currently exist; the projection substitutes a small discoverable browser loader for the 21 detailed browser definitions. It is not an implemented feature. A browser task would need to load the schemas, potentially adding a model round trip and affecting cache reuse. Initial-input savings alone do not establish end-to-end cost savings.

## Selected scope after user review

The user selected two workstreams: (1) break down and restructure the initial seed by segment, and (2) load each optional capability's guidance and schemas together on demand. Generic prompt shortening and independent memory/skill relevance changes are outside this scope. The historical projections above remain size experiments, not a selected implementation or savings target. No runtime changes are made by this audit.

### 1. Restructure the seed by segment

The measured seed is approximately 6,854 tokens. Its separate segment counts are estimates, not exactly additive because JSON framing and token boundaries differ.

| Existing segment | Estimated tokens | Proposed treatment |
|---|---:|---|
| `repository_structure` | 1,141 | Keep compact workspace orientation, with relevant branches expanded and other branches summarized. Preserve discoverability for vague tasks; do not drop the map merely because a file is named. |
| `file_outlines` | 2,396 | Retain candidate entry points across files, but replace exhaustive listings with selected symbols and explicit omitted counts. Expand an outline on demand. The measured request had 217 symbols across 10 files. |
| `planner_evidence.evidence_files` | 1,326 | Separate candidate metadata (path, range, retrieval rationale) from source bodies. Deliver selected current source through the verified-evidence path where supported; keep an explicit fallback for unsupported selection. |
| `planner_evidence.evidence_symbols` | 1,603 | Merge with per-file candidates. Preserve symbol identity and location; remove only source overlap established by path, current content identity and range, not merely shared names or files. |
| `graph_neighbor_files` | 314 | Retain cross-file discovery. Where graph evidence supports it, surface a bounded relation such as caller/importer/reference with its origin, rather than only a path list. Never invent missing relationships. |
| `snapshot_stats`, empty content/diagnostic fields, framing | Small | Low priority for savings. Preserve actionable diagnostics and uncertainty. Counts and empty keys are not the principal cost. |

Target representation: a compact workspace map plus a unified, bounded candidate list (file, selected symbols/ranges, match reason, supported graph relationships), followed by current source evidence delivered once through the existing validation path. This is a representation change, not a policy that narrows every request to a single file. Preserve diversity and exploration for broad requests. Do not remove old evidence producers until their consumers and non-Python/failure fallbacks are covered.

The initial seed is pinned byte-for-byte per chat today. Apply a new representation when a new seed is created; do not rewrite existing pinned seeds as retrieval changes. The pinned map remains a discovery hint, not proof of current code. Current source, changes and invalidation information continue through the verified tail. With verified delivery disabled, seed source bodies must retain their existing behavior until a separately validated replacement exists.

### 2. Load guidance and schemas as one capability

The existing system already separates much of the material: tool sources contribute definitions, named prompt blocks teach MCP, execution sessions, dispatch and teams, and web guidance is generated from effective tools. `format_controller_system_prompt` concatenates them today. Preserve these authored blocks and change their selection/delivery, rather than first shortening their wording.

Proposed capability unit:

```text
capability: browser
summary / when_to_use: brief discovery description
version: identifies this definition and guidance revision
tools: authorized browser schemas
guidance: applicable browser/MCP usage instructions
dependencies: any shared instructions needed to use those tools
```

Keep the controller action contract, permissions, source-freshness rules, basic execution ordering and a compact capability directory available from the start. A harness-level loader returns the authorized tools and their matching guidance together through the current tool-result protocol. Provider-native tool search is optional; it is not a prerequisite for this design. Namespacing alone does not defer anything.

Start with browser as the pilot. Do not automatically defer small, frequently used capabilities just because they can be grouped. Existing instructions that establish *when* to use a capability must remain represented in the discovery summary or global policy; moving every trigger behind the loader would make the capability invisible. Generic MCP guidance may be shared by several capabilities, so load dependencies once without hiding the instructions needed by an already active MCP tool. Keep web factual-confidence obligations available even before web schemas are loaded.

Loaded definitions/guidance must be versioned, persisted and restored when required after restart or compaction; a loaded-name flag without the actual content in view is insufficient. Append capability material without rewriting the stable system/seed prefix. Recheck permissions on every execution. A loader must never advertise or grant tools excluded by the agent's current permissions. Deferral controls visibility, not authorization or tool-server startup.

### Validation boundary

Compare baseline, seed restructuring alone, capability loading alone, and both combined. Include vague cross-file investigations, multi-file edits, narrow lookups and tasks that actually use the browser. Keep model/effort, workspace state and cache conditions comparable. Measure complete-task provider input/output, cached input, discovery calls, tool argument failures, source reads, accepted results and latency. Confirm restart/compaction recovery, current-source invalidation and permission enforcement. Smaller first requests alone do not establish a successful improvement.
