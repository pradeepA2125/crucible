# Candidate replacement and paired Qwen payload measurements

The live backend now follows the agreed rule: **only the current candidate catalog is included in each model request**. Earlier catalogs are removed from retained controller-step messages rather than accumulated in history. A current catalog may still be reused on subsequent calls when discovery is needed; this means sending one current catalog again, not appending older versions.

This fixes the history accumulation observed in `docs/qwen-live-candidate-metrics-2026-10-18.md`. Qwen plain context remains enabled. The provider configuration was preserved. Changes remain on `codex/sidecar-reliability-experiments`, uncommitted and unpushed.

## Post-fix live comparison

Four read-only messages were run through the configured ChatGPT provider. Candidate measurements include the JSON field envelope, using the named `o200k_base` tokenizer as a proxy for provider attribution.

| Query | Retrieved → kept by Qwen | Removed | Without Qwen estimate | With Qwen transmitted | Estimated candidate tokens removed |
|---|---:|---:|---:|---:|---:|
| Specific file question | 8 → 2 | 6 | 845 | 260 | 585 |
| “Thanks” | 8 → 2 | 6 | 415 | 93 | 322 |
| Multi-file question | 8 → 2 on each of 2 passes | 6 on each pass | 2,693 | 463 | 2,230 |
| Fresh “hello” | 8 → 0 | 8 | 363 | 0 | 363 |
| **Total token counts** | | | **4,316** | **816** | **3,500 (81.1%)** |

Counts of candidates are per scoring pass. The multi-file question triggered a refresh after a failed discovery operation, so it was scored twice; this does not imply 16 distinct files. Counts are also different from the older run because this is a fresh conversation against the current index and code, not a replay of frozen candidates.

The without-Qwen estimate uses the **same retrieved catalog and actual visible source reads on every observed model call**, but skips the relevance filter. This is computed locally as telemetry without another retrieval or model invocation. Both sides apply the same suppression of candidates whose relevant source is already visible. This is more informative than dividing token counts by a guessed ratio.

The comparison estimates candidate-field savings on the observed execution path. It does not measure how a separately run unfiltered agent would change its tool calls, answers, or total input. It is not an 81.1% reduction in the whole prompt or billing. Candidate rows retained by Qwen have not been assigned independent correctness/usefulness labels.

| Query | Total response time | Retrieval across passes | Qwen across passes | Model requests | Candidate tokens per physical request |
|---|---:|---:|---:|---:|---|
| Specific file | 20.62 s | 2,808 ms | 639 ms | 2 | 172, 88 |
| “Thanks” | 5.37 s | 301 ms | 582 ms | 1 | 93 |
| Multi-file | 51.74 s | 393 ms | 935 ms | 7 | 91, 0, 0, 93, 93, 93, 93 |
| Fresh “hello” | 6.72 s | 70 ms | 313 ms | 1 | 0 |

The first retrieval is after backend restart; it should not be treated as steady-state latency. Timings include telemetry overhead. These four examples do not establish latency percentiles or a no-Qwen latency comparison.

For all **11 physical requests**, the outgoing-body telemetry finds **at most one candidate field**. Current-field token totals equal physical transmitted candidate totals for every message; there were no candidate preparation errors. Thus the earlier history accumulation is absent in this run. Retries, if they occur in future, are still counted as physical transmissions.

## What was useful in the earlier 2,466-token multi-file turn?

The older 2,466 was **411 tokens from three historical catalog snapshots, resent six times**. It was not a new 2,466-token catalog.

Those snapshots represented four distinct file paths:

- `services/agentd-py/agentd/retrieval/candidate_delivery.py`
- `services/agentd-py/agentd/retrieval/candidates.py`
- `services/agentd-py/agentd/memory/curator.py`
- `services/agentd-py/agentd/tools/files.py`

Checking the saved logical requests and tool actions shows **0 of these 4 files was newly read during the multi-file turn**. `candidate_delivery.py` had already been read in the preceding file question. The multi-file turn instead directly read **6 other distinct files**: `local_models.py`, `candidate_gate.py`, `context_selection.py`, `chat/controller.py`, `qwen_gate.py`, and `artifact_client.py`.

The current discovery pass for that older turn was 8 retrieved → 1 kept by Qwen → 0 delivered, because the selected source was already visible. None of the 2,466 historical candidate tokens was needed to deliver that current catalog. However, direct read counts do not prove that a hint had no indirect value, and “Qwen kept it” does not establish usefulness. No independent relevance labels were collected. The source evidence remains in tool results when old candidate fields are removed.

## Implementation and validation

- `providers/openai_native.py`: `SessionInputs.commit` stores a projection of prior step messages with `code_candidates` removed. It handles string and image-content-part forms, leaves ordinary user text alone, and does not mutate the already transmitted request. OpenAI and Claude native adapters share this history utility. Uncommitted retries remain identical; compaction and independent sessions retain their existing behavior.
- `chat/controller.py`: makes the pre-filter catalog available to telemetry on each computation; it is not added to model input.
- `retrieval/candidate_delivery.py`: applies the same current-source visibility check to the unfiltered shadow catalog, then records the size comparison with actual delivery.
- `retrieval/candidate_metrics.py` and `scripts/report-candidate-messages.py`: report paired delivery totals separately from catalog reduction and provider-reported whole-input counts.

Removing candidates from historical step messages changes the previous request's exact prefix at that field. This can reduce provider prompt-cache reuse from that position onward. The live measurements above establish reduced candidate payload, not net billing savings after cache effects.

Validation: **112 focused backend tests passed**, plus **84 OpenAI/Claude adapter tests**. Three mocked Claude authentication tests initially needed a loopback socket unavailable in the sandbox; all three passed when rerun with loopback access. Ruff and `git diff --check` passed. Mypy passed for candidate delivery and metrics; file-wide `openai_native.py` checking still reports eight diagnostics in unchanged earlier code, outside the new replacement helper.

The settings and timing capture remain enabled for subsequent user messages. From the repository root:

```sh
/Users/pradeepkumar/.crucible/runtime/venv/bin/python scripts/report-candidate-messages.py --limit 20
```

Evidence under `docs/validation/2026-10-18-qwen-live/`:

- `messages.json` and `per-message.json`: post-fix live traces and paired comparisons.
- `replacement-check.json`: checks all 11 outgoing requests for candidate accumulation.
- `pre-replacement-multifile-usage.json`: historical catalog paths and direct read overlap.
- `pre-replacement-messages.json`: preserved earlier run with the history accumulation bug.
- `restart.json`: live scorer ready and provider unchanged.
