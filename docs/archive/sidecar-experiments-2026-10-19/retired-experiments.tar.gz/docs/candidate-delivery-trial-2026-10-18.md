# Conditional candidate delivery trial

Implemented on `codex/sidecar-reliability-experiments`, 18 October 2026. The trial
is enabled in this workspace's configuration; the global extension default is
off. The updated extension/backend must reload/restart before the running instance
uses it. This work did not restart the live backend or call a main model provider.

## Policy

The user explicitly accepted missing candidates in preference to filling the
request with weak or unrelated candidates. This trial therefore uses stricter,
configurable rejection, rather than the earlier calibration's recall-first policy.
Normal search/read tools are always available to recover missing discovery.

1. Before retrieval, compare the current request embedding with bounded recap,
   summary and previous-answer embeddings. Select each independently at cosine
   **0.55**. Segment vectors are cached by bounded text in a process-local LRU
   owned by the selected embedding model. One encode batch contains the query and
   only uncached segments; there are no per-segment reranker calls.
2. Run existing hybrid retrieval with the current request and selected context.
   Current-request lexical scoring remains separate. Explicit user paths enter
   the candidate pool first, without invented symbol or range metadata.
3. Score at most eight candidates in **one local reranker batch**. Keep only rows
   scoring at least **0.10**. Selected context participates in this one bounded
   combined input. Do not preserve low-scoring neighbours, refill rejected slots,
   or force explicit paths back into a rejected catalog.
4. Before every model request, suppress candidates whose relevant current source
   is already visible in the actual outgoing history. Filter/remap relationships
   to the surviving rows. Emit no `code_candidates` field when none remain.
5. Reuse the per-turn catalog between model steps. Refresh on new user steering,
   index/candidate-file changes, local-model readiness changes, applied edits,
   failed read/search/graph calls, empty code searches or compaction. A notice turn
   has no catalog. Forced-final/iteration-limit requests omit the catalog.

“Discovery needed” is operationally defined as uncovered candidates that passed
relevance filtering, not a claim that the harness understands the complete task
scope or knows the answer. Greetings/status requests pass through the same semantic
policy; no hardcoded greeting list or separate classifier call was introduced.
The classifier is imperfect: other conversational queries can still pass, and
legitimate coding requests can receive nothing.

## Visibility and freshness

There is no permanent “file was read” flag. Coverage is reconstructed from
successful `read_file` results that remain in the outgoing history, including
after restart. Both existing delivery metadata and the actual numbered code text
must agree with the current workspace file's hash and lines.

- Wrong/different roots, errors, missing hashes, summaries, truncated bodies and
  changed files do not establish coverage.
- Multiple adjacent reads can establish range coverage; gaps cannot.
- All candidate range hints and selected symbol locations must be covered.
  Without range hints, merely reading a definition line is insufficient; the
  entire current file must be visible before suppressing that candidate.
- File hashing is bounded to the existing two-megabyte read ceiling and cached
  against file identity, size, modification time and change time. A change during
  reading prevents coverage. This backend-only check sends no new source body.
- Source removed by compaction no longer counts, even if its former metadata or a
  summary survives. The catalog can reappear after the evidence is evicted.
- Search snippets and shell `cat` output are not currently counted as coverage;
  their file/range/revision provenance is not strong enough for this suppressor.

This does not certify graph correctness or remove stale code already in history.
Index paths/lines remain discovery hints. A file can also change after a visibility
check; ordinary current reads and existing stale-write guards remain authoritative.
No verification manifest, automatic source delivery or initial seed was restored.
Internal visibility checks do not mark a file as read for edit authorization or
update the write guard's read ledger.

## Configuration and fallback

Workspace setting (enabled here):

```json
"crucible.performance.candidateTrial": true
```

It maps to `CRUCIBLE_CODE_CANDIDATE_TRIAL=1` at managed backend spawn. Global
default is false and explicit workspace opt-out is honored. The existing user
choice `crucible.localModels` / `CRUCIBLE_LOCAL_MODELS` remains authoritative;
no new hardware detector or mandatory model installation was added.

Advanced process overrides:

```text
CRUCIBLE_CODE_CONTEXT_MIN_SIMILARITY=0.55
CRUCIBLE_CODE_CANDIDATE_MIN_SCORE=0.10
```

These are deliberate trial choices, not validated universal thresholds or
probabilities. Invalid semantic thresholds use the trial default. An invalid
explicit reranker threshold disables that gate and preserves direct delivery.

Disabled, loading, unavailable or failed models bypass their corresponding local
inference stage and preserve ordinary retrieval. The visibility filter still
works without ML. A transition to model readiness invalidates the turn's cached
catalog. The semantic selector runs only when there is context to select.

The older explicit-cutoff-only experiment remains available without the trial
flag, with its prior whole-catalog acceptance behavior. The trial flag selects
strict per-candidate filtering and visibility/refresh handling instead.

## Local end-to-end evidence

Actual cached BGE embedder/reranker plus the current hybrid retrieval index, with
coding recap and summary supplied:

| Request | Delivered candidates |
|---|---:|
| hello | 0 |
| Thanks for checking that. | 0 |
| What is the status of our work? | 0 |
| continue | 0 |
| Inspect candidates.py and explain render_candidates' file limit | 6 |
| Explain index changes, retrieval and source freshness | 0 |
| Investigate team proposals, reports and finalization | 0 |

The two broader coding questions and `continue` receiving no candidates are
observed false negatives, not successes. They illustrate the user's accepted
trial tradeoff. These examples do not establish general conversational detection.

A separate source-visibility run started with **4 rows**, fell to **1** after
current file reads, and returned to **4** after removing those read results.
The remaining row was the long controller file, whose read was truncated; its
coverage was conservatively insufficient.

Measured full candidate computation was approximately **442–533 ms** for the warm
examples here, including retrieval and both local stages. The first call took
about **1.68 s** with additional cold retrieval/model-path work. The earlier 6.5 ms
embedding-only and 113 ms reranker-only measurements are not the whole pipeline's
latency. Model-lock contention and other hardware can change these timings.
No task-level model-token or answer-quality savings were measured for this trial.

Actual query/catalog pairs and visibility states are saved in
[local-pipeline.json](validation/2026-10-18-candidate-trial/local-pipeline.json).
The read-only reproduction script is
`docs/experiments/2026-10-18-candidate-reranker/trial_pipeline.py`.

## Code and validation

- `retrieval/context_selection.py`: readiness-gated semantic selection and bounded cache.
- `retrieval/candidate_gate.py`: one-batch row rejection in trial mode.
- `retrieval/candidate_delivery.py`: per-turn catalog, visibility proof and refresh state.
- `retrieval/candidates.py`: renderer can forbid explicit-path reinsertion.
- `chat/controller.py`, `controller_factory.py`, `controller_loop.py`: selected
  retrieval, off-event-loop delivery, steering/edit/compaction lifecycle.
- `retrieval/artifact_client.py`: cheap snapshot revision observation.
- API config reports `candidate_trial`; extension setting/env mapping and this
  workspace opt-in make the trial switchable without changing the global default.

Focused checks cover actual controller requests, restart, compaction, partial and
truncated reads, source changes after read, source-range unions, metadata-only
false proof, scope/index refresh, semantic cache reuse, unavailable/failed models,
single reranker batches and explicit-path rejection. Existing edit/read guards,
memory, provider serialization, prompt snapshots, rewind and retrieval checks are
also included. **210 backend tests passed** across the focused regression set.

**76 extension runtime tests**, TypeScript checking and extension bundling pass. Ruff,
strict mypy for the three new policy modules and `git diff --check` pass.

Earlier experiments and their limitations remain documented in
[the calibration report](candidate-reranker-calibration-2026-10-18.md) and
[the context-selection report](candidate-context-selection-2026-10-18.md).
