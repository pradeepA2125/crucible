# Qwen, BGE and Kev candidate scoring comparison — 18 October 2026

**Qwen improves useful-file recovery, but the tested conditional instruction does not reliably ignore unrelated recap/summary context. Do not replace the current gate with this recipe.** On the 22 newer cases, conditional Qwen recovered an expected file in 10/16 coding requests, versus 3/16 for the BGE trial and 1/16 for conditional Kev. However, it delivered candidates for all six requests requiring no code inspection. Query-only Qwen recovered 5/16 and rejected all six.

This follow-up tests the previously omitted Qwen alternative. The [earlier BGE/Kev report](</Users/pradeepkumar/projects/AI editor/docs/instruction-reranker-comparison-2026-10-18.md>), original scores, original protocol and baseline source files remain unchanged, verified by hashes. No live code, model settings or backend were changed.

## What “current trial” means, and why earlier recovery was higher

The earlier short answer used “current trial” too broadly. Its BGE row is **the embedding-based context selector at cosine >=0.55 followed by the BGE reranker at score >=0.10**, rejecting candidate rows independently. It is not embedding matching alone. These comparison scores replay that scoring policy on fixed candidate pools; they do not rerun the full retrieval/visibility pipeline.

The earlier higher numbers are real, but describe different units and policies:

| Measurement | Result | What was counted |
|---|---:|---|
| Earlier embedding-only context selection, cutoff ~0.475 | 10/12 | Relevant recap/summary segments retained in its 14-request evaluation set; no candidate search/reranker |
| Same embedding-only evaluation at cutoff 0.55 | 8/12 | Relevant recap/summary segments retained; 14/16 irrelevant segments dropped |
| Earlier query-only BGE catalog gate, cutoff ~0.001335 | 8/10 | Coding requests receiving any catalog in its earlier holdout |
| That earlier catalog gate, expected-file metric | 7/10 | Coding requests receiving an expected file; nine of ten had one in the original pool |
| Latest BGE selector + strict row filter, newer 22 cases | 8/16 | Coding requests receiving any candidate |
| Same latest run, expected-file metric | 3/16 | Coding requests receiving an expected file |

The earlier catalog gate forwarded every row when any row passed its much lower cutoff, preserving weakly scored neighbors. The latest trial filters each row at 0.10 and uses selected context. The new dataset also differs. Therefore **3/16 is not a remeasurement showing embedding recall fell from 10/12**. The reported raw count is correct; the abbreviated label and omission of the other metrics made it easy to misread.

Sources: [embedding-only measurements](</Users/pradeepkumar/projects/AI editor/docs/candidate-context-selection-2026-10-18.md>), [earlier catalog calibration](</Users/pradeepkumar/projects/AI editor/docs/candidate-reranker-calibration-2026-10-18.md>), and [independent recount](</Users/pradeepkumar/projects/AI editor/docs/experiments/2026-10-18-instruction-reranker/comparison-reconciled.json>). Original artifacts were not overwritten.

## Model, inputs and controls

We used the official **Qwen/Qwen3-Reranker-0.6B** checkpoint, revision `e61197ed45024b0ed8a2d74b80b4d909f1255473`. Its weight file is 1,191,588,280 bytes, SHA-256 `27cd75a405b9c1b46b59abfd88aaa209e6fed2a1972cde9b70e7659537c5e65b`. The public model was downloaded to a temporary directory; inference stayed local. No runtime packages were installed. An initial Xet download stalled and was stopped; standard HTTPS completed the same pinned checkpoint before scoring began.

The [official interface](https://huggingface.co/Qwen/Qwen3-Reranker-0.6B) supports custom instructions with query/document inputs and yes/no relevance scores. We used its system prefix, instruction/query/document formatting, assistant suffix and normalized yes/no logits. The public sanity check scored a correct Mars passage 0.9983 and an unrelated fruit passage 0.0000133, confirming score direction before repository scoring.

The experiment uses exactly the same **66 requests and frozen candidate metadata** as the earlier comparison: 24 calibration cases, 20 earlier diagnostic holdout cases, and 22 newer cases. Expected files are present for 11/12 calibration coding requests, 9/10 earlier holdout coding requests, and all 16 newer coding requests. The remaining requests need no code inspection: 12, ten and six respectively. The newer labels were authored before the BGE/Kev inference, but were already inspected by this Qwen follow-up and are not an independent new validation set. They have not been independently human-reviewed.

Three Qwen variants were frozen before any Qwen repository scores:

| Variant | Query input | Instruction |
|---|---|---|
| Query only | JSON containing only `current_request` | Original explicit inspection-relevance rubric |
| Plain context | JSON containing request plus raw recap, summary and previous answer | Original simple relevance instruction |
| Conditional context | Same raw fields as plain context | Original full rubric: current request determines the task; ignore unrelated background; resolve continuations; no quota; reject unnecessary inspection |

Each candidate's document is its original frozen metadata, without source bodies. Qwen scores the whole candidate pool in **one batch**, with one query/document pair per file. It does not separately score recap, summary or previous answer and does not run the embedding selector. This is the proposed combined instruction-aware scoring experiment.

All pairs fit without truncation: **110–348 tokens** including formatting and instruction, against an 8,192-token guard. Each variant has 198 timed batches: three repetitions of 66 requests. Across all variants, 594 batches and 4,554 candidate-pair scores completed with no errors. Repeated decisions and scores were identical. No prompt revision was made after inspecting Qwen outputs.

## Fixed-cutoff comparison

Qwen and Kev accept P(yes/true)>0.5, rejecting ties. The BGE trial retains its semantic-context cutoff >=0.55 and candidate-score cutoff >=0.10. “Recovered” means at least one expected file was delivered, not that the agent completed the task or received every necessary file. Unlisted files in coding cases are not automatically labeled irrelevant.

| Method | Earlier holdout: expected-file requests recovered | Earlier holdout: unwanted deliveries | Newer cases: expected-file requests recovered | Newer cases: unwanted deliveries | Newer follow-ups recovered |
|---|---:|---:|---:|---:|---:|
| BGE selector + strict row filter, fixed pools | 2/9 | 0/10 | 3/16 | 0/6 | 1/3 |
| Kev, query only | 6/9 | 2/10 | 1/16 | 0/6 | 0/3 |
| Kev, plain context | 8/9 | 3/10 | 4/16 | 4/6 | 1/3 |
| Kev, conditional context | 7/9 | 3/10 | 1/16 | 0/6 | 0/3 |
| Qwen, query only | 6/9 | 1/10 | 5/16 | 0/6 | 0/3 |
| Qwen, plain context | 8/9 | 4/10 | 11/16 | 6/6 | 3/3 |
| Qwen, conditional context | 8/9 | 5/10 | 10/16 | 6/6 | 3/3 |

Providing background helps Qwen resolve continuations, but also causes unwanted delivery. The long conditional instruction did not improve that rejection behavior over plain context. The model's documented support for instructions does not establish reliable handling of this particular conditional rule.

Kev-0.8B is the **JEV-style decision model actually tested**, using its native typed decision API. No result here is for OpenJev 27B or Nano-Jev; those checkpoints were not run in this comparison. The [earlier memory experiment](</Users/pradeepkumar/projects/AI editor/docs/superpowers/evals/2026-10-15-memory-kev-vs-reranker.md>) finding 9/14 core memories for Kev concerns a separate memory-selection task, not these code-candidate requests.

For the newer 22-case subset, the distinction between “something delivered” and “expected file delivered” is:

| Method | Coding requests with any candidate | Coding requests with expected file | No-inspection requests with unwanted candidates |
|---|---:|---:|---:|
| BGE selector + strict row filter | 8/16 | 3/16 | 0/6 |
| Kev, query only | 1/16 | 1/16 | 0/6 |
| Kev, plain context | 9/16 | 4/16 | 4/6 |
| Kev, conditional context | 1/16 | 1/16 | 0/6 |
| Qwen, query only | 5/16 | 5/16 | 0/6 |
| Qwen, plain context | 16/16 | 11/16 | 6/6 |
| Qwen, conditional context | 16/16 | 10/16 | 6/6 |

The expected-file counts are the stricter task-location metric used throughout the recent comparison. They still do not measure answer correctness or all necessary files. All seven rows were independently recounted from raw scores against the frozen labels; they agree with the original analyses.

## Calibration-only cutoff selection

The unchanged rule selects a cutoff using calibration cases only: require zero unrelated request deliveries, then maximize expected-file query recovery, minimizing delivered rows on ties. No threshold was chosen using the newer cases or earlier holdout. Exact thresholds are retained in the analysis file; the table rounds them.

| Qwen variant | Selected cutoff | Calibration recovered | Earlier holdout recovered; unwanted | Newer cases recovered; unwanted |
|---|---:|---:|---:|---:|
| Query only | >0.880797 | 7/11 | 5/9; 0/10 | 5/16; 0/6 |
| Plain context | >0.993710 | 5/11 | 1/9; 0/10 | 6/16; 6/6 |
| Conditional context | >0.989672 | 5/11 | 1/9; 1/10 | 8/16; 5/6 |

The conditional-context calibration does not generalize: it still admits five of six newer no-inspection requests. Query-only calibration gives a more conservative result on these cases, but loses all implicit follow-ups and adds substantial scoring latency. This is an experimental trade-off, not a new product default.

## What went wrong, concretely

The following requests share a recap naming `CandidateDelivery.deliver` and describing visibility deduplication. These are conditional-context scores for `candidate_delivery.py`:

| Current request | Desired behavior for that file | Score |
|---|---|---:|
| “Continue with the next inspection.” | Deliver the expected location | 0.999596 |
| “Go ahead with that change.” | Deliver the expected location | 0.999245 |
| “Hello again!” | Deliver nothing | 0.999290 |
| “Summarize the decisions above without inspecting any more code.” | Deliver nothing | 0.999030 |
| “Actually investigate authentication refresh handling instead.” | Ignore the old file; find authentication | 0.999704 |

On the authentication topic switch, Qwen selected the old delivery file and rejected the expected authentication file. The same problem occurs for “Ignore the old candidate task. Where does token refresh happen?” The scores are consistent with strong relevance to old background overriding the current request; they do not prove a particular internal reasoning mechanism.

The unwanted greeting scores slightly higher than the useful “Go ahead” continuation. Consequently, a single cutoff cannot preserve that continuation while rejecting that greeting. A 0.999 score here is not a calibrated probability that discovery is necessary.

There are useful successes: Qwen conditional context recovered `context_selection.py` for a request about refreshing summary vectors with an authentication recap and a relevant cache summary. It also recovered the cache file for “How is the context cache bounded across requests?” However, these successes do not offset the consistent unrelated-background failures for the intended gate.

## Latency and resources

Qwen ran sequentially after the other models on the same development Mac, using PyTorch 2.14.1, Transformers 5.19.0, BF16, SDPA, `mps:0`, six CPU threads, and inference/evaluation mode. Only final-position logits are computed; there is no generated answer or rationale. The model load took 1.56 seconds, excluded from scoring timings.

| Method | Median batch/request | p95 | Maximum |
|---|---:|---:|---:|
| BGE selector + strict row filter, fixed pools | 40 ms | 65 ms | 242 ms |
| Kev, query only | 827 ms | 1,001 ms | 1,117 ms |
| Kev, plain context | 417 ms | 509 ms | 750 ms |
| Kev, conditional context | 838 ms | 995 ms | 1,187 ms |
| Qwen, query only | 593 ms | 618 ms | 660 ms |
| Qwen, plain context | 327 ms | 459 ms | 499 ms |
| Qwen, conditional context | 622 ms | 772 ms | 785 ms |

Conditional Qwen adds roughly **582 ms** versus the BGE trial, about **15.5 times** its median scoring time. It is faster than the tested conditional Kev setup. The shorter plain instruction is faster than the long rubric; wording and input length change together, so this does not isolate the cost of understanding conditional context.

Qwen process peak RSS was **1.69 GiB**. At completion, MPS reported **1.12 GiB allocated** and **2.17 GiB driver memory**; those are current measurements, not peaks, and should not be added to RSS as an estimate of total memory. BGE earlier process peak RSS was 1.14 GiB and Kev sampled process peak RSS was 3.47 GiB. These measures do not establish complete system memory requirements or performance on a 16 GB Air.

Qwen timings include query/format construction, tokenization, transfers, one full candidate batch, synchronized GPU work and score conversion. BGE is the existing in-process bounded cross-encoder plus selector; Kev uses its native local catalog API, with shared prefill/readouts and full catalog state. Input shape, prompt and implementation differ; this is a comparison of practical policies, not weights alone. Retrieval, result-file writes, primary agent calls, and production queue contention are excluded.

## Decision and remaining work

**Do not adopt conditional Qwen as the conversational/discovery gate.** It improves coding-file recovery in this pool, but fails the main requirement of avoiding unrelated candidate payloads. The current BGE trial remains the preserved baseline, with its previously documented recovery and topic-switch weaknesses still unresolved.

Query-only Qwen at its calibration-selected cutoff is a possible separate ranking candidate: it improves recovery over BGE on both held-out sets with no unwanted deliveries there. It also abandons useful follow-up context, and costs about 593 ms. Whether that trade-off improves the harness requires an end-to-end experiment measuring successful work, fallback reads and total input tokens. This comparison does not measure token savings.

The result applies to this frozen long rubric and JSON context format. It does not show that every Qwen prompt or model size fails. A future format/rubric change would need its own frozen experiment and fresh reviewed cases, rather than tuning against these already inspected examples.

## Evidence and reproduction

The [experiment directory](</Users/pradeepkumar/projects/AI editor/docs/experiments/2026-10-18-instruction-reranker>) retains the earlier files plus:

- [Qwen protocol](</Users/pradeepkumar/projects/AI editor/docs/experiments/2026-10-18-instruction-reranker/qwen-protocol.json>) and fingerprint: `a0875d4679d4c760ef8dea22fa6cf0c5615966dbfb802f1f581f423064a5ab14`. The original 66 inputs and candidate documents remain in `protocol.json`.
- [Raw Qwen results](</Users/pradeepkumar/projects/AI editor/docs/experiments/2026-10-18-instruction-reranker/qwen-results.json>): every score, no/yes logit pair, token length and repeated timing.
- [Qwen analysis](</Users/pradeepkumar/projects/AI editor/docs/experiments/2026-10-18-instruction-reranker/qwen-analysis.json>): all split metrics, exact cutoffs, ranking and stability.
- [Validation](</Users/pradeepkumar/projects/AI editor/docs/experiments/2026-10-18-instruction-reranker/qwen-validation.json>): nine baseline hashes, earlier report/results, complete outputs and zero truncation/errors.
- `reconcile.py`, [comparison-reconciled.json](</Users/pradeepkumar/projects/AI editor/docs/experiments/2026-10-18-instruction-reranker/comparison-reconciled.json>): independent recount of all seven fixed policies and explicit separation of historical context-segment, any-delivery and expected-file metrics. The clarification adds no new model runs or tuned cutoffs.
- `download_qwen.py`, `qwen-model-manifest.json`, `run_qwen.py`, `analyze_qwen.py`, `validate_qwen.py`: public download/weight fingerprints, frozen-format runner and analysis checks. The download used `HF_HUB_DISABLE_XET=1` after the stalled attempt. Scoring uses offline model loading and disables remote model code. Existing result/protocol files cannot be overwritten by rerunning the scorer/freezer.

All scoring completed and its process exited. No temporary inference server was required for Qwen. Script lint, compilation, analysis sanity checks and Git whitespace validation passed. Product tests were not rerun because this follow-up changes only experiment scripts, evidence and this report.
