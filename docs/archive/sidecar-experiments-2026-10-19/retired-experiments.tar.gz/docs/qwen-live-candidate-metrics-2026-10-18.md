# Qwen plain-context live trial and per-message measurements

**Historical run, before the candidate-history replacement fix.** The accumulation measured below was a bug against the agreed design. The follow-up implementation and live comparison are documented in `docs/qwen-candidate-replacement-2026-10-18.md`.

Qwen plain context is enabled for **code candidates in this workspace's running backend**. The backend reports `qwen_plain: ready`; the ChatGPT provider configuration was preserved. Changes remain on `codex/sidecar-reliability-experiments`, uncommitted and unpushed.

The path is hybrid retrieval → Qwen3-Reranker-0.6B in one batch → strict score > 0.5 → visible-source suppression → compact candidate catalog. There is no embedding-based recap/summary selector on this path. Semantic retrieval still uses embeddings. Memory retains its independent BGE reranker. No automatic source-body delivery was introduced.

Local-model opt-out wins: when local models are disabled, candidates bypass the Qwen filter. Loading or failed Qwen inference also preserves the bounded retrieval results; telemetry distinguishes this bypass from filtering.

## Final live measurements

Four read-only messages were sent through the configured ChatGPT provider. The first three share a conversation; “hello” starts a fresh conversation. These are illustrative live checks, not a controlled task-quality benchmark or production percentile estimate.

| Message | End-to-end response | Retrieval | Qwen | Model requests | Current candidate fields delivered | All candidate tokens transmitted | Catalog before → after Qwen |
|---|---:|---:|---:|---:|---:|---:|---:|
| Explain catalog reuse in a specified file | 18.87 s | 2,603 ms | 447 ms | 2 | 267 | 442 | 509 → 175 |
| “Thanks, that answers it.” | 6.24 s | 330 ms | 729 ms | 1 | 144 | 411 | 496 → 203 |
| Explain filtering, opt-out, and hybrid retrieval across files | 52.74 s | 177 ms | 471 ms | 6 | 0 | 2,466 | 489 → 86 |
| Fresh “hello” | 4.84 s | 77 ms | 320 ms | 1 | 0 | 0 | 263 → 0 |

The initial retrieval after backend restart was substantially slower. Do not treat its 2.6 seconds as steady-state latency, or infer a stable latency percentile from the three later messages. Earlier isolated benchmark timings and these full live timings have different surrounding workloads. Main-model execution dominates total response times here; a no-Qwen paired run was not performed.

**Filter-only catalog reduction:** 1,757 → 464 tokens, removing **1,293 tokens (73.6%)** over four catalog computations. These comparisons are made before visibility suppression. Qwen kept 2, 3, 1, and 0 of the eight retrieved rows respectively. The acknowledgement retained candidates in the code conversation: plain context is not a reliable conversational bypass.

**Delivery versus transmitted history:** 411 tokens were put into current candidate fields across the ten calls, but **3,319 candidate tokens** were transmitted in total. Current-field counts also count repeated delivery across calls; they are not unique-token counts. Provider history retains previous controller-step payloads, which include older catalogs:

- First message: 175 candidate tokens on call 1; call 2 sends the old 175 plus its current 92 = 267. Total: 442.
- Acknowledgement: old catalogs total 267; current field adds 144. Total: 411.
- Multi-file message: current candidate fields are empty because the relevant retrieved source is already visible. Nevertheless, all six requests carry the previous 411 tokens: 6 × 411 = 2,466.

Thus Qwen shrank each new catalog, but that version did not remove catalog copies already retained in provider history. The follow-up fixes historical discovery-context serialization; this older run is preserved as diagnostic evidence.

The 73.6% reduction is **not** a measured reduction in whole-task input, provider billing, or total physical candidate tokens versus a no-Qwen replay. A no-filter agent may choose different reads and calls. Nor are all filter removals net savings: visible-source suppression might have removed some of them anyway.

## Measurement details and ongoing use

Candidate counts use `o200k_base` tokenization of an isolated escaped `code_candidates` JSON field envelope. This includes field/encoding overhead and has an explicit fallback label if the tokenizer is unavailable. It is a named token-count proxy, not a claim of exact provider billing attribution or an exact whole-request token delta at field boundaries. The final run used the tokenizer, not the character heuristic. Provider-reported whole-input counts are stored separately. Cached versus uncached billing savings are not calculated.

Physical counters run on outgoing request bodies, including retained step history and retries. Logical delivery counters describe the current field separately. Each message has a trace keyed by message ID with:

- Backend duration and retrieval/Qwen spans.
- Catalog rows and token counts before/after filtering, plus bypass status.
- Current candidate field sizes after visibility suppression.
- Candidate tokens per physical request and total across requests.
- Provider-reported input counts and candidate preparation errors.

Tracing remains enabled via `.crucible/state/performance.enabled`, with content-free records in `.crucible/state/performance.jsonl`. Timing includes telemetry overhead. No new model call is made to collect or summarize these measurements.

From the repository root, review the latest messages:

```sh
/Users/pradeepkumar/.crucible/runtime/venv/bin/python scripts/report-candidate-messages.py --limit 20
```

Save a full structured summary with `--output /private/tmp/candidate-messages.json`. This reports subsequent real user messages as well as validation messages; it does not rerun the probes. It requires the tracing flag to remain enabled.

Final evidence:

- `docs/validation/2026-10-18-qwen-live/pre-replacement-messages.json`: four messages, prompts, end-to-end durations, trace records, and summaries captured before replacement was fixed.
- `docs/validation/2026-10-18-qwen-live/pre-replacement-per-message.json`: corresponding summaries, including current-field versus physical totals.
- `docs/validation/2026-10-18-qwen-live/restart.json`: ready scorer and unchanged provider receipt.

## Validation and issues corrected

The live checks exposed two issues before the final run:

1. Candidate preparation read the thread-affine memory SQLite connection from a worker thread. Conversation signals now snapshot on the owning event loop before retrieval/inference moves off loop. A regression test checks this separation.
2. Physical attribution initially missed native provider strings prefixed with `Current step ...`. It now recognizes the exact native prefix as well as JSON content parts. A regression test covers both string and content-part requests.

The failed runs are preserved as `initial-diagnostic-messages.json` and `pre-native-prefix-diagnostic-messages.json`. Their zero physical counters must not be interpreted as filtering savings. Only `pre-replacement-messages.json` supports the table above. The later `messages.json` contains the post-fix run.

All 92 focused backend tests passed, covering the gate, opt-out and failure paths, context selection, delivery, callback threading, metrics and performance tracing. Ruff for the new scorer, telemetry and scripts passed, as did `git diff --check`. Extension setting mapping tests, TypeScript and the extension build passed during integration. This is a workspace trial, not a global default or a proven accuracy improvement.
